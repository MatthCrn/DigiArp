# SPDX-License-Identifier: GPL-2.0-or-later
"""Rebuild the guarded D620 source with the user's local stock OS and SDK."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--sdk', required=True, type=Path)
    parser.add_argument('--cross', required=True, help='Full compiler prefix, ending in m68k-elf-')
    parser.add_argument('--stock', required=True, type=Path)
    parser.add_argument('--out', required=True, type=Path)
    args = parser.parse_args()
    sdk = args.sdk.resolve()
    stock = args.stock.resolve()
    destination = args.out.resolve()
    sys.path.insert(0, str(sdk))
    from elekloader import formats

    container, device, _ = formats.load(str(stock))
    image = formats.main_image(container, device)
    repository = Path(__file__).resolve().parents[1]
    source = repository / 'source'
    module_relative = Path('persistence-sources050/firmware/melody_native')
    recipe = json.loads((source / module_relative / 'mod.guarded.json').read_text())
    for site in recipe['sites']:
        address = int(site['addr'], 16)
        offset = address - device.main_load
        length = site.pop('len')
        expected = site.pop('stock_sha256')
        original = image[offset:offset + length]
        if offset < 0 or len(original) != length or hashlib.sha256(original).hexdigest() != expected:
            raise ValueError('Stock firmware guard failed at ' + hex(address))
        site['stock'] = original.hex()

    environment = os.environ.copy()
    environment['PYTHONPATH'] = str(sdk)
    environment['ELEKLOADER_CROSS'] = args.cross
    environment['PATH'] = str(Path(args.cross).parent) + os.pathsep + environment['PATH']
    destination.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='digiarp-build-', dir=destination) as temporary:
        tree = Path(temporary) / 'source'
        shutil.copytree(source, tree)
        module = tree / module_relative
        (module / 'mod.json').write_text(json.dumps(recipe, indent=2) + '\n')
        subprocess.run([sys.executable, '-m', 'elekloader.sdk.build', str(module),
                        '--stock', str(stock), '--out', str(destination)],
                       env=environment, check=True)


if __name__ == '__main__':
    main()
