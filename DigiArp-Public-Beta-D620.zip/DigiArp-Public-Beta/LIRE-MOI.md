# Préparation de la bêta publique DigiArp

Auteur BonVoyage ModularForms, compte GitHub MatthCrn.

Le dossier contient la D620 exacte, ses sources sélectionnées, les licences, un guide en anglais, les notes de version et le rapport de tests. Le dossier modwerk décrit les points d'intégration et contient une vignette conceptuelle.

La D620 a été rapportée testée sous 90 % CPU avec huit pistes et des LFO. La disparition des clics, la RAM libre, la durée et les essais de sauvegarde/redémarrage restent à préciser pour cette version.

L'intégration au catalogue Modwerk exige encore la vérification du Core et des points de modification du firmware, les captures d'écran réelles et les preuves de tests. La version D620 utilise Core 4.1 tandis que le profil Modwerk actuel annonce l'interface 2.1. Une compilation et des essais seront nécessaires pour tout paquet adapté.

La publication GitHub nécessite une connexion au compte MatthCrn. Ce dossier prépare cette étape. Les liens GitHub proposés dans les documents restent des cibles tant que le dépôt et la release ne sont pas créés.

Les sources pr�par�es reconstruisent un fichier elemod strictement identique � la D620 test�e. L'audit Modwerk a identifi� neuf chevauchements de points de modification, d�taill�s dans modwerk/patch-overlaps.json. La b�ta doit �tre utilis�e en tenant compte des modules concern�s, avant r�solution de ces conflits.
