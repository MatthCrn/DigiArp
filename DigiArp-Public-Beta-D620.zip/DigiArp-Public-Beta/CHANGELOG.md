# Releases

## 0.62.0dev0 — public-beta candidate

- Adds DigiArp and Melody Engine to audio and MIDI tracks on Digitakt MK1 OS 1.54.
- Offers six musical presets, six variation depths, FREEZE and RISE.
- Shows the evolving Melody Engine phrase in the main step editor after YES.
- Adds a third LFO to audio tracks and Melody Engine modulation destinations.
- Known issue — LFO 3 parameter locks remain unimplemented.
