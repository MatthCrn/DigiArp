# D620 test record

Version 0.62.0dev0. Target Digitakt MK1 OS 1.54, Core 4.1.
Released object SHA-256 `b7c8bbe77faefbf0b16863babcbc563b64a999e9f31d7717e91cba5056ab6456`.

## Author hardware report

Reported by MatthCrn / BonVoyage ModularForms on 2026-11-15 in the development conversation.
Exact statement translated from French: D620 tested, stays below 90% CPU with eight active tracks and LFOs.

The test duration, tempo, active presets, LFO settings, companion modules and measured free RAM were not supplied. Resolution of the earlier clicks was not stated. Save/reload and physical power-cycle results for this exact version were not supplied.

## Software results

- Eight-audio-track scheduler comparison against D619, two scenarios, 814 combined events. Notes, velocities, lengths and scheduling traces match.
- Scheduler instruction totals for twenty sampled calls changed from 99033 to 85215 and from 95982 to 82439. Twelve UI-generation refreshes changed from 112273 to 62112 and from 110977 to 62112. These instruction counts describe the tested routines in emulation. Hardware total CPU is reported separately above.
- 96 combinations of six presets and sixteen tracks pass YES-to-main evolution, freeze, per-step edits, Euclidean restoration and source restoration.
- Compiled audio/MIDI scheduler passes four-loop handoff checks. The audio mixer and acoustic output are outside that fixture.
- 13056 codec round trips pass, including single-bit corruption rejection.
- Compiled project manager, codec and RAM-context tests pass three patterns by sixteen tracks, simulated fresh state, temporary restore, corruption rejection and legacy audio-track migration. Heap allocation is modeled. The native storage writer and physical power cycle are outside this suite.
- LFO navigation and cached page counters pass. Memory copy/fill tests pass alignment and boundary cases.
- SDK build and lint pass with Core 4.1 and the private reference DigiHealth 1.0 module.

## Memory

D620 linked sections are 173339 bytes run code/data and 75488 bytes BSS, totaling 248827 bytes before linker alignment and companion modules. Heap allocations in the project persistence test are 658656, 532736 and 532736 bytes, totaling 1724128 bytes for that exercised setup. Section sizes do not measure physical free RAM.

## Hardware acceptance to record

Use a disposable project. Record model, OS, exact module hash, companion mods, tempo, presets and duration. Compare the same eight-track passage for CPU, free RAM and audible clicks. Check note releases on STOP/mute, pattern changes, audio and MIDI output, and controls while playing. Save distinct settings on several tracks and patterns, edit without saving, reload, switch projects and return, then power-cycle and verify the saved settings and usable playback. Record each actual result and any failure.

## Modwerk qualification

No Modwerk build, catalogue publication or downloaded-image hardware test has been performed. Core-interface and patch ownership differences are tracked in modwerk/INTEGRATION.md.

## Public source rebuild

The selected public source tree and guarded manifest were compiled through tools/build.py using the D620 toolchain. The output is byte-for-byte identical to the author-tested D620 object. Modwerk compiler and core integration remain open.
