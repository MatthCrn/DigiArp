# Proposed DigiArp submission

DigiArp adds a per-track arpeggiator and an evolving Melody Engine to Digitakt MK1 OS 1.54, including MIDI output and a third audio-track LFO. Its six presets cover free phrases, bass lines, arpeggios, rolls and melodic motion. YES returns the generated phrase to a live step editor.

Author and maintainer — BonVoyage ModularForms, GitHub MatthCrn.

The D620 author build has been tested on a unit and was reported below 90% CPU with eight active tracks and LFOs. Software tests cover phrase behavior, scheduler traces, codecs and modeled persistence. Exact hardware conditions, click resolution and physical persistence/reboot evidence remain open. LFO 3 P-locks remain unimplemented.

Core integration needs review because the current author build declares Core 4.1 and the Modwerk Digitakt profile pins interface 2.1. The native audio, LFO UI, MIDI and persistence sites need a full ownership comparison. This is a preparation record for that review.
