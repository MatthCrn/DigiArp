# Modwerk integration preparation

Author GitHub MatthCrn. Display name BonVoyage ModularForms. Proposed public repository https://github.com/MatthCrn/DigiArp. The public repository was created on 2026-11-15. Upload of the prepared files remains pending.

Baseline is the exact D620 elemod 0.62.0dev0. Keep its version and binary identity while preparing its review. Its historical internal module ID is digiarp-smoke. Changing that ID requires a separately built and tested release, including review of persistence client ownership and conflict names.

The current upstream Modwerk Digitakt profile pins Core interface 2.1. D620 declares Core 4.1 and uses the Core 3/4 SDK headers plus its own audio-dispatch/start collections. The integration needs an explicit comparison of core symbols, event ABI and site ownership. This preparation does not claim compatibility with Modwerk Core 2.1.

D620 also patches the native LFO UI, pattern/project persistence and MIDI scheduling. Compare every guarded site with the base and all catalogue modules. Keep the existing declared conflicts with digipoly, digimatrix and project-data-dt1. Additional actual overlaps must be documented before catalogue submission.

The modwerk/build.draft.json declaration uses paths relative to this public repository root and is source-derived from the guarded SDK recipe. It remains an integration input outside the upstream catalogue until the core interface, source-only compiler flags, package parity and manifests pass their real checks. Do not set publication evidence to author-hardware for a Modwerk rebuild based solely on the original D620 hardware report.

Remaining publication inputs are real monochrome UI captures and capture provenance, hardware test duration/configuration/RAM, click outcome, persistence and reboot results, an authenticated GitHub session, the public source revision and release asset URL, the package pin and the maintainer-reviewed compatibility outcome. The empty public repository exists. No release or pull request has been published.

## Static site overlap audit

The checked Modwerk checkout is b52d11e00a124a7e1ae35d23eff5b4d072ab961f. Nine guarded-site overlaps were found across the current OS 1.54 build declarations, including machine-pages/digichain/digineighbor at the native parameter formatter, DigiMatrix and Digi Perform at LFO callbacks, DigiPoly at audio dispatch, and Euclidean Sequencing at audio/MIDI trig preparation. See patch-overlaps.json for exact addresses. This static scan does not establish complete compatibility or account for every indirect site claim.

The original D620 object declares only its existing conflicts. Its binary is retained exactly as tested. Users must avoid combining this beta with the additional overlapping modules until shared-hook integration or a validated exclusion rule is available.
