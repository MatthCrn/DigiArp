# DigiArp

Arpeggiator and Melody Engine for the original Elektron Digitakt.

By **BonVoyage ModularForms** · GitHub **MatthCrn**

## Overview

DigiArp turns a source trig into an arpeggio or an evolving musical phrase on audio tracks T1–T8 and MIDI tracks A–H. Melody Engine offers FREE, BASS, ARP, ROLL, MELO and FLOW, from small rhythmic gestures to changing melodic patterns. Six variation depths and a freeze switch make the phrase playable in live performance.

This public-beta candidate is D620, version 0.62.0dev0, for Digitakt MK1 OS 1.54. Audio-track playback supports the native ONESHOT machine. Use the exact OS version specified. Installation uses a custom firmware built locally from your own official OS file. Back up projects and samples before installation and retain the official OS for recovery.

## Controls

Open DigiArp with FUNC + TRIG. YES moves from the main page to Note Source, then Melody Engine. YES in Melody Engine returns to the main editor, whose sequence follows the phrase being played. NO moves back through Note Source to the main page, and exits from the main page. Reopening with FUNC + TRIG recalls the page used in the current session.

| Melody Engine encoder | Function |
| --- | --- |
| A RHY | Attack density and rhythmic placement, from silence to sixteen attacks |
| B MOT | Pitch movement and musical activity, shaped by the preset |
| C OCT | Four register positions, with the fourth extending upward |
| D PRESET | FREE, BASS, ARP, ROLL, MELO or FLOW |
| E VAR | Six increasing variation depths |
| F FREEZE | Holds the phrase when ON, allows evolution when OFF |
| G RISE | Higher-register variations within the playable pitch range |
| H FREQ | Native filter frequency on audio tracks |

Note Source selects TRIG, FIXED or CUSTOM, the scale, note count and octave register. Its MODE control selects classic arpeggiation or recalls ME. In the main editor after Melody Engine, A adjusts the selected step's velocity, B adjusts speed, C controls the audio filter, and D adjusts probability. The remaining controls provide Euclidean pulse/rotation settings, phrase length and selected-step pitch offset. Arrow keys select, activate or deactivate steps.

Audio tracks gain a third LFO page, reached by pressing LFO in the cycle 1/3 → 2/3 → 3/3. Extra audio-track LFO destinations include ME RHY, ME MOT, ME OCT, ME VAR, ME PRESET and ME RISE.

## Usage

1. On a test pattern, choose an ONESHOT audio sound or an enabled MIDI output channel. Place a source trig and use a suitable native note length. For a sustained audio source, start with LEN INF.
2. Open DigiArp with FUNC + TRIG and select TRUE on the main page. Start playback and confirm that the source trig starts arpeggiation.
3. Press YES for Note Source, choose your source notes and scale, then YES for Melody Engine. A prepared Melody Engine phrase starts at the next accepted source trig.
4. Choose a preset, turn RHY and MOT, and raise VAR gradually. Set FREEZE ON to hold a phrase. Press YES to see and edit its steps on the main page.
5. Stop the transport to stop playback. FUNC + CLEAR retains native track clear and also resets DigiArp for that track.

FUNC + REC captures a generated phrase as pattern trigs. Follow its on-screen recording and confirmation prompts, using a disposable pattern first. Writing the captured phrase changes pattern trigs.

## Compatibility and limitations

- Target is Digitakt MK1 OS 1.54 with elekloader Core 4.1. Other instruments and OS versions have no qualification for this release.
- The Modwerk catalogue integration is in preparation. The bundled elemod is the author's D620 build. It has not yet been qualified through Modwerk's build and download workflow.
- LFO 3 parameter locks remain unimplemented. Its eight page parameters, normal modulation, clipboard/reset and persistence have software coverage.
- digiPoly, DigiMatrix and the separate project-data-dt1 module are declared conflicts in the D620 recipe. The current Modwerk sources also show patch overlaps with Machine Pages, digichain, NEIGHBOR, Digi Perform and Euclidean Sequencing. Avoid combining this beta with them until compatibility is resolved. See modwerk/patch-overlaps.json.
- The native audio pitch range depends on the Sound TUNE and the sample playback engine. RISE and OCT follow that available range.
- The author reports under 90% CPU with eight active tracks and LFOs on D620. Test duration, full configuration, measured free RAM and the outcome of the previously reported clicks are still to be documented.
- Project save/load and temporary restore are implemented. Physical save/reload and power-cycle evidence for this exact release remains to be completed in TESTING.md.

## Tests and measurements

See TESTING.md for the distinction between compiled-code tests, emulator measurements and the author's hardware report. Report a bug with the exact version, track type, preset, source mode, tempo, track length, other selected mods and reproduction steps. Never attach firmware or personal projects to public reports.

## Authorship and licences

Musical design, direction and hardware testing by BonVoyage ModularForms (MatthCrn), with Codex-assisted implementation and testing. Existing DigiArp contributor notices are retained. Firmware integration is GPL-2.0-or-later. Portable components marked MIT retain that licence and the notice in LICENSES/MIT.txt. The combined release is distributed under GPL-2.0-or-later.

The external elekloader SDK and Core are separate projects. This repository refers to their APIs and retains the existing source notices. Elektron product names identify the target instrument. DigiArp is an independent unofficial project.

## Screens and audio

Verified captures and demonstration links will be added before catalogue submission. A conceptual thumbnail is supplied in modwerk/thumbnail.svg. It represents musical activity.

## Building

Run `python tools/build.py --sdk PATH_TO_ELEKLOADER --cross PATH_TO_m68k-elf- --stock YOUR_OFFICIAL_OS --out LOCAL_OUTPUT` with Python, the elekloader SDK used for D620 and a ColdFire cross compiler. The script verifies guarded stock spans from your local OS and materializes the SDK input in a temporary directory. The public source manifest stores address, length and SHA-256 guards.

The dist folder includes the exact D620 elemod and its SHA-256. The prepared source tree was rebuilt with the D620 toolchain and produced a byte-for-byte identical elemod. See modwerk/source-rebuild.json. Modwerk uses its own pinned toolchain and needs a separate parity check.
