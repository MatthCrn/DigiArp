| SPDX-License-Identifier: GPL-2.0-or-later
        .section .run,"ax"
        .globl darp_lfo_prehook
darp_lfo_prehook:
        move.l %d0,-(%sp)
        move.l %d0,-(%sp)
        jsr darp_lfo_pre
        addq.l #4,%sp
        move.l (%sp)+,%d0
        movea.l (%sp)+,%a1
        move.l 0x4020df10,-(%sp)
        jmp (%a1)
        .globl darp_lfo_posthook
darp_lfo_posthook:
        move.l 12(%sp),-(%sp)
        move.l 12(%sp),-(%sp)
        move.l 12(%sp),-(%sp)
        jsr darp_lfo_post
        lea 12(%sp),%sp
        move.l (%sp),%d0
        lea 20(%sp),%sp
        move.l %d0,-(%sp)
        clr.l %d0
        rts
| UI list's temporary vector: preserve all scratch registers, then replay.
        .globl darp_lfo_list_hook
darp_lfo_list_hook:
        lea -16(%sp),%sp
        movem.l %d0-%d1/%a0-%a1,(%sp)
        move.l %a5,-(%sp)
        move.l -88(%a6),-(%sp)
        jsr darp_lfo_list_extend
        addq.l #8,%sp
        movem.l (%sp),%d0-%d1/%a0-%a1
        lea 16(%sp),%sp
        movea.l -88(%a6),%a0
        move.l 4(%a0),%d1
        rts
        .globl darp_lfo_list_end_hook
darp_lfo_list_end_hook:
        lea -16(%sp),%sp
        movem.l %d0-%d1/%a0-%a1,(%sp)
        jsr darp_lfo_list_restore
        movem.l (%sp),%d0-%d1/%a0-%a1
        lea 16(%sp),%sp
        move.l 172(%a5),%d0
        bmi.s 1f
        rts
1:      addq.l #4,%sp
        jmp 0x400a4d06
        .globl darp_lfo_row_hook
darp_lfo_row_hook:
        movea.l 8(%sp),%a1
        move.l 4(%a1),%d0
        cmpi.l #171,%d0
        bcs.s 2f
        cmpi.l #179,%d0
        bhi.s 2f
        move.l %a0,-(%sp)
        move.l %d0,-(%sp)
        move.l %a0,-(%sp)
        jsr darp_lfo_row
        addq.l #8,%sp
        move.l (%sp)+,%d0
        rts
2:      lea -52(%sp),%sp
        movem.l %d2-%d7/%a2-%a6,(%sp)
        jmp 0x400a4450
| C++ shared vector result uses the hidden A0 result register.
        .globl darp_lfo_get_list
darp_lfo_get_list:
        movea.l 4(%sp),%a0
        move.l 12(%sp),-(%sp)
        move.l 12(%sp),-(%sp)
        jsr 0x40011348
        addq.l #8,%sp
        rts

        .globl darp_lfo_native_validate
darp_lfo_native_validate:
        link.w %a6,#-28
        movem.l %d2-%d3/%a2-%a3,(%sp)
        jmp 0x4001157e

        .globl darp_lfo_native_change
darp_lfo_native_change:
        link.w %a6,#-20
        movem.l %d2/%a2-%a3,(%sp)
        jmp 0x400a4e64
        .globl darp_lfo_native_increment
darp_lfo_native_increment:
        link.w %a6,#-24
        move.l 12(%a6),%d0
        jmp 0x4001163a

| Native / machine-pages have already saved d2-d6 at this point.
        .globl darp_lfo_gfx_hook
darp_lfo_gfx_hook:
        lea 28(%sp),%a0
        move.l %a0,-(%sp)
        jsr darp_lfo_draw_destination
        addq.l #4,%sp
        tst.l %d0
        beq.s 1f
        movem.l (%sp),%d2-%d6
        lea 20(%sp),%sp
        rts
1:      move.l 32(%sp),%d2
        move.l 36(%sp),%d6
        jmp 0x4000f2cc

| Only native UI-owned references may acquire independent LFO 3 storage.
| Ref/parameter are ordinary stack arguments at each of these entry points.
        .globl darp_lfo_turn_reference
darp_lfo_turn_reference:
        bsr darp_lfo_bind_entry
        tst.l %d0
        beq.s 9f
        lea -12(%sp),%sp
        movem.l %d2/%a2-%a3,(%sp)
        jmp 0x4000ffe2
9:      rts
        .globl darp_lfo_turn_fine_reference
darp_lfo_turn_fine_reference:
        bsr darp_lfo_bind_entry
        tst.l %d0
        beq.s 9f
        lea -56(%sp),%sp
        movem.l %d2-%d7/%a2-%a6,(%sp)
        jmp 0x4001002e
9:      rts
        .globl darp_lfo_set_reference
darp_lfo_set_reference:
        bsr darp_lfo_bind_entry
        tst.l %d0
        beq.s 9f
        lea -44(%sp),%sp
        movem.l %d2-%d7/%a2-%a3,(%sp)
        jmp 0x4000fefe
9:      rts
        .globl darp_lfo_format_reference
darp_lfo_format_reference:
        bsr darp_lfo_bind_entry
        lea -20(%sp),%sp
        movem.l %d2-%d4/%a2-%a3,(%sp)
        jmp 0x4000f32c
9:      rts
darp_lfo_bind_entry:
        lea -12(%sp),%sp
        movem.l %d1/%a0-%a1,(%sp)
        move.l 24(%sp),-(%sp)
        move.l 24(%sp),-(%sp)
        jsr darp_lfo_bind_reference
        addq.l #8,%sp
        movem.l (%sp),%d1/%a0-%a1
        lea 12(%sp),%sp
        rts

| Native page clipboard captures use hidden A0 vector results.
        .globl darp_lfo_copy_values
darp_lfo_copy_values:
        bsr darp_lfo_bind_copy
        tst.l %d0
        beq.s darp_lfo_empty_copy
        lea -24(%sp),%sp
        movem.l %d2/%a2-%a5,(%sp)
        jmp 0x400111e2
        .globl darp_lfo_copy_pairs
darp_lfo_copy_pairs:
        bsr darp_lfo_bind_copy
        tst.l %d0
        beq.s darp_lfo_empty_copy
        lea -28(%sp),%sp
        movem.l %d2/%a2-%a5,(%sp)
        jmp 0x40011ac0
darp_lfo_empty_copy:
        clr.l (%a0)
        clr.l 4(%a0)
        clr.l 8(%a0)
        move.l %a0,%d0
        rts
darp_lfo_bind_copy:
        lea -16(%sp),%sp
        movem.l %d1/%a0-%a1,(%sp)
        move.l 28(%sp),-(%sp)
        move.l 28(%sp),-(%sp)
        jsr darp_lfo_bind_group
        addq.l #8,%sp
        movem.l (%sp),%d1/%a0-%a1
        lea 16(%sp),%sp
        rts

| Replace only the native header's two printf arguments.
| The actual page vector, cursor, format string and drawing remain native.
        .globl darp_lfo_counter_hook
darp_lfo_counter_hook:
        asr.l #2,%d0
        move.l %d0,-(%sp)
        move.l %a2,-(%sp)
        jsr darp_lfo_page_number
        addq.l #4,%sp
        tst.l %d0
        beq.s 1f
        moveq #3,%d1
        move.l %d1,(%sp)
        movea.l %d0,%a2
        bra.s 2f
1:      movea.l 144(%a2),%a2
        addq.l #1,%a2
2:      move.l %a2,-(%sp)
        jmp 0x40030978
