/* SPDX-License-Identifier: GPL-2.0-or-later */
#include "midi_gate.h"
#define FIRST 0x421b8e38u
#define END 0x421c4e38u
#define STRIDE 24u
#define HEAD (*(volatile uint32_t *)0x421b8e34u)
#define LINK(p) (*(volatile uint32_t *)((p)+20u))
static uint32_t owned[64];
volatile uint32_t darp_midi_gate_faults;
static int valid(uint32_t p){return p>=FIRST && p<END && (p-FIRST)%STRIDE==0;}
static unsigned idx(uint32_t p){return (p-FIRST)/STRIDE;}
static int is_owned(uint32_t p){unsigned i=idx(p);return (owned[i>>5]&(1u<<(i&31)))!=0;}
static int fault(void){++darp_midi_gate_faults;return 0;}
uint32_t darp_midi_gate_reserve(void){
 uint32_t p=HEAD;if(!p)return 0;
 if(!valid(p) || is_owned(p))return (uint32_t)fault();
 uint32_t next=LINK(p);
 if(next && (!valid(next) || next==p || is_owned(next)))return (uint32_t)fault();
 unsigned i=idx(p);HEAD=next;owned[i>>5]|=1u<<(i&31);
 for(unsigned w=0;w<6;w++)((volatile uint32_t *)p)[w]=0;
 return p;
}
int darp_midi_gate_release(uint32_t p){
 if(!valid(p) || !is_owned(p))return fault();
 if(HEAD && (!valid(HEAD) || is_owned(HEAD)))return fault();
 unsigned i=idx(p);LINK(p)=HEAD;HEAD=p;owned[i>>5]&=~(1u<<(i&31));return 1;
}
int darp_midi_gate_handoff(uint32_t p){
 if(!valid(p) || !is_owned(p))return fault();
 unsigned i=idx(p);owned[i>>5]&=~(1u<<(i&31));return 1;
}
