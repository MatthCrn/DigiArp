/* SPDX-License-Identifier: MIT */
#include <stddef.h>
#include <stdint.h>
typedef uint16_t copy_word __attribute__((__may_alias__));
typedef uint32_t copy_long __attribute__((__may_alias__));
/* ColdFire permits aligned halfwords. Odd/different parity copies stay bytewise;
 * never read beyond n, including the final byte of a mapped region. */
void *darp_memset(void *p,int value,size_t n){
 unsigned char *d=p;unsigned char v=(unsigned char)value;
 if(n && ((uintptr_t)d&1u)){*d++=v;--n;}
 copy_word w=(copy_word)((unsigned)v*257u);
 if(n>=16){
  if((uintptr_t)d&2u){*(copy_word *)d=w;d+=2;n-=2;}
  copy_long fill=(copy_long)w*65537u;
  while(n>=16){
   copy_long *q=(copy_long *)d;
   q[0]=fill;q[1]=fill;q[2]=fill;q[3]=fill;
   d+=16;n-=16;
  }
 }
 while(n>=8){copy_word *q=(copy_word *)d;q[0]=w;q[1]=w;q[2]=w;q[3]=w;d+=8;n-=8;}
 while(n>=2){*(copy_word *)d=w;d+=2;n-=2;}
 if(n)*d=v;
 return p;
}
void *darp_memcpy(void *p,const void *s,size_t n){
 unsigned char *d=p;const unsigned char *b=s;
 if(((uintptr_t)d^(uintptr_t)b)&1u){while(n--)*d++=*b++;return p;}
 if(n && ((uintptr_t)d&1u)){*d++=*b++;--n;}
 if(n>=16 && !(((uintptr_t)d^(uintptr_t)b)&2u)){
  if((uintptr_t)d&2u){*(copy_word *)d=*(const copy_word *)b;d+=2;b+=2;n-=2;}
  while(n>=16){
   copy_long *q=(copy_long *)d;const copy_long *r=(const copy_long *)b;
   q[0]=r[0];q[1]=r[1];q[2]=r[2];q[3]=r[3];
   d+=16;b+=16;n-=16;
  }
 }
 while(n>=8){copy_word *q=(copy_word *)d;const copy_word *r=(const copy_word *)b;
  q[0]=r[0];q[1]=r[1];q[2]=r[2];q[3]=r[3];d+=8;b+=8;n-=8;}
 while(n>=2){*(copy_word *)d=*(const copy_word *)b;d+=2;b+=2;n-=2;}
 if(n)*d=*b;
 return p;
}
/* GCC can emit these libc names for aggregate copies even with -fno-builtin.
 * First alpha links with core only; duplicate names in another mod are refused. */
#undef memcpy
#undef memset
void *memcpy(void *p,const void *s,size_t n){return darp_memcpy(p,s,n);}
void *memset(void *p,int v,size_t n){return darp_memset(p,v,n);}
