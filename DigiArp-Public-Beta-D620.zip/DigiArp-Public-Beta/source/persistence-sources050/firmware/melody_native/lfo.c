/* SPDX-License-Identifier: GPL-2.0-or-later */
#include "lfo.h"
#include "core_audio.h"
#include "digitakt-mk1/core3.h"
volatile uint8_t darp_lfo_routes[8][2];
volatile int32_t darp_lfo_delta[8][DARP_LFO_TARGETS];
volatile int16_t darp_lfo3[8][8];
/* Private native oscillator state, in the exact OS 1.54 layout. */
static uint32_t native_state[8][10];
static int32_t extra_delta[8];
extern void darp_native_lfo_tick(volatile int16_t *,unsigned,unsigned,
                                const volatile int16_t *,uint32_t *);
void darp_lfo3_clear(unsigned t){
    if(t>=8)return;
    static const int16_t defaults[8]={28672,1024,16384,0,256,0,0,16384};
    for(unsigned i=0;i<8;i++)darp_lfo3[t][i]=defaults[i];
    for(unsigned i=0;i<10;i++)native_state[t][i]=0;
    native_state[t][4]=0x3fffffff;
    extra_delta[t]=0;
}
static void render_third(unsigned t,volatile int16_t *words,unsigned tempo,unsigned trigger){
    extra_delta[t]=0;
    int dest=darp_lfo3[t][3]/256;
    darp_native_lfo_tick(words,tempo,trigger,darp_lfo3[t],native_state[t]);
    if(dest>=53 && dest<=DARP_LFO_DEST_LAST){
        int32_t waveform=(int32_t)native_state[t][1];
        int32_t depth=(int32_t)darp_lfo3[t][7]-16384;
        extra_delta[t]=(waveform/65536)*depth/16384;
    }
}
static int16_t saved[8][2];
static uint8_t routed[8][2],had_routes[8];
void darp_lfo_pre(void *base){
    for(unsigned t=0;t<8;t++)for(unsigned l=0;l<2;l++){
        volatile int16_t *w=(volatile int16_t *)((uint8_t *)base+18+106*t);
        int dest=w[4+8*l]/256;
        unsigned route=dest>=DARP_LFO_DEST_FIRST && dest<=DARP_LFO_DEST_LAST?(unsigned)(dest-52):0;
        darp_lfo_routes[t][l]=(uint8_t)route;routed[t][l]=(uint8_t)(route<=DARP_LFO_TARGETS?route:0);
        if(routed[t][l]){saved[t][l]=w[4+8*l];w[4+8*l]=-1;}
    }
}
void darp_lfo_post(void *base,unsigned tempo,unsigned triggers){
    for(unsigned t=0;t<8;t++){
        volatile int16_t *w=(volatile int16_t *)((uint8_t *)base+18+106*t);
        render_third(t,w,tempo,(triggers>>t)&1u);
        unsigned active=routed[t][0] || routed[t][1];
        active=active || extra_delta[t];
        if(!active && !had_routes[t])continue;
        had_routes[t]=(uint8_t)active;
        int32_t sum[DARP_LFO_TARGETS]={0};
        for(unsigned l=0;l<2;l++)if(routed[t][l]){
            w[4+8*l]=saved[t][l];
            int32_t value=*(volatile int32_t *)(uintptr_t)(0x421f4e14u+80*t+40*l);
            int32_t depth=(int32_t)w[8+8*l]-16384;
            /* Bounded signed product; full DEP64 covers the target's range.
             * Division gives defined signed behavior, precision 16 waveform bits. */
            int32_t product=(value/65536)*depth;
            sum[routed[t][l]-1]+=product/16384;
        }
        int dest=darp_lfo3[t][3]/256;
        if(dest>=53 && dest<=DARP_LFO_DEST_LAST)sum[dest-53]+=extra_delta[t];
        for(unsigned k=0;k<DARP_LFO_TARGETS;k++)darp_lfo_delta[t][k]=sum[k];
    }
}
unsigned darp_lfo_map_delta(unsigned target,unsigned base,int32_t modulation){
    static const unsigned low[DARP_LFO_TARGETS]={1,0,1,0,0,1,0,0,0};
    static const unsigned high[DARP_LFO_TARGETS]={8,5,16,127,127,4,5,5,127};
    if(target>=DARP_LFO_TARGETS)return base;
    /* Two native waves/depths are bounded, including their signed sum. */
    if(!modulation && base>=low[target] && base<=high[target])return base;
    int32_t n=modulation*(int32_t)(high[target]-low[target]);
    int32_t delta=n>=0?(n+16256)/32512:-((-n+16256)/32512);
    int32_t value=(int32_t)base+delta;
    if(value<(int32_t)low[target])value=(int32_t)low[target];
    if(value>(int32_t)high[target])value=(int32_t)high[target];
    return (unsigned)value;
}
unsigned darp_lfo_value(unsigned t,unsigned target,unsigned base){
    if(t>=8 || target>=DARP_LFO_TARGETS)return base;
    return darp_lfo_map_delta(target,base,darp_lfo_delta[t][target]);
}
void darp_lfo_reset_track(unsigned t){
    if(t>=8)return;
    for(unsigned k=0;k<DARP_LFO_TARGETS;k++)darp_lfo_delta[t][k]=0;
    darp_lfo3_clear(t);
    /* Do not clear saved/routed: an in-flight pre/post pair owns its restore. */
}
