/* SPDX-License-Identifier: GPL-2.0-or-later */
#include "digitakt-mk1/core3.h"
#include "controls.h"
#include "lfo.h"
#include "pattern_store.h"
#include "print.h"
#define DARP_ME_TRACK darp_ui_track
#include "melody_native.h"
#include "../../src/melody_order.h"
#include "../../src/arp_scale.h"
#include "core_audio.h"
#include "native_ui.h"
#include "length_labels.h"
#include "../../src/arp_chord.h"
#include "../../src/arp_pitch_set.h"
extern volatile uint32_t darp_root[DARP_TRACKS],darp_root_valid[DARP_TRACKS];
extern volatile int32_t pd_project_error,darp_project_error;
volatile uint32_t darp_ui_track;
#define darp_enabled (darp_controls[darp_ui_track].enabled)
#define darp_settings (darp_controls[darp_ui_track].settings)
#define darp_revision (darp_controls[darp_ui_track].revision)
#define darp_mask (darp_controls[darp_ui_track].mask)
#define rhythm (darp_rhythm[darp_ui_track])
#define darp_length (darp_controls[darp_ui_track].length)
#define darp_offsets (darp_controls[darp_ui_track].offsets)
#define darp_source (darp_controls[darp_ui_track].source)
#define darp_preset (darp_controls[darp_ui_track].preset)
#define darp_chord_count (darp_controls[darp_ui_track].chord_count)
#define darp_chord_offsets (darp_controls[darp_ui_track].chord_offsets)
static int32_t turns[8];
static uint8_t selected;
static unsigned popup_ticks,popup_knob;
static void *refresh_controller;
static unsigned refresh_ticks,shortcut_release,exit_release;
enum { DARP_UI_MAIN,DARP_UI_SOURCE,DARP_UI_MELODY };
volatile uint32_t darp_ui_page;
/* UI session only: native parameter pages must not import/leave the ME. */
static uint8_t return_page[DARP_TRACKS];
static void remember_page(void){if(darp_ui_track<DARP_TRACKS)return_page[darp_ui_track]=(uint8_t)darp_ui_page;}
#define notes_page (darp_ui_page==DARP_UI_SOURCE)
static uint32_t header_ticks;
volatile uint32_t darp_ui_visible;
#define visible darp_ui_visible
static int chord_bank;
static unsigned quantize_opened,track_held,bank_held,pattern_held,print_owned_key;
static uint16_t owned_pads;
static uint32_t clear_blockers;
/* Context serial is published by the existing pattern/restore handoff. */
extern volatile uint32_t darp_store_context_serial;
static uint32_t view_context;
static unsigned view_context_seen;
extern unsigned darp_lfo_ui_scope;
static unsigned lfo_editor,lfo_presses,lfo_key_owned,lfo_expected,lfo_seen;
static void *lfo_brain;
void darp_lfo_observe(unsigned bank){
    if(lfo_expected && !lfo_editor)lfo_seen=bank;
}
unsigned darp_lfo_editing(void){return lfo_editor && fw_active_track<8;}

static void follow_track(void){
    unsigned t=fw_active_track;uint32_t serial=darp_store_context_serial;
    unsigned changed=view_context_seen && serial!=view_context;
    view_context=serial;view_context_seen=1;
    if(changed)for(unsigned i=0;i<DARP_TRACKS;i++)
        return_page[i]=darp_me_enabled_tracks[i]?DARP_UI_MELODY:DARP_UI_MAIN;
    if(t>=8 && lfo_editor){visible=0;lfo_editor=0;lfo_presses=0;}
    if(!visible)return;
    if(t>=DARP_TRACKS){visible=0;darp_ui_page=DARP_UI_MAIN;return;}
    if(t!=darp_ui_track || changed){
        darp_ui_track=t;selected=0;chord_bank=0;popup_ticks=0;
        darp_ui_page=darp_me_active()?DARP_UI_MELODY:DARP_UI_MAIN;header_ticks=0;
        for(unsigned i=0;i<8;i++)turns[i]=0;
    }else if(darp_ui_page==DARP_UI_MELODY && !darp_me_active())darp_ui_page=DARP_UI_MAIN;
}
/* Same stock Brain::key ABI called by core_key (OS1.54 KEYDISP).
 * A balanced NO pair dismisses the Quantize we opened before overlaying ARP. */
extern int32_t darp_stock_key(void *,void *);

static unsigned source_count(void){
    unsigned count=darp_source==ARP_SOURCE_ABSOLUTE?darp_manual[darp_ui_track].count:darp_chord_count;
    return count?count:1;
}
static unsigned view_base(void){
    if(darp_source==ARP_SOURCE_ABSOLUTE)return 12u*darp_manual[darp_ui_track].octave;
    if(darp_source==ARP_SOURCE_FIXED)return 12u*darp_fixed_octave[darp_ui_track];
    unsigned root=darp_root_valid[darp_ui_track]?darp_root[darp_ui_track]:0;
    return (root/12u)*12u+12u*(unsigned)chord_bank;
}
static void track_label(char *out,const char *label){
    *out++=darp_ui_track<8?'T':'M';*out++=(char)('1'+(darp_ui_track&7u));*out++=' ';
    while(*label)*out++=*label++;
    *out=0;
}
static void dirty(void){if(refresh_controller)((volatile uint8_t *)refresh_controller)[0x20]=1;}
static void number(char *out,int value){
    char r[10];unsigned n=0;
    if(value<0){*out++='-';value=-value;}
    do{r[n++]=(char)('0'+value%10);value/=10;}while(value);
    while(n)*out++=r[--n];
    *out=0;
}
/* Stock DT1 1.54 raw text wrapper at 0x400c2780. Its six-stack-argument
 * ABI is visible in fw_textf, which calls it after formatting. This is a
 * call target, not a new patch site or transplanted Digitone font. */
extern int32_t darp_text_at(void *,const void *,int32_t,int32_t,int32_t,const char *);
extern const uint32_t darp_font_label[];
static int width(const uint32_t *font,const char *s){
    const uint8_t *widths=(const uint8_t *)font[2];int n=0;
    while(*s)n+=widths[(unsigned char)*s++]+1;
    return n?n-1:0;
}
static void text(void *bmp,int x,int y,const char *s){darp_text_at(bmp,darp_font_label,x,y,-1,s);}
static void center(void *bmp,int x,int y,const char *s){text(bmp,x-width(darp_font_label,s)/2,y,s);}
static void small(void *bmp,int x,int y,const char *s){darp_text_at(bmp,fw_font5,x,y,-1,s);}
static void small_center(void *bmp,int x,int y,const char *s){small(bmp,x-width((const uint32_t *)fw_font5,s)/2,y,s);}
static void draw_header(void *bmp,const char *label,const char *help){
    char title[64],line_text[160];track_label(title,label);
    fw_fillrect(bmp,0,58,127,63,0);
    if(!help[0] || header_ticks<90){small_center(bmp,64,58,title);return;}
    unsigned at=0;const char *parts[3]={title," | ",help};
    for(unsigned i=0;i<3;i++){const char *p=parts[i];while(*p && at<sizeof(line_text)-1)line_text[at++]=*p++;}
    line_text[at]=0;int w=width((const uint32_t *)fw_font5,line_text);
    unsigned cycle=(unsigned)(w+20)*3u+60u,phase=(header_ticks-90u)%cycle;
    int offset=phase<60?0:(int)((phase-60u)/3u);
    small(bmp,2-offset,58,line_text);small(bmp,2-offset+w+20,58,line_text);
}

static void nav_clear_turns(void){for(unsigned i=0;i<8;i++)turns[i]=0;popup_ticks=0;header_ticks=0;}
static void nav_main(void){
    if(darp_me_enabled){darp_me_tick();darp_me_toggle();selected=0;}
    darp_ui_page=DARP_UI_MAIN;nav_clear_turns();dirty();
}
static void nav_source(void){
    if(darp_me_imported){darp_me_toggle();darp_me_tick();}
    darp_ui_page=DARP_UI_SOURCE;nav_clear_turns();dirty();
}
static void nav_melody(void){
    if(!darp_me_enabled){
        uint32_t sr=core_audio_irq_save();
        darp_me_wait_source_trigger(darp_ui_track);darp_me_toggle();
        core_audio_irq_restore(sr);
    }
    darp_me_tick();darp_ui_page=DARP_UI_MELODY;nav_clear_turns();dirty();
}
static void dot(void *bmp,int x,int y){fw_fillrect(bmp,x,y,x,y,1);}
static void line(void *bmp,int x0,int y0,int x1,int y1){
    int dx=x1>x0?x1-x0:x0-x1,dy=y1>y0?y0-y1:y1-y0;
    int sx=x0<x1?1:-1,sy=y0<y1?1:-1,error=dx+dy;
    for(unsigned n=0;n<32;n++){
        dot(bmp,x0,y0);if(x0==x1 && y0==y1)break;
        int twice=2*error;if(twice>=dy){error+=dy;x0+=sx;}if(twice<=dx){error+=dx;y0+=sy;}
    }
}
static void dial(void *bmp,unsigned index){
    int x=0,y=8,error=1-y;
    while(x<=y){
        int px[8]={x,-x,x,-x,y,-y,y,-y},py[8]={y,y,-y,-y,x,x,-x,-x};
        for(unsigned i=0;i<8;i++)if(48+py[i]>=43)dot(bmp,112+px[i],48+py[i]);
        ++x;if(error<0)error+=2*x+1;else{--y;error+=2*(x-y)+1;}
    }
    static const int8_t ends[128][2]={{-5,-5},{-5,-5},{-5,-5},{-5,-4},{-6,-4},{-6,-4},{-6,-4},{-6,-4},{-6,-3},{-6,-3},{-6,-3},{-7,-3},{-7,-2},{-7,-2},{-7,-2},{-7,-2},{-7,-1},{-7,-1},{-7,-1},{-7,-1},{-7,0},{-7,0},{-7,0},{-7,0},{-7,1},{-7,1},{-7,1},{-7,2},{-7,2},{-7,2},{-7,2},{-7,2},{-6,3},{-6,3},{-6,3},{-6,3},{-6,4},{-6,4},{-6,4},{-6,4},{-5,5},{-5,5},{-5,5},{-5,5},{-5,5},{-4,5},{-4,6},{-4,6},{-4,6},{-4,6},{-3,6},{-3,6},{-3,6},{-3,6},{-2,7},{-2,7},{-2,7},{-2,7},{-1,7},{-1,7},{-1,7},{-1,7},{0,7},{0,7},{0,7},{0,7},{1,7},{1,7},{1,7},{1,7},{2,7},{2,7},{2,7},{2,7},{3,6},{3,6},{3,6},{3,6},{4,6},{4,6},{4,6},{4,6},{4,5},{5,5},{5,5},{5,5},{5,5},{5,5},{6,4},{6,4},{6,4},{6,4},{6,3},{6,3},{6,3},{6,3},{7,2},{7,2},{7,2},{7,2},{7,2},{7,1},{7,1},{7,1},{7,0},{7,0},{7,0},{7,0},{7,-1},{7,-1},{7,-1},{7,-1},{7,-2},{7,-2},{7,-2},{7,-2},{7,-3},{6,-3},{6,-3},{6,-3},{6,-4},{6,-4},{6,-4},{6,-4},{5,-4},{5,-5},{5,-5},{5,-5}};
    if(index>127)index=127;
    line(bmp,112,48,112+ends[index][0],48+ends[index][1]);
}
static void keyboard(void *bmp){
    char value[16];fw_fillrect(bmp,29,1,29,31,1);
    for(int x=2;x<29;x+=2)dot(bmp,x,15);
    small_center(bmp,15,26,"EUCL(E)");
    small_center(bmp,15,9,"ROT (F)");
    if(rhythm.pulses==255){center(bmp,15,18,"OFF");center(bmp,15,1,"--");}
    else{
        number(value,rhythm.pulses);unsigned n=0;while(value[n])++n;
        value[n++]='/';number(value+n,darp_length);center(bmp,15,18,value);
        value[0]='+';number(value+1,rhythm.rotation);center(bmp,15,1,value);
    }
}

static unsigned selected_velocity(void){return darp_me_velocity[selected]?darp_me_velocity[selected]:100;}
static void turn_velocity(int delta){
    if(delta>64)delta=64;
    if(delta< -64)delta=-64;
    turns[0]+=delta;
    while(turns[0]>=16 || turns[0]<=-16){
        int step=turns[0]>0?1:-1;turns[0]-=16*step;
        uint32_t sr=core_audio_irq_save();
        if(darp_effective_mask(darp_ui_track)&(1u<<selected)){
            int value=(int)selected_velocity()+step;
            if(value>=1 && value<=127){darp_me_velocity[selected]=(uint8_t)value;++darp_controls[darp_ui_track].revision;}
        }
        core_audio_irq_restore(sr);
    }
    popup_knob=0;popup_ticks=30;dirty();
}
static void paint(void *bmp){
    const char *modes[]={"TRUE","UP","DOWN","CYCL","RND","SHUF"};
    const char *speeds[]={"1/1","1/2","1/3","1/4","1/5","1/6","1/8","1/10","1/12","1/16","1/20","1/24","1/32","1/40","1/48","1/64","1/80","1/96"};
    darp_options o=darp_decode(darp_settings);char n[12];
    unsigned imported=darp_me_imported;
    fw_fillrect(bmp,0,0,127,63,0);
    if(imported){
        if(darp_effective_mask(darp_ui_track)&(1u<<selected)){number(n,(int)selected_velocity());center(bmp,16,48,n);}
        else center(bmp,16,48,"--");
    }else center(bmp,16,48,darp_enabled?modes[o.mode]:"OFF");
    center(bmp,48,48,speeds[o.rate]);number(n,imported?(int)darp_me_filter():(int)o.range);center(bmp,80,48,imported && darp_ui_track>=8?"--":n);
    center(bmp,16,37,imported?"VEL":"MODE");center(bmp,48,37,"SPEED");center(bmp,80,37,imported?(darp_ui_track<8?"FILT":"--"):"OCT");center(bmp,112,37,"PROB");
    dial(bmp,(rhythm.probability*127u+50u)/100u);
    /* The reference editor has squared borders and dotted length bounds. */
    fw_fillrect(bmp,0,0,127,0,1);fw_fillrect(bmp,0,32,127,32,1);
    fw_fillrect(bmp,0,0,0,32,1);fw_fillrect(bmp,127,0,127,32,1);fw_fillrect(bmp,100,0,100,32,1);
    /* Open corner pixels and the native dotted LEN/OFS separator. */
    fw_fillrect(bmp,0,0,0,0,0);fw_fillrect(bmp,127,0,127,0,0);
    fw_fillrect(bmp,0,32,0,32,0);fw_fillrect(bmp,127,32,127,32,0);
    for(int x=102;x<127;x+=2)dot(bmp,x,15);
    for(int y=1;y<32;y+=2){dot(bmp,29,y);if(y>=7)dot(bmp,33+4*darp_length,y);}
    keyboard(bmp);
    int low=-20,high=20;
    if(darp_me_imported){
        low=high=0;
        for(unsigned i=0;i<darp_length;i++)if(darp_effective_mask(darp_ui_track)&(1u<<i)){
            if(darp_offsets[i]<low)low=darp_offsets[i];
            if(darp_offsets[i]>high)high=darp_offsets[i];
        }
        if(low==high){--low;++high;}
    }
    unsigned playhead=imported && darp_me_player.running?darp_me_player.position:16;
    for(unsigned i=0;i<16;i++){
        int x=33+4*(int)i;
        int y=darp_me_imported?9+20*((int)darp_offsets[i]-low)/(high-low):19+darp_offsets[i]/2;
        if(y<9)y=9;
        if(y>29)y=29;
        if(i<darp_length){
            if(darp_me_imported && (darp_effective_mask(darp_ui_track)&(1u<<i)) && darp_me_span[i]>1){
                unsigned until=i+darp_me_span[i];if(until>darp_length)until=darp_length;
                fw_fillrect(bmp,x+2,y,33+4*(int)until-2,y,1);
            }
            int radius=i==selected?2:1;
            if(darp_effective_mask(darp_ui_track)&(1u<<i)){
                fw_fillrect(bmp,x+1-radius,y-radius,x+1+radius,y+radius,1);
                if(darp_offsets[i])fw_fillrect(bmp,x+2-radius,y+1-radius,x+radius,y+radius-1,0);
            }else fw_fillrect(bmp,x,y,x+2,y,1);
            if(i==selected){
                fw_fillrect(bmp,x,1,x+2,2,1);
            }else{
                fw_fillrect(bmp,x,1,x+2,3,1);fw_fillrect(bmp,x+1,2,x+1,2,0);
            }
        }else dot(bmp,x+1,2);
        if(i==playhead)fw_fillrect(bmp,x,5,x+2,5,1);
    }
    small(bmp,102,26,"LEN (G)");number(n,darp_length);small_center(bmp,114,19,n);
    small(bmp,102,9,"OFS (H)");number(n,darp_offsets[selected]);small_center(bmp,114,2,n);
}
/* Two C-to-C octaves (25 pitches, 15 white keys). Native page fonts and pitch mapping are retained.
 * The larger 22px keybed uses the space released by the removed footer. Physical input remains one bank
 * at a time; G OCT selects that bank for CUSTOM/FIXED. */
static void chord_keyboard(void *bmp,const uint8_t *notes,unsigned count,unsigned base){
    static const uint8_t white[15]={0,2,4,5,7,9,11,12,14,16,17,19,21,23,24};
    static const uint8_t black[10]={1,3,6,8,10,13,15,18,20,22};
    static const uint8_t boundary[10]={1,2,4,5,6,8,9,11,12,13};
    uint32_t active=0;
    unsigned octaves=darp_decode(darp_settings).range;
    for(unsigned octave=0;octave<octaves;octave++)for(unsigned i=0;i<count;i++){
        unsigned note=notes[i]+12u*octave;
        if(note<=127 && note>=base && note-base<=24u)active|=1u<<(note-base);
    }
    for(unsigned slot=0;slot<15;slot++){
        int x=4+8*(int)slot;
        fw_fillrect(bmp,x,18,x+7,39,1);
        if(!(active&(1u<<white[slot])))fw_fillrect(bmp,x+1,19,x+6,38,0);
    }
    /* One black pixel separates adjacent filled white keys. */
    for(unsigned slot=1;slot<15;slot++){
        int x=4+8*(int)slot-1;fw_fillrect(bmp,x,18,x,39,0);
    }
    for(unsigned key=0;key<10;key++){
        int x=4+8*(int)boundary[key]-2;
        fw_fillrect(bmp,x-1,26,x+4,39,0);
        fw_fillrect(bmp,x,27,x+3,39,1);
        if(!(active&(1u<<black[key])))fw_fillrect(bmp,x+1,28,x+2,38,0);
    }
}
static const char *key_names[]={"OFF","C","C#","D","D#","E","F","F#","G","G#","A","A#","B"};
static const char *source_modes[]={"TRUE","UP","DOWN","CYCL","RANDOM","SHUFFLE"};
static void paint_notes(void *bmp){
    uint8_t notes[16];int count;char n[12];
    unsigned custom=darp_source==ARP_SOURCE_ABSOLUTE;
    if(custom){
        arp_manual_notes manual=darp_manual[darp_ui_track];count=arp_manual_copy(&manual,notes);
        if(!count && darp_root_valid[darp_ui_track]){notes[0]=(uint8_t)darp_root[darp_ui_track];count=1;}
    }
    else{
        int8_t offsets[16];count=arp_pitch_set(darp_preset,darp_chord_count,offsets);
        if(count>0){unsigned root=darp_source==ARP_SOURCE_FIXED?darp_fixed_root[darp_ui_track]:(darp_root_valid[darp_ui_track]?darp_root[darp_ui_track]:0);
            count=arp_chord_resolve(root,offsets,(unsigned)count,notes);}
    }
    if(darp_source==ARP_SOURCE_FIXED && darp_key[darp_ui_track])count=arp_scale_pool(darp_key[darp_ui_track]-1,darp_preset,darp_fixed_root[darp_ui_track],darp_chord_count,notes);
    fw_fillrect(bmp,0,0,127,63,0);
    if(count<0){center(bmp,64,30,"INVALID SOURCE");return;}
    darp_options o=darp_decode(darp_settings);
    draw_header(bmp,(darp_me_enabled || darp_me_imported)?"NOTE SOURCE ME":"NOTE SOURCE","");
    small_center(bmp,16,50,"A SOURCE");small_center(bmp,48,50,"B SCALE");
    small_center(bmp,80,50,"C OCT");small_center(bmp,112,50,"D NOTES");
    small_center(bmp,16,42,custom?"CUSTOM":darp_source==ARP_SOURCE_FIXED?"FIXED":"TRIG");
    small_center(bmp,48,42,custom?(darp_manual[darp_ui_track].count?"KEYS":"TRIG"):arp_pitch_set_name(darp_preset));
    number(n,(int)((darp_me_enabled || darp_me_imported)?darp_me_knobs[2]:o.range));small_center(bmp,80,42,n);
    number(n,(int)source_count());small_center(bmp,112,42,n);
    chord_keyboard(bmp,notes,(unsigned)count,view_base());
    small_center(bmp,16,8,"E KEY");small_center(bmp,48,8,"F MODE");small_center(bmp,80,8,(custom || darp_source==ARP_SOURCE_FIXED)?"G OCT":"G VIEW");
    small_center(bmp,112,8,darp_ui_track<8?"H FILT":"H --");
    center(bmp,16,0,darp_source==ARP_SOURCE_FIXED?key_names[darp_key[darp_ui_track]]:"--");small_center(bmp,48,1,(darp_me_enabled || darp_me_imported)?"ME":darp_enabled?source_modes[o.mode]:"OFF");
    number(n,custom?darp_manual[darp_ui_track].octave:darp_source==ARP_SOURCE_FIXED?darp_fixed_octave[darp_ui_track]:chord_bank);center(bmp,80,0,n);
    if(darp_ui_track<8){number(n,(int)darp_me_filter());center(bmp,112,0,n);}else center(bmp,112,0,"--");
}
/* Independent modal overlay through core's existing events. The tick's
 * controller+0x20 dirty byte is documented by core/core.s. No view list,
 * parameter storage or stock Quantize handler is patched. */
static int paint_print(void *bmp){
 unsigned phase=darp_print.phase;
 if(!darp_print_ui_error && phase!=ARP_PRINT_ARMED && phase!=ARP_PRINT_RECORDING && phase!=ARP_PRINT_READY && phase!=ARP_PRINT_ERROR && phase!=ARP_PRINT_PENDING && phase!=ARP_PRINT_PREPARED && phase!=ARP_PRINT_QUEUED)return 0;
 char n[24];fw_fillrect(bmp,0,0,127,63,0);center(bmp,64,57,"ARP TO TRIGS");
 number(n,(int)darp_print_track+1);small(bmp,5,44,"TRACK");small(bmp,36,44,n);
 const char *a="",*b="",*c="NO: CANCEL";
 if(darp_print_ui_error){
  switch(darp_print_ui_error){
   case 1:a="NO SOURCE TRIG";break;case 2:a="NO SOURCE TRIG";break;
   case 3:a="SOURCE MICRO = 0";break;case 4:a="PLAY + ARP ON";break;
   case 5:a="CONTEXT CHANGED";break;case 6:a="LEN NOT EXACT";break;
   case 7:a="STOP THEN YES";break;case 9:a="AUDIO QUEUE FULL";break;default:a="ARP LFO ACTIVE";break;
  }
 }else if(phase==ARP_PRINT_ERROR){
  switch(darp_print.error){
   case ARP_PRINT_GRID:a="NOT ON STEP GRID";b="USE SPEED 1/16";break;
   case ARP_PRINT_COLLISION:a="TWO NOTES ONE STEP";break;
   case ARP_PRINT_EMPTY:a="NO NOTES CAPTURED";break;
   case ARP_PRINT_STOPPED:a="CAPTURE STOPPED";break;
   default:a="CONTEXT CHANGED";break;
  }
 }else if(phase==ARP_PRINT_ARMED){
  a="WAIT NEXT LOOP";number(n,(int)darp_print.steps);
  unsigned i=0;while(n[i])++i;const char *suffix=" STEPS / 1 LOOP";
  while(*suffix && i<sizeof(n)-1){n[i++]=*suffix++;}
  n[i]=0;b=n;
 }
 else if(phase==ARP_PRINT_RECORDING){a="CAPTURING NOTES";number(n,(int)darp_print.count);b=n;}
 else if(phase==ARP_PRINT_PENDING){a="PRINT QUEUED";b="NEXT PATTERN LOOP";c="NO: CANCEL";}
 else if(phase==ARP_PRINT_PREPARED || phase==ARP_PRINT_QUEUED){a="SWITCHING TO TRIGS";b="SEQUENCER KEEPS PLAYING";c="";}
 else if(darp_print_confirm){a="REPLACE TRIGS?";b="YES: PRINT / NO: BACK";c="NEXT LOOP / ARP OFF";}
 else {a="CAPTURE READY";b="YES: PRINT LIVE";}
 small_center(bmp,64,32,a);small_center(bmp,64,21,b);small_center(bmp,64,7,c);return 1;
}
static void melody_dial(void *bmp,int cx,int cy,unsigned value,unsigned maximum){
    static const int8_t points[17][2]={{-4,-4},{-5,-3},{-6,-1},{-6,1},{-5,3},{-4,4},{-3,5},{-1,6},{0,6},{1,6},{3,5},{4,4},{5,3},{6,1},{6,-1},{5,-3},{4,-4}};
    for(unsigned i=1;i<17;i++)line(bmp,cx+points[i-1][0],cy+points[i-1][1],cx+points[i][0],cy+points[i][1]);
    unsigned at=maximum?value*16/maximum:0;if(at>16)at=16;
    line(bmp,cx,cy,cx+points[at][0],cy+points[at][1]);
}
/* Fixed title fits the central 66px window with the native small font.
 * Errors retain their existing visible feedback in this area. */
static void melody_footer(void *bmp){
    char title[64];track_label(title,"MELODY ENGINE");
    if(darp_me_error){
        char error[16]="ME ERROR ";number(error+9,(int)darp_me_error);small_center(bmp,64,1,error);
    }else small_center(bmp,64,1,title);
    fw_fillrect(bmp,0,0,30,7,0);fw_fillrect(bmp,97,0,127,7,0);
}
static void melody_side_dial(void *bmp,int cx,int cy,unsigned value){
    static const int8_t points[10][2]={{-3,-3},{-4,-1},{-4,1},{-3,3},{-1,4},{1,4},{3,3},{4,1},{4,-1},{3,-3}};
    for(unsigned i=1;i<10;i++)line(bmp,cx+points[i-1][0],cy+points[i-1][1],cx+points[i][0],cy+points[i][1]);
    unsigned at=value*9u/127u;if(at>9)at=9;
    line(bmp,cx,cy,cx+points[at][0],cy+points[at][1]);
}
static void paint_melody(void *bmp){
    fw_fillrect(bmp,0,0,127,63,0);melody_footer(bmp);
    static const char *const names[4]={"A RHY","B MOT","C OCT","D PRESET"};
    char n[12];
    for(unsigned i=0;i<4;i++){
        int x=16+32*(int)i;small_center(bmp,x,58,names[i]);
        unsigned v=darp_me_knobs[i==3?5:i];melody_dial(bmp,x,51,i==2?v-1:v,i==2?3:i==3?MELODY_PRESETS-1:127);
        if(i==3){
            char label[8];const char *name=melody_preset_name(v);unsigned at=0;
            while(*name)label[at++]=*name++;
            if(darp_me_preset_custom())label[at++]='*';
            label[at]=0;small_center(bmp,x,41,label);
        }else{number(n,(int)v);small_center(bmp,x,41,n);}
    }
    fw_fillrect(bmp,0,39,127,39,1);fw_fillrect(bmp,30,0,30,39,1);fw_fillrect(bmp,97,0,97,39,1);
    fw_fillrect(bmp,31,8,96,8,1);
    small_center(bmp,15,32,"FREEZE");small_center(bmp,2,23,"F");
    fw_fillrect(bmp,7,21,27,29,1);fw_fillrect(bmp,8,22,26,28,0);
    unsigned frozen=!darp_me_knobs[4];int switch_x=frozen?23:9;
    fw_fillrect(bmp,switch_x,23,switch_x+2,27,1);small_center(bmp,frozen?17:19,23,frozen?"ON":"OFF");
    small_center(bmp,15,14,"E VAR");melody_side_dial(bmp,7,6,darp_me_knobs[7]*127u/5u);
    number(n,(int)darp_me_knobs[7]+1);small_center(bmp,22,3,n);
    small_center(bmp,113,32,"G RISE");melody_side_dial(bmp,104,24,darp_me_knobs[6]);
    number(n,(int)darp_me_knobs[6]);small_center(bmp,119,21,n);
    unsigned freq=darp_me_filter();small_center(bmp,113,14,darp_ui_track<8?"H FREQ":"H --");if(darp_ui_track<8)melody_side_dial(bmp,104,6,freq);
    number(n,(int)freq);small_center(bmp,119,3,darp_ui_track<8?n:"--");
    uint32_t sr=core_audio_irq_save();
    melody_phrase phrase=darp_me_player.running?darp_me_player.phrase:darp_me_stage;
    unsigned running=darp_me_player.running;
    unsigned head_position=darp_me_player.position;
    core_audio_irq_restore(sr);
    for(int x=32;x<=80;x+=16)for(int y=15;y<37;y+=3)dot(bmp,x,y);
    int low=60,high=60;
    if(phrase.count){low=high=phrase.event[0].note;
        for(unsigned i=1;i<phrase.count;i++){
            if(phrase.event[i].note<low)low=phrase.event[i].note;
            if(phrase.event[i].note>high)high=phrase.event[i].note;
        }
    }
    low-=2;high+=2;
    for(unsigned i=0;i<phrase.count;i++){
        melody_event v=phrase.event[i];int x=32+4*(int)v.step,y=15+20*((int)v.note-low)/(high-low);
        fw_fillrect(bmp,x,y-1,x+2,y+1,1);
        unsigned end=v.step+v.span;if(end>16)end=16;
        if(v.span>1)fw_fillrect(bmp,x+2,y,32+4*(int)end-2,y,1);
    }
    unsigned cursor=running?head_position:16;
    for(unsigned i=0;i<16;i++){
        int x=33+4*(int)i;
        if(i==cursor)fw_fillrect(bmp,x-1,10,x+1,12,1);else dot(bmp,x,10);
    }
    if(cursor<16){int x=33+4*(int)cursor;dot(bmp,x,37);fw_fillrect(bmp,x-1,38,x+1,38,1);}
}
void darp_ui_overlay(void *bmp,void *controller){
    refresh_controller=controller;
    if(!visible || bank_held || pattern_held)return;
    int project_error=pd_project_error?pd_project_error:darp_project_error;
    if(project_error<0){
        fw_fillrect(bmp,0,0,127,63,0);char code[16]="ERROR ";number(code+6,project_error);
        small_center(bmp,64,40,"PROJECT DATA");small_center(bmp,64,28,code);
        small_center(bmp,64,14,"RELOAD PROJECT");small_center(bmp,64,2,"NO: EXIT");return;
    }
    if(paint_print(bmp))return;
    if(lfo_editor && darp_ui_track<8)return;
    if(notes_page){paint_notes(bmp);return;}
    if(darp_ui_page==DARP_UI_MELODY){paint_melody(bmp);return;}
    paint(bmp);fw_fillrect(bmp,0,58,127,63,0);
    char title[40],n[12],heading[40];track_label(heading,darp_me_imported?"DIGIARP ME":"DIGIARP");const char *name=heading,*value=0;
    darp_options o=darp_decode(darp_settings);
    if(darp_print.phase==ARP_PRINT_DONE && darp_print_track==darp_ui_track){track_label(heading,"PRINTED F+STOP UNDO");name=heading;}
    if(popup_ticks){
        const char *modes[]={"TRUE","UP","DOWN","CYCLE","RANDOM","SHUFFLE"};
        if(popup_knob==0){
            if(darp_me_imported){
                name="VELOCITY: ";if(darp_effective_mask(darp_ui_track)&(1u<<selected)){number(n,(int)selected_velocity());value=n;}else value="--";
            }else{name="MODE: ";value=darp_enabled?modes[o.mode]:"OFF";}
        }
        else if(popup_knob==1){
            name="SPEED: ";n[0]='1';n[1]='/';number(n+2,(int)(7680/darp_periods[o.rate]));value=n;
        }else if(popup_knob==2){unsigned imported=darp_me_imported;name=imported?"FILTER: ":"OCTAVES: ";number(n,imported?(int)darp_me_filter():(int)o.range);value=n;}
        else if(popup_knob==3){name="PROBABILITY: ";number(n,rhythm.probability);unsigned j=0;while(n[j])++j;n[j++]='%';n[j]=0;value=n;}
        else if(popup_knob==4){name="EUCLID: ";if(rhythm.pulses==255)value="OFF";else{number(n,rhythm.pulses);unsigned j=0;while(n[j])++j;n[j++]='/';number(n+j,darp_length);value=n;}}
        else if(popup_knob==5){name="ROTATION: ";number(n,rhythm.rotation);value=n;}
        else if(popup_knob==6){name="ARP LENGTH: ";number(n,darp_length);value=n;}
        else {name="OFFSET: ";number(n,darp_offsets[selected]);value=n;}
    }
    unsigned i=0;while(*name && i<sizeof(title)-1)title[i++]=*name++;
    if(value)while(*value && i<sizeof(title)-1)title[i++]=*value++;
    title[i]=0;
    if(popup_ticks)small_center(bmp,64,58,title);
    else if(darp_print.phase==ARP_PRINT_DONE && darp_print_track==darp_ui_track)draw_header(bmp,"PRINTED","FUNC+REC: PHRASE TO TRIGS");
    else draw_header(bmp,darp_me_imported?"DIGIARP ME":"DIGIARP","FUNC+REC: PHRASE TO TRIGS");
}
void darp_ui_tick(void *controller){
    if(lfo_expected && lfo_seen && lfo_brain && fw_active_track<8){
        unsigned mismatch=lfo_expected!=lfo_seen;
        lfo_expected=lfo_seen=0;
        if(mismatch){
            uint32_t key[5]={0,0,0,23,1};
            darp_stock_key(lfo_brain,key);key[4]=16;darp_stock_key(lfo_brain,key);
        }
    }
    refresh_controller=controller;darp_print_ui_tick();darp_me_tick_all();follow_track();if(popup_ticks)--popup_ticks;
    if(visible)++header_ticks;else header_ticks=0;
    if(visible && ++refresh_ticks>=3){refresh_ticks=0;dirty();}
}
static int32_t key(void *view,void *event){
    (void)view;const uint32_t *e=event;uint32_t k=e[3],flags=e[4];
    if(k<14 || k>17)return 0;
    if((flags&1u) || (flags&8u)){
        uint32_t sr=core_audio_irq_save();
        if((k==14 || k==15) && rhythm.pulses!=255){
            darp_mask=darp_effective_mask(darp_ui_track);rhythm.pulses=255;
        }
        if(k==16 && selected)--selected;
        else if(k==17 && selected+1u<darp_length)++selected;
        else if(k==14)darp_mask|=(uint16_t)(1u<<selected);
        else if(k==15)darp_mask&=(uint16_t)~(1u<<selected);
        ++darp_revision;core_audio_irq_restore(sr);dirty();
    }
    return 1; /* consume release too, avoid native underlying arrow actions */
}
static int32_t enc(void *view,void *event){
    (void)view;const int32_t *e=event;if(e[3]<1 || e[3]>8)return 1;
    unsigned knob=(unsigned)e[3]-1;int32_t delta=e[4];
    if(delta>64)delta=64;
    if(delta< -64)delta= -64;
    turns[knob]+=delta;
    while(turns[knob]>=16 || turns[knob]<=-16){
        int step=turns[knob]>0?1:-1;turns[knob]-=16*step;
        uint32_t sr=core_audio_irq_save();darp_options o=darp_decode(darp_settings);
        if(knob==0){
            unsigned me=(darp_me_enabled || darp_me_imported);
            unsigned mode=me?7u:darp_enabled?o.mode+1u:0u;
            unsigned maximum=darp_me_saved?7u:6u;
            if(step>0){if(mode==7)mode=1;else if(mode<maximum)++mode;}
            else if(mode)--mode;
            if(mode==7){
                if(!me){darp_me_toggle();darp_me_tick();o=darp_decode(darp_settings);}
            }else{
                if(me){darp_me_leave();o=darp_decode(darp_settings);}
                darp_enabled=mode!=0;o.mode=mode?mode-1:0;
            }
        }else if(knob==1){if(step>0 && o.rate<17)++o.rate;else if(step<0 && o.rate)--o.rate;}
        else if(knob==2){if(step>0 && o.range<8)++o.range;else if(step<0 && o.range>1)--o.range;}
        else if(knob==3){int v=(int)rhythm.probability+step;if(v>=0 && v<=100)rhythm.probability=(uint8_t)v;}
        else if(knob==4){int v=rhythm.pulses==255?-1:rhythm.pulses;v+=step;if(v>=-1 && v<=(int)darp_length)rhythm.pulses=v<0?255:(uint8_t)v;}
        else if(knob==5){int v=(int)rhythm.rotation+step;if(v<0)v=(int)darp_length-1;if(v>=(int)darp_length)v=0;rhythm.rotation=(uint8_t)v;}
        else if(knob==6){if(step>0 && darp_length<16)++darp_length;else if(step<0 && darp_length>1)--darp_length;
            if(rhythm.pulses!=255 && rhythm.pulses>darp_length)rhythm.pulses=darp_length;
            rhythm.rotation=(uint8_t)(rhythm.rotation%darp_length);selected=(uint8_t)(darp_length-1);}
        else if(knob==7){if(step>0 && darp_offsets[selected]<63)++darp_offsets[selected];else if(step<0 && darp_offsets[selected]>-64)--darp_offsets[selected];}
        darp_settings=darp_pack(o);popup_knob=knob;popup_ticks=30;++darp_revision;core_audio_irq_restore(sr);dirty();
    }
    return 1;
}
static int32_t global_enc_impl(void *brain,void *event){
    (void)brain;follow_track();if(!visible)return 0;
    const int32_t *raw=event;
    if(raw[3]<1 || raw[3]>8 || track_held || bank_held || pattern_held)return 0;
    if(lfo_editor && darp_ui_track<8){
        darp_lfo_ui_scope=1;
        ((void (*)(void *,void *))0x40008550)(brain,event);
        darp_lfo_ui_scope=0;
        dirty();return 1;
    }

    if(darp_ui_page==DARP_UI_MAIN && darp_me_imported && raw[3]==1){turn_velocity(raw[4]);return 1;}
    if(darp_ui_page==DARP_UI_MAIN && darp_me_imported && raw[3]==3){
        darp_me_turn(7,raw[4]);popup_knob=2;popup_ticks=30;dirty();return 1;
    }
    if(darp_ui_page==DARP_UI_MELODY){darp_me_turn((unsigned)raw[3]-1,raw[4]);dirty();return 1;}
    if(!notes_page)return enc(0,event);
    if(raw[3]==8){darp_me_turn(7,raw[4]);dirty();return 1;}
    const int32_t *e=event;
    if(e[3]<1 || e[3]>7)return 1;
    if(e[3]==3 && (darp_me_enabled || darp_me_imported)){
        darp_me_turn(2,e[4]);darp_me_tick();dirty();return 1;
    }
    unsigned knob=(unsigned)e[3]-1u;int delta=e[4];
    if(delta>64)delta=64;
    if(delta< -64)delta= -64;
    turns[knob]+=delta;
    while(turns[knob]>=16 || turns[knob]<=-16){
        int step=turns[knob]>0?1:-1;turns[knob]-=step*16;
        uint32_t sr=core_audio_irq_save();darp_options o=darp_decode(darp_settings);
        if(knob==0){
            int source=(int)darp_source;
            if(source<3 || source>5)source=3;
            source+=step;if(source>=3 && source<=5)darp_source=(uint8_t)source;
        }else if(knob==1 && darp_source!=ARP_SOURCE_ABSOLUTE){
            int v=(int)darp_preset+step;if(v>=0 && v<(int)ARP_PITCH_SETS)darp_preset=(uint8_t)v;
        }else if(knob==2){
            if(step>0 && o.range<8)++o.range;else if(step<0 && o.range>1)--o.range;
        }else if(knob==3 && darp_source!=ARP_SOURCE_ABSOLUTE){
            int v=(int)darp_chord_count+step;if(v>=1 && v<=16)darp_chord_count=(uint8_t)v;
        }else if(knob==4 && darp_source==ARP_SOURCE_FIXED){int v=(int)darp_key[darp_ui_track]+step;if(v>=0 && v<=12)darp_key[darp_ui_track]=(uint8_t)v;}
        else if(knob==5){
            unsigned me=(darp_me_enabled || darp_me_imported);
            unsigned mode=me?7u:darp_enabled?o.mode+1u:0u;
            unsigned maximum=darp_me_saved?7u:6u;
            if(step>0){if(mode==7)mode=1;else if(mode<maximum)++mode;}
            else if(mode)--mode;
            if(mode==7){
                if(!me){darp_me_toggle();darp_me_tick();o=darp_decode(darp_settings);}
            }else{
                if(me){darp_me_leave();o=darp_decode(darp_settings);}
                darp_enabled=mode!=0;o.mode=mode?mode-1:0;
            }
        }
        else if(knob==6){
            if(darp_source==ARP_SOURCE_ABSOLUTE){int v=darp_manual[darp_ui_track].octave+step;if(v>=0 && v<=10)darp_manual[darp_ui_track].octave=(uint8_t)v;}
            else if(darp_source==ARP_SOURCE_FIXED){int v=darp_fixed_octave[darp_ui_track]+step;if(v>=0 && v<=10)darp_fixed_octave[darp_ui_track]=(uint8_t)v;}
            else{int v=chord_bank+step;if(v>=0 && v<=10)chord_bank=v;}
        }
        darp_settings=darp_pack(o);++darp_revision;
        core_audio_irq_restore(sr);dirty();
    }
    return 1;
}
static int32_t global_key_impl(void *brain,void *event){
    (void)brain;const uint32_t *e=event;uint32_t k=e[3],flags=e[4];
    unsigned down=flags&1u;
    uint32_t blocker=k>=5 && k<=8?1u<<(k-5):k>=18 && k<=39?1u<<(k-14):0;
    if(blocker){if(down)clear_blockers|=blocker;else clear_blockers&=~blocker;}
    /* Let the stock key handler perform its exact clear operation. Skip
     * page/pattern/pad clear chords; only the unqualified FUNC+PLAY chord
     * resets the active track's DigiArp settings. Never consume either edge. */
    if(!lfo_editor && k==10 && down && (flags&2u) && !(flags&8u) && !clear_blockers && !bank_held && !pattern_held){
        unsigned track=fw_active_track;
        if(track<DARP_TRACKS){
            darp_clear_track(track);
            return_page[track]=DARP_UI_MAIN;
            if(darp_ui_track==track){selected=0;popup_ticks=0;darp_ui_page=DARP_UI_MAIN;chord_bank=0;for(unsigned i=0;i<8;i++)turns[i]=0;}
            dirty();
        }
        return 0;
    }
    /* Leave the native LFO page on its second bank while displaying LFO 3.
     * Returning the fourth press to stock then selects its first bank. */
    if(k==23 && down && !(flags&10u))lfo_brain=brain;
    if(k==23 && lfo_key_owned){
        if(!down)lfo_key_owned=0;
        return 1;
    }
    if(k==23 && down && !(flags&(2u|8u)) && fw_active_track<8 &&
       !track_held && !bank_held && !pattern_held){
        if(lfo_editor){
            lfo_editor=0;visible=0;lfo_presses=1;lfo_expected=1;lfo_seen=0;dirty();return 0;
        }
        if(++lfo_presses==3){
            lfo_expected=lfo_seen=0;
            darp_ui_track=fw_active_track;lfo_editor=1;visible=1;lfo_key_owned=1;
            /* The Brain caches the short page title on a native page change.
             * Revisit the same native bank before the next frame so both the
             * title and its counter are rebuilt with LFO 3 selected. */
            if(brain){
                uint32_t refresh[5];for(unsigned i=0;i<5;i++)refresh[i]=e[i];
                for(unsigned i=0;i<2;i++){
                    refresh[4]=1;darp_stock_key(brain,refresh);
                    refresh[4]=16;darp_stock_key(brain,refresh);
                }
            }
            nav_clear_turns();dirty();return 1;
        }
        lfo_expected=lfo_presses;lfo_seen=0;
    }else if(down && !(flags&8u) && ((k>=5 && k<=8) || (k>=19 && k<=23) || fw_active_track>=8)){
        lfo_expected=lfo_seen=lfo_presses=0;
        if(lfo_editor){lfo_editor=0;visible=0;dirty();}
    }
    if(lfo_editor && k==19 && (flags&2u) && down){lfo_editor=0;visible=0;}
    if(lfo_editor && !(k==19 && (flags&2u))){
        darp_lfo_ui_scope=1;darp_stock_key(brain,event);darp_lfo_ui_scope=0;
        dirty();return 1;
    }
    if(print_owned_key==k){if(!down)print_owned_key=0;return 1;}
    if((darp_print.phase==ARP_PRINT_PENDING || darp_print.phase==ARP_PRINT_PREPARED || darp_print.phase==ARP_PRINT_QUEUED) && (flags&2u) && (k==12 || k==13)){
        if(down)print_owned_key=k;
        return 1;
    }
    if(k==2)track_held=down;
    if(k==3)pattern_held=down;
    if(k==4)bank_held=down;
    follow_track();
    /* A key keeps its owner until release, even if RECORD/modifiers/page
     * changes in between. Native keys keep their native release as well. */
    if(k>=24 && k<=39){
        uint16_t bit=(uint16_t)(1u<<(k-24));
        if(owned_pads&bit){if(!down)owned_pads&=(uint16_t)~bit;return 1;}
        if(!down || (flags&8u))return 0;
    }
    /* Panel repeats carry pressed as well. Toggle actions run once per
     * physical press; arrows retain their normal repeat behaviour. */
    if((flags&8u) && !(k>=14 && k<=17)){
        if((visible && (k==12 || k==13 || (k>=40 && k<=47))) || (k==19 && (flags&2u)) || (k==13 && exit_release))return 1;
        return 0;
    }
    if(k==19 && down && (flags&2u)){
        if(!visible){
            unsigned track=fw_active_track;
            if(track>=DARP_TRACKS){quantize_opened=0;return 0;}
            darp_ui_track=track;selected=0;chord_bank=0;
        }
        if(!visible && quantize_opened){
            uint32_t close[5];for(unsigned i=0;i<5;i++)close[i]=e[i];
            close[3]=13;close[4]=1;darp_stock_key(brain,close);
            close[4]=16;darp_stock_key(brain,close);quantize_opened=0;
        }
        if(visible)remember_page();
        lfo_editor=0;visible=!visible;shortcut_release=visible?1:2;popup_ticks=0;
        if(!visible)quantize_opened=1;
        else{
            darp_ui_page=return_page[darp_ui_track];
            if(darp_ui_page>DARP_UI_MELODY || (darp_ui_page==DARP_UI_MELODY && !darp_me_active()))darp_ui_page=DARP_UI_MAIN;
            /* A loaded active generator may have no remembered UI page yet. */
            if(darp_ui_page==DARP_UI_MAIN && darp_me_active())darp_ui_page=DARP_UI_MELODY;
        }
        nav_clear_turns();
        dirty();return visible?1:0; /* second chord follows native Quantize */
    }
    if(k==19 && !down && shortcut_release){unsigned taken=shortcut_release==1;shortcut_release=0;return (int32_t)taken;}
    if(k==13 && !down && exit_release){exit_release=0;return 1;}
    if(!visible){
        if(down && (k==13 || k==2 || k==18 || (k>=3 && k<=8) || (k>=20 && k<=23)))quantize_opened=0;
        return 0;
    }
    if(k>=40 && k<=47 && down && !(flags&2u) && darp_ui_page==DARP_UI_MELODY){
        darp_me_action(k-40);dirty();return 1;
    }
    if(k==9 && down && (flags&2u)){
        print_owned_key=k;
        if(darp_me_active()){darp_me_error=4;dirty();return 1;}
        if(darp_print.phase==ARP_PRINT_PENDING || darp_print.phase==ARP_PRINT_PREPARED || darp_print.phase==ARP_PRINT_QUEUED)return 1;
        if(darp_print.phase==ARP_PRINT_ARMED || darp_print.phase==ARP_PRINT_RECORDING)darp_print_cancel();
        else (void)darp_print_arm(darp_ui_track);
        dirty();return 1;
    }
    if(k==11 && down && (flags&2u) && darp_print.phase==ARP_PRINT_DONE){print_owned_key=k;if(darp_print_track==darp_ui_track)(void)darp_print_undo();else darp_print_ui_error=5;dirty();return 1;}
    if(!(flags&2u) && (k==12 || k==13) && (darp_print_ui_error || darp_print.phase==ARP_PRINT_ARMED || darp_print.phase==ARP_PRINT_RECORDING || darp_print.phase==ARP_PRINT_READY || darp_print.phase==ARP_PRINT_ERROR || darp_print.phase==ARP_PRINT_PENDING || darp_print.phase==ARP_PRINT_PREPARED || darp_print.phase==ARP_PRINT_QUEUED)){
        if(!down)return 1;
        if(darp_print.phase==ARP_PRINT_PREPARED || darp_print.phase==ARP_PRINT_QUEUED)return 1;
        if(darp_print.phase==ARP_PRINT_PENDING){if(k==13){darp_print.phase=ARP_PRINT_READY;darp_print_confirm=0;exit_release=1;dirty();}return 1;}
        if(k==13){if(darp_print_confirm){darp_print_confirm=0;darp_print_ui_error=0;}else darp_print_cancel();exit_release=1;}
        else if(darp_print.phase==ARP_PRINT_READY){
            if(darp_print_confirm)(void)darp_print_commit();
            else {darp_print_ui_error=0;darp_print_confirm=1;}
        }else if(darp_print_ui_error || darp_print.phase==ARP_PRINT_ERROR)darp_print_cancel();
        dirty();return 1;
    }
    if((k==12 || k==13) && (flags&2u) && down){
        remember_page();visible=0;quantize_opened=0;popup_ticks=0;dirty();
        return 0; /* native FUNC+YES/NO, including from inside ARP */
    }
    if(k==13){
        if(down){
            if(darp_ui_page==DARP_UI_MELODY)nav_source();
            else if(darp_ui_page==DARP_UI_SOURCE)nav_main();
            else{remember_page();visible=0;exit_release=1;dirty();}
        }
        return 1;
    }
    if(k==12){
        if(down){
            if(darp_ui_page==DARP_UI_MAIN)nav_source();
            else if(darp_ui_page==DARP_UI_SOURCE)nav_melody();
            else nav_main();
        }
        return 1;
    }
    if(k>=24 && k<=39){
        if(!notes_page || (darp_source!=ARP_SOURCE_ABSOLUTE && darp_source!=ARP_SOURCE_FIXED) || (flags&2u) ||
           track_held || bank_held || pattern_held || darp_native_recording() || darp_native_mute())return 0;
        owned_pads|=(uint16_t)(1u<<(k-24));
        if(down && notes_page && darp_source==ARP_SOURCE_FIXED){
            int pitch=arp_keyboard_pitch(k-23,darp_fixed_octave[darp_ui_track]);
            if(pitch>=0){uint32_t sr=core_audio_irq_save();darp_fixed_root[darp_ui_track]=(uint8_t)pitch;++darp_revision;core_audio_irq_restore(sr);dirty();}
        }else if(down && notes_page && darp_source==ARP_SOURCE_ABSOLUTE){
            int pitch=arp_keyboard_pitch(k-23,darp_manual[darp_ui_track].octave);
            if(pitch>=0){
                uint32_t sr=core_audio_irq_save();arp_manual_notes manual=darp_manual[darp_ui_track];
                if(arp_manual_toggle(&manual,(unsigned)pitch)==1){darp_manual[darp_ui_track]=manual;++darp_revision;}
                core_audio_irq_restore(sr);dirty();
            }
        }
        return 1;
    }
    if(k>=40 && k<=47)return 1; /* no underlying encoder-push dialog */
    if(k>=14 && k<=17){
        if(darp_ui_page==DARP_UI_MELODY)return 1;
        if(notes_page){
            if(down && darp_source==ARP_SOURCE_ABSOLUTE){
                if(k==16 && darp_manual[darp_ui_track].octave>0)--darp_manual[darp_ui_track].octave;
                if(k==17 && darp_manual[darp_ui_track].octave<10)++darp_manual[darp_ui_track].octave;
            }else if(down && darp_source==ARP_SOURCE_FIXED){
                if(k==16 && darp_fixed_octave[darp_ui_track]>0)--darp_fixed_octave[darp_ui_track];
                if(k==17 && darp_fixed_octave[darp_ui_track]<10)++darp_fixed_octave[darp_ui_track];
            }else{
                if(down && k==16 && chord_bank>0)--chord_bank;
                if(down && k==17 && chord_bank<10)++chord_bank;
            }
            dirty();return 1;
        }
        return key(0,event);
    }
    /* Keep RECORD/transport, TRK, BANK/PTN and plain PAGE native while ARP
     * stays open. Dedicated parameter/menu keys still expose their pages. */
    if(down && ((k>=5 && k<=8) || (k>=19 && k<=23) ||
                 (k==18 && (flags&2u)) || (k==2 && (flags&2u)))){
        remember_page();visible=0;dirty();
    }
    return 0;
}

int darp_ui_open(void){return visible!=0;}

int32_t darp_ui_global_enc(void *brain,void *event){darp_store_before_event();int32_t r=global_enc_impl(brain,event);if(r)header_ticks=0;(void)darp_store_flush();return r;}
int32_t darp_ui_global_key(void *brain,void *event){darp_store_before_event();int32_t r=global_key_impl(brain,event);if(((const uint32_t *)event)[4]&1u)header_ticks=0;(void)darp_store_flush();return r;}
