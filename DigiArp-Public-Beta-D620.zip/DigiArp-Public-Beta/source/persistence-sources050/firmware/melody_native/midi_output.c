/* SPDX-License-Identifier: GPL-2.0-or-later */
#include "midi_output.h"
#include "midi_pool.h"
#include "midi_gate.h"
#include "midi_queue.h"
#define W(p,n) (*(volatile uint32_t *)((p)+4u*(n)))
/* 1/250 quarter-note articulation gap (2 ms at 120 BPM). Only MIDI
 * attacks are shifted; releases, the shared readers and audio stay intact. */
#define ATTACK_GAP 43200u
#define FIRST 0x421c4e3cu
#define END 0x421c5a3cu
struct release {midi_queue_reservation queue;uint32_t payload;};
static struct release release[8];
static uint32_t gate[64];
static uint8_t owner[64],cancelled[64],preserve[64];
volatile uint32_t darp_midi_output_faults;
static unsigned slot(uint32_t p){return (p-FIRST)/48u;}
static int valid(uint32_t p){return p>=FIRST && p<END && (p-FIRST)%48u==0;}
static void packet(uint32_t p,unsigned t,unsigned note,unsigned velocity,unsigned on,uint32_t date){
 W(p,1)=t;W(p,2)=on?1:2;W(p,3)=on?0x81:0;W(p,4)=1;
 *(volatile uint8_t *)(p+20)=(uint8_t)note;W(p,6)=0;W(p,7)=velocity;W(p,8)=date;
 W(p,10)=on?1:0; /* OFF bypasses source-mute gating and finds the old channel. */
}
int darp_midi_output_on(unsigned t,unsigned note,unsigned velocity,uint32_t date){
 if(t>=8 || note>127 || !velocity || velocity>127)return -1;
 uint32_t sr=core_audio_irq_save();midi_queue_reservation onq={0},offq={0};
 uint32_t on=0,off=0,g=0;int ok=0;
 if(release[t].payload)goto done;
 on=darp_midi_pool_reserve();if(!on)goto done;
 off=darp_midi_pool_reserve();if(!off)goto done;
 g=darp_midi_gate_reserve();if(!g)goto done;
 if(!midi_queue_reserve(&onq) || !midi_queue_reserve(&offq))goto done;
 date+=ATTACK_GAP;packet(on,t,note,velocity,1,date);packet(off,t,note,0,0,date);
 midi_queue_note event={t,on};gate[slot(on)]=g;owner[slot(on)]=(uint8_t)(t+1);cancelled[slot(on)]=0;preserve[slot(on)]=1;
 if(!midi_queue_post_reserved(&onq,&event,date)){gate[slot(on)]=0;owner[slot(on)]=0;goto done;}
 (void)darp_midi_pool_handoff(on);release[t]=(struct release){offq,off};ok=1;
done:
 if(!ok){
  midi_queue_unreserve(&onq);midi_queue_unreserve(&offq);
  if(g)(void)darp_midi_gate_release(g);
  if(off)(void)darp_midi_pool_release(off);
  if(on)(void)darp_midi_pool_release(on);
  ++darp_midi_output_faults;
 }
 core_audio_irq_restore(sr);return ok?0:-2;
}
int darp_midi_output_off(unsigned t,uint32_t date){
 if(t>=8)return -1;
 uint32_t sr=core_audio_irq_save();struct release *r=&release[t];
 if(!r->payload){core_audio_irq_restore(sr);return 0;}
 midi_queue_note event={t,r->payload};
 W(r->payload,8)=date;
 if(!midi_queue_post_reserved(&r->queue,&event,date)){++darp_midi_output_faults;core_audio_irq_restore(sr);return -2;}
 (void)darp_midi_pool_handoff(r->payload);r->payload=0;
 core_audio_irq_restore(sr);return 0;
}
uint32_t darp_midi_output_gate_take(uint32_t p){
 if(!valid(p))return 0;
 uint32_t sr=core_audio_irq_save();unsigned i=slot(p);uint32_t g=gate[i];
 if(g && darp_midi_gate_handoff(g))gate[i]=0;else g=0;
 core_audio_irq_restore(sr);return g;
}
void darp_midi_output_payload_done(uint32_t p){
 if(!valid(p))return;
 uint32_t sr=core_audio_irq_save();unsigned i=slot(p);
 if(gate[i] && darp_midi_gate_release(gate[i]))gate[i]=0;
 owner[i]=cancelled[i]=preserve[i]=0;
 core_audio_irq_restore(sr);
}

void darp_midi_output_cancel(unsigned t){
 if(t>=8)return;
 uint32_t sr=core_audio_irq_save();
 for(unsigned i=0;i<64;i++)if(owner[i]==t+1)cancelled[i]=1;
 core_audio_irq_restore(sr);
}
void darp_midi_output_filter(uint32_t p){
 if(!valid(p))return;
 uint32_t sr=core_audio_irq_save();unsigned i=slot(p);
 if(owner[i] && cancelled[i]){W(p,2)=2;W(p,3)=0;W(p,4)=0;W(p,10)=0;}
 core_audio_irq_restore(sr);
}

unsigned darp_midi_output_generated(uint32_t p){
 return valid(p) && owner[slot(p)] && !cancelled[slot(p)] && preserve[slot(p)];
}

unsigned darp_midi_output_owned(uint32_t p){return valid(p) && owner[slot(p)];}
uint32_t darp_midi_output_take_release(unsigned t,uint32_t date){
 if(t>=8)return 0;
 struct release *r=&release[t];uint32_t p=r->payload;if(!p)return 0;
 W(p,8)=date;midi_queue_unreserve(&r->queue);(void)darp_midi_pool_handoff(p);r->payload=0;return p;
}
int darp_midi_output_adopt(uint32_t p,unsigned t,unsigned note,unsigned velocity,uint32_t date,unsigned on,uint32_t *prefix){
 if(!valid(p) || t>=8 || !prefix)return -1;
 midi_queue_reservation reserve={0},attackq={0};uint32_t off=0,g=0,attack=0;
 if(on){
  off=darp_midi_pool_reserve();if(!off)goto fail;
  attack=darp_midi_pool_reserve();if(!attack)goto fail;
  g=darp_midi_gate_reserve();if(!g)goto fail;
  if(!midi_queue_reserve(&reserve) || !midi_queue_reserve(&attackq))goto fail;
  packet(off,t,note,0,0,date);
  packet(attack,t,note,velocity,1,date+ATTACK_GAP);
  gate[slot(attack)]=g;owner[slot(attack)]=(uint8_t)(t+1);
  cancelled[slot(attack)]=0;preserve[slot(attack)]=1;
  midi_queue_note event={t,attack};
  if(!midi_queue_post_reserved(&attackq,&event,date+ATTACK_GAP)){
   gate[slot(attack)]=0;owner[slot(attack)]=preserve[slot(attack)]=0;goto fail;
  }
 }
 /* Cancel older pending attacks before publishing the replacement ownership. */
 for(unsigned i=0;i<64;i++)if(owner[i]==t+1 && (!attack || i!=slot(attack)))cancelled[i]=1;
 *prefix=darp_midi_output_take_release(t,date);
 if(on){
  (void)darp_midi_pool_handoff(attack);
  release[t]=(struct release){reserve,off};
  W(p,4)=1;*(volatile uint8_t *)(p+20)=(uint8_t)note;W(p,7)=velocity;W(p,8)=date;
 }
 /* Original source still applies native locks and defaults, without an attack.
  * The reserved generated attack follows after the articulation gap. */
 W(p,3)&=~0x80u;W(p,6)=0;
 return 0;
fail:
 midi_queue_unreserve(&reserve);midi_queue_unreserve(&attackq);
 if(g)(void)darp_midi_gate_release(g);
 if(attack)(void)darp_midi_pool_release(attack);
 if(off)(void)darp_midi_pool_release(off);
 ++darp_midi_output_faults;return -2;
}
uint32_t darp_midi_output_marker(unsigned t,uint32_t date){
 if(t>=8)return 0;
 uint32_t p=darp_midi_pool_reserve();if(!p)return 0;
 W(p,1)=t;W(p,2)=2;W(p,8)=date;
 midi_queue_note event={t,p};uint32_t m=midi_queue_try_post(&event,date);
 if(m)(void)darp_midi_pool_handoff(p);else (void)darp_midi_pool_release(p);
 return m;
}
