/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef DARP_PATTERN_STORE_H
#define DARP_PATTERN_STORE_H
#include <stdint.h>
#include "../../src/arp_snapshot.h"
extern volatile int32_t darp_store_error;
void darp_store_tick(void *);
uint32_t darp_ram_project_id(void);
void darp_ram_capture(arp_snapshot_state *,const unsigned char *);
void darp_ram_restore(const arp_snapshot_state *);
int darp_store_flush(void);
void darp_store_before_event(void);
void darp_store_audio_select(void);
int darp_store_audio_ready(void);
void darp_store_reset_audio(void);
#endif
