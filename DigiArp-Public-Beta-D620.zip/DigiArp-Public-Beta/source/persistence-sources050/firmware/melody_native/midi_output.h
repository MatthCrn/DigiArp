/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef DARP_MIDI_OUTPUT_H
#define DARP_MIDI_OUTPUT_H
#include <stdint.h>
/* Native queue backend. Tracks are MIDI indices 0..7. The native
 * consumer bridge must call gate_take BEFORE its held-note allocator and
 * payload_done BEFORE native free, including skipped/muted ONs.
 * These consumer hooks and cancellation are supplied by this module. */
int darp_midi_output_on(unsigned,unsigned,unsigned,uint32_t);
int darp_midi_output_off(unsigned,uint32_t);
uint32_t darp_midi_output_gate_take(uint32_t);
void darp_midi_output_payload_done(uint32_t);
void darp_midi_output_cancel(unsigned);
void darp_midi_output_filter(uint32_t);
unsigned darp_midi_output_generated(uint32_t);
unsigned darp_midi_output_owned(uint32_t);
uint32_t darp_midi_output_take_release(unsigned,uint32_t);
int darp_midi_output_adopt(uint32_t,unsigned,unsigned,unsigned,uint32_t,unsigned,uint32_t *);
uint32_t darp_midi_output_marker(unsigned,uint32_t);
extern volatile uint32_t darp_midi_output_faults;
#endif
