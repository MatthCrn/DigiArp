| SPDX-License-Identifier: GPL-2.0-or-later
| Isolated probe candidate, not patched into a delivered firmware.
.text
.globl darp_midi_gate_consumer
| Replaces 0x400e19ac..19bc: allocate from the reserved gate if ours,
| otherwise replay stock's free-list pop. No task/allocator calls.
darp_midi_gate_consumer:
 lea -12(%sp),%sp
 movem.l %d0-%d1/%a1,(%sp)
 move.l %a2,-(%sp)
 jsr darp_midi_output_gate_take
 addq.l #4,%sp
 tst.l %d0
 beq.s 1f
 movea.l %d0,%a0
 bra.s 2f
1: movea.l 0x421b8e34,%a0
 lea 20(%a0),%a1
 move.l (%a1),0x421b8e34
2: movem.l (%sp),%d0-%d1/%a1
 lea 12(%sp),%sp
 lea 20(%a0),%a1
 jmp 0x400e19bc
.globl darp_midi_payload_free
| Replays 0x400e0c7a..0c82 after releasing an unused gate reservation.
darp_midi_payload_free:
 lea -16(%sp),%sp
 movem.l %d0-%d1/%a0-%a1,(%sp)
 move.l 20(%sp),-(%sp)
 jsr darp_midi_output_payload_done
 addq.l #4,%sp
 movem.l (%sp),%d0-%d1/%a0-%a1
 lea 16(%sp),%sp
 move.l %a2,-(%sp)
 moveq #1,%d0
 movea.l 8(%sp),%a2
 jmp 0x400e0c82

.globl darp_midi_payload_filter
| Replays 0x400e143c..1446. A canceled addon attack becomes an empty
| OFF command before native parameter processing or hardware output.
darp_midi_payload_filter:
 lea -16(%sp),%sp
 movem.l %d0-%d1/%a0-%a1,(%sp)
 move.l %a2,-(%sp)
 jsr darp_midi_output_filter
 addq.l #4,%sp
 movem.l (%sp),%d0-%d1/%a0-%a1
 lea 16(%sp),%sp
 move.l 4(%a2),%d2
 move.l 0x421c9558,%d1
 jmp 0x400e1446

.globl darp_midi_preserve_params
| Replaces 0x400e14ec..14f4. Source/native commands still replay the
| default-parameter path. Addon attacks use the already resolved native
| MIDI context: do not reset source P-Locks/CC between generated notes.
darp_midi_preserve_params:
 lea -16(%sp),%sp
 movem.l %d0-%d1/%a0-%a1,(%sp)
 move.l %a2,-(%sp)
 jsr darp_midi_output_generated
 addq.l #4,%sp
 tst.l %d0
 beq.s 1f
 movem.l (%sp),%d0-%d1/%a0-%a1
 lea 16(%sp),%sp
 move.l %d2,-(%sp)
 jsr 0x400e09d8
 addq.l #4,%sp
 move.l %d0,%d6
 jmp 0x400e1906
1: movem.l (%sp),%d0-%d1/%a0-%a1
 lea 16(%sp),%sp
 moveq #106,%d1
 muls.l %d2,%d1
 movea.l %d1,%a0
 jmp 0x400e14f4
