/* SPDX-License-Identifier: GPL-2.0-or-later */
#include "core_audio.h"
#include "print.h"
#include "midi_output.h"
#define DARP_ME_TRACK (lane->track)
#include "melody_native.h"
#include "controls.h"
#include "pattern_store.h"
#include "step_locks.h"
#include "lfo.h"
#include "temp_pattern.h"
#include "track_scale.h"
#include "track_cycle.h"
#include "../../src/arp_repool.h"
#include "../../src/arp_probability.h"
#include "../../src/arp_scale.h"
#include "../../src/arp_player.h"
#include "../../src/arp_timeline.h"
#include "../../src/arp_chord.h"
#include "../../src/arp_pitch_set.h"
volatile uint32_t darp_root[DARP_TRACKS],darp_root_valid[DARP_TRACKS];
volatile arp_manual_notes darp_manual[DARP_TRACKS]={
    {.octave=5},{.octave=5},{.octave=5},{.octave=5},
    {.octave=5},{.octave=5},{.octave=5},{.octave=5},{.octave=5},{.octave=5},{.octave=5},{.octave=5},{.octave=5},{.octave=5},{.octave=5},{.octave=5}};
#define RHYTHM_INITIAL {100,255,0,0}
volatile darp_rhythm_controls darp_rhythm[DARP_TRACKS]={
 RHYTHM_INITIAL,RHYTHM_INITIAL,RHYTHM_INITIAL,RHYTHM_INITIAL,
 RHYTHM_INITIAL,RHYTHM_INITIAL,RHYTHM_INITIAL,RHYTHM_INITIAL,RHYTHM_INITIAL,RHYTHM_INITIAL,RHYTHM_INITIAL,RHYTHM_INITIAL,RHYTHM_INITIAL,RHYTHM_INITIAL,RHYTHM_INITIAL,RHYTHM_INITIAL};
volatile uint8_t darp_key[DARP_TRACKS];
volatile uint8_t darp_fixed_root[DARP_TRACKS]={60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60};
volatile uint8_t darp_fixed_octave[DARP_TRACKS]={5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5};
#define DARP_INITIAL {.settings=DARP_DEFAULT_SETTINGS,.mask=0xffff,.length=16,.source=ARP_SOURCE_GENERATED,.preset=2,.chord_count=1,.chord_offsets={0,4,7}}
volatile darp_track_controls darp_controls[DARP_TRACKS]={
    DARP_INITIAL,DARP_INITIAL,DARP_INITIAL,DARP_INITIAL,
    DARP_INITIAL,DARP_INITIAL,DARP_INITIAL,DARP_INITIAL,DARP_INITIAL,DARP_INITIAL,DARP_INITIAL,DARP_INITIAL,DARP_INITIAL,DARP_INITIAL,DARP_INITIAL,DARP_INITIAL};
volatile uint32_t darp_arms[DARP_TRACKS],darp_generated[DARP_TRACKS],darp_cancels[DARP_TRACKS],darp_errors[DARP_TRACKS],darp_suppressed[DARP_TRACKS];
volatile uint32_t darp_source_duration[DARP_TRACKS],darp_skip_start;
/* Scoped to the current render-dispatched message, reset at every dispatch. */
volatile uint32_t darp_preserve_locks;
static uint32_t midi_context_pending;
struct darp_lane {
    union {melody_phrase me_prepared;arp_player_config prepared;};uint32_t me_applied_revision,me_root;
    uint8_t track,prepared_count,prepared_empty,source_empty,machine,melody_mode,wait_me_trig;
    uint8_t prepared_notes[16],source_manual[16];
    int8_t source_custom[16];
    uint8_t source_kind,source_root,source_preset,base_notes,manual_count,applied_notes;
    uint8_t prepared_scale,scale;
    arp_player player;core_audio_reservation release_reserve;
    uint32_t generation,pattern,active,dispatch_ours,prepared_message;
    uint32_t probability_state; /* persistent stream, never reset by source restart */
    struct {uint32_t date,pattern,generation;} cycle[8];
    uint32_t cycle_read,cycle_write,cycle_fault,boundary_date,boundary_valid,source_velocity;
    uint32_t last_clock,fraction,musical_tick,emit_date,initial,last_revision;
    struct {uint32_t pointer,generation;} pending[8];
};
#define me_prepared (lane->me_prepared)
#define me_applied_revision (lane->me_applied_revision)
#define me_root (lane->me_root)
static struct darp_lane lanes[DARP_TRACKS]={
    {.track=0},{.track=1},{.track=2},{.track=3},
    {.track=4},{.track=5},{.track=6},{.track=7},{.track=8},{.track=9},{.track=10},{.track=11},{.track=12},{.track=13},{.track=14},{.track=15}};
#define ME_READER (darp_me_active() || darp_me_imported)
#define ME_SEED (8107u+977u*lane->track)
#define ME_PROBABILITY (darp_me_imported?darp_rhythm[lane->track].probability:100u)
#define ME_LENGTH (darp_me_imported?darp_length:16u)
#define ME_STEP ((darp_me_imported?darp_periods[darp_decode(darp_settings).rate]:480u)*lane->scale*DARP_SCALE_CLOCK_UNIT)
#define darp_enabled (darp_controls[lane->track].enabled)
#define darp_settings (darp_controls[lane->track].settings)
#define darp_revision (darp_controls[lane->track].revision)
#define darp_mask darp_effective_mask(lane->track)
#define darp_length (darp_controls[lane->track].length)
#define darp_offsets (darp_controls[lane->track].offsets)
#define darp_source (darp_controls[lane->track].source)
#define darp_preset (darp_controls[lane->track].preset)
#define darp_chord_count (darp_controls[lane->track].chord_count)
#define darp_chord_offsets (darp_controls[lane->track].chord_offsets)
#define darp_arms darp_arms[lane->track]
#define darp_generated darp_generated[lane->track]
#define darp_cancels darp_cancels[lane->track]
#define darp_errors darp_errors[lane->track]
#define darp_suppressed darp_suppressed[lane->track]
#define darp_source_duration darp_source_duration[lane->track]
/* UI calls under the audio IRQ guard before enabling the generator.
 * Only a running classic reader waits; an existing ME reader keeps playing. */
void darp_me_wait_source_trigger(unsigned track){
    if(track>=DARP_TRACKS)return;
    struct darp_lane *lane=&lanes[track];
    lane->wait_me_trig=lane->active && !lane->melody_mode && !ME_READER;
}
static unsigned machine_id(struct darp_lane *lane){
    if(lane->track>=8)return 0;
    const uint8_t *kit=*(const uint8_t *const volatile *)0x800019ac;
    return kit?kit[0x20+0xa2*lane->track+0x7e]:255;
}
/* First native-only candidate: stock ONESHOT. No alternative machine IDs. */
static int supported(unsigned machine){return machine==0;}
static int eligible(struct darp_lane *lane){
    const uint8_t *kit=*(const uint8_t *const volatile *)0x800019ac;
    return darp_enabled && CORE_AUDIO_RUNNING==1 && !(CORE_AUDIO_MUTES&(1u<<lane->track)) && kit && supported(machine_id(lane));
}
static int allowed(struct darp_lane *lane){
    return eligible(lane) && darp_store_audio_ready();
}
static unsigned room(struct darp_lane *lane){unsigned n=0;for(unsigned i=0;i<8;i++)if(!lane->pending[i].pointer)++n;return n;}
static void remember(struct darp_lane *lane,uint32_t p){
    for(unsigned i=0;i<8;i++)if(!lane->pending[i].pointer){lane->pending[i].pointer=p;lane->pending[i].generation=lane->generation;return;}
    ++darp_errors;
}
static int resolve_pool(struct darp_lane *lane,unsigned count,uint8_t notes[16]){
    if(lane->source_kind==ARP_SOURCE_ABSOLUTE){
        if(count>lane->manual_count)count=lane->manual_count;
        for(unsigned i=0;i<count;i++)notes[i]=lane->source_manual[i];
        return (int)count;
    }
    if(lane->source_kind==ARP_SOURCE_FIXED && darp_key[lane->track])
        return arp_scale_pool(darp_key[lane->track]-1,lane->source_preset,lane->source_root,count,notes);
    int8_t offsets[16];
    int n=(lane->source_kind==ARP_SOURCE_GENERATED || lane->source_kind==ARP_SOURCE_FIXED)?
        arp_pitch_set(lane->source_preset,count,offsets):
        arp_chord_offsets(lane->source_kind,lane->source_preset,lane->source_custom,count,offsets);
    return n<0?n:arp_chord_resolve(lane->source_root,offsets,(unsigned)n,notes);
}
/* Refresh the source snapshot after an editor revision, without restarting
 * the clock or attacking a note. The last native trig remains the TRIG root.
 * Compare source data so unrelated timing/offset edits keep SHUFFLE's bag. */
static int refresh_source(struct darp_lane *lane){
    unsigned kind=darp_source,preset=darp_preset;
    unsigned root=kind==ARP_SOURCE_FIXED?darp_fixed_root[lane->track]:
        darp_root_valid[lane->track]?darp_root[lane->track]:lane->source_root;
    unsigned changed=kind!=lane->source_kind || preset!=lane->source_preset || root!=lane->source_root;
    unsigned count=darp_chord_count;
    for(unsigned i=0;i<16;i++){
        int8_t v=darp_chord_offsets[i];
        if(v!=lane->source_custom[i])changed=1;
        lane->source_custom[i]=v;
    }
    if(kind==ARP_SOURCE_ABSOLUTE){
        arp_manual_notes manual=darp_manual[lane->track];uint8_t notes[16];
        int n=arp_manual_copy(&manual,notes);if(n<0)return -1;
        if(!n){notes[0]=(uint8_t)root;n=1;}
        if((unsigned)n!=lane->manual_count)changed=1;
        for(unsigned i=0;i<(unsigned)n;i++){
            if(notes[i]!=lane->source_manual[i])changed=1;
            lane->source_manual[i]=notes[i];
        }
        lane->manual_count=count=(unsigned)n;
    }else lane->manual_count=0;
    if(count!=lane->base_notes)changed=1;
    lane->source_kind=kind;lane->source_preset=preset;
    lane->source_root=root;lane->base_notes=count;
    /* KEY edits can change a FIXED pool without changing the fields above. */
    return (int)(changed || kind==ARP_SOURCE_FIXED);
}
static darp_options mod_options(struct darp_lane *lane,darp_options o){
    o.range=darp_lfo_value(lane->track,0,o.range);
    o.mode=darp_lfo_value(lane->track,1,o.mode);
    return o;
}
static int emit(void *context,const arp_player_event *event){
    struct darp_lane *lane=context;
    if(lane->initial && event->kind==ARP_PLAYER_ON){lane->initial=0;return 0;}
    if(lane->track>=8){
        int r=event->kind==ARP_PLAYER_ON?darp_midi_output_on(lane->track-8,event->note,event->velocity,lane->emit_date):darp_midi_output_off(lane->track-8,lane->emit_date);
        if(!r && event->kind==ARP_PLAYER_ON){uint32_t m[19]={0};m[1]=1;m[3]=1;m[6]=event->note;m[5]=(uint32_t)event->velocity<<24;uint32_t len=lane->player.sequence.config.span[event->position]?lane->player.sequence.config.span[event->position]*lane->player.period_ticks:lane->player.note_ticks;if(lane->player.finite && lane->player.end_tick-event->tick<len)len=lane->player.end_tick-event->tick;m[12]=len*DARP_SCALE_CLOCK_UNIT;darp_print_attack(lane->track,m,lane->emit_date);}
        if(r)++darp_errors;else ++darp_generated;return r;
    }
    if(room(lane)<2){++darp_errors;return -1;}
    core_audio_note n={event->note,event->velocity,event->kind==ARP_PLAYER_ON?1u:2u,1u,event->kind==ARP_PLAYER_ON?0x10281u:0u,0,lane->track};
    if(n.on==1){
        unsigned span=lane->player.sequence.config.span[event->position];
        uint32_t length=span?span*lane->player.period_ticks:lane->player.note_ticks;
        if(lane->player.finite && lane->player.end_tick-event->tick<length)length=lane->player.end_tick-event->tick;
        n.length=length*DARP_SCALE_CLOCK_UNIT;
    }
    uint32_t p=core_audio_try_post(&n,lane->emit_date);
    if(!p){++darp_errors;return -1;}
    remember(lane,p);++darp_generated;return 0;
}
static int me_emit(void *context,const melody_note *event){
    struct darp_lane *lane=context;
    if(lane->initial && event->kind==MELODY_ON){lane->initial=0;return 0;}
    if(lane->track>=8){int r=event->kind==MELODY_ON?darp_midi_output_on(lane->track-8,event->note,event->velocity,event->tick):darp_midi_output_off(lane->track-8,event->tick);if(r)++darp_errors;else ++darp_generated;return r;}
    if(room(lane)<2){++darp_errors;return -1;}
    core_audio_note n={event->note,event->velocity,event->kind==MELODY_ON?1u:2u,1u,
        event->kind==MELODY_ON?0x10281u:0u,0,lane->track};
    if(n.on==1)n.length=darp_me_player.gate_ticks;
    uint32_t p=core_audio_try_post(&n,event->tick);
    if(!p){++darp_errors;return -1;}
    remember(lane,p);++darp_generated;return 0;
}
static void cancel(struct darp_lane *lane,uint32_t now){
    if(!lane->active && !lane->player.sounding)return;
    ++lane->generation;++darp_cancels;lane->active=0;lane->wait_me_trig=0;
    if(lane->track>=8){darp_midi_output_cancel(lane->track-8);if(!(midi_context_pending&(1u<<(lane->track-8))))(void)darp_midi_output_off(lane->track-8,now);lane->player.running=lane->player.sounding=darp_me_player.running=darp_me_player.sounding=0;return;}
    uint32_t owner=*(volatile uint32_t *)(0x4399eb54+4u*lane->track);
    uint32_t held=*(volatile uint32_t *)(0x4399ec80+4u*lane->track);
    if(owner==1 && held<=127 && room(lane)){
        core_audio_note off={held,0,2,1,0,0,lane->track};
        uint32_t p=core_audio_post_reserved(&lane->release_reserve,&off,now);
        if(p)remember(lane,p);else ++darp_errors;
    }
    lane->player.running=0;lane->player.sounding=0;
    darp_me_player.running=0;darp_me_player.sounding=0;
}
static void imported_timing(unsigned track,arp_sequence_config *cfg){
    for(unsigned i=0;i<16;i++){
        unsigned span=darp_me_imported_tracks[track]?darp_me_span_tracks[track][i]:0;
        if(i>=cfg->length)span=0;
        else if(span>cfg->length-i)span=cfg->length-i;
        cfg->span[i]=(uint8_t)span;
        cfg->velocity[i]=darp_me_imported_tracks[track]?darp_me_velocity_tracks[track][i]:0;
    }
}
/* Rebuild the ordinary ARP traversal at the Melody player's exact horizon.
 * Existing queued events retain their generation; no past ON/OFF is replayed. */
/* Native 1.54 step clock: 0x4007091a..9c selects the scale and phase;
 * 0x40070a36..52 adds (ticks-1)*900000 to the scheduler base. This is
 * the grid date, before microtiming, even when a condition rejects a trig.
 * Reuse the existing PRINT step wrapper: no new firmware hook or allocator. */
volatile uint32_t darp_cycle_rewinds[DARP_TRACKS],darp_cycle_errors[DARP_TRACKS],darp_cycle_continues[DARP_TRACKS];
void darp_cycle_native_step(int32_t t,uint32_t pattern,int32_t step,const void *prepared){
    uint32_t date;if(!darp_cycle_step_date(t,pattern,step,prepared,&date))return;
    darp_print_cycle((unsigned)t,pattern,date);
    struct darp_lane *lane=&lanes[t];
    if(!lane->active || !darp_controls[t].enabled || pattern!=lane->pattern)return;
    uint32_t irq=core_audio_irq_save();
    if(lane->cycle_write!=lane->cycle_read){
        unsigned last=(lane->cycle_write-1u)&7u;
        if(lane->cycle[last].date==date && lane->cycle[last].pattern==pattern){core_audio_irq_restore(irq);return;}
    }
    if(lane->cycle_write-lane->cycle_read>=8){lane->cycle_fault=1;++darp_cycle_errors[t];}
    else{unsigned at=lane->cycle_write++&7u;lane->cycle[at].date=date;lane->cycle[at].pattern=pattern;lane->cycle[at].generation=lane->generation;}
    core_audio_irq_restore(irq);
}
static int adopt_silent(void *context,const arp_player_event *event){(void)context;(void)event;return 0;}
static int adopt_main(struct darp_lane *lane){
    if(!darp_me_player.running)return -1;
    melody_player *old=&darp_me_player;
    /* UI work can separate the last Melody service from this handoff by
     * more than the ordinary ARP per-render guard. Catch up in the existing
     * player first; never interpret that one transition as a stopped source.
     * Freeze its queued loop as well, so no prepared variation escapes. */
    uint32_t target=CORE_AUDIO_CLOCK+(lane->track<8?2*CORE_AUDIO_TEMPO:0);
    uint32_t lag=target-old->now;
    if(lag && lag<0x80000000u){
        if(lag>2u*old->step_ticks)return -1;
        if(melody_player_queue(old,&old->phrase) || melody_player_advance(old,target))return -1;
    }
    arp_player_config c={0};
    c.sequence.mode=ARP_SEQ_TRUE;c.sequence.range=1;c.sequence.length=16;
    for(unsigned i=0;i<old->phrase.count;i++){
        const melody_event *v=&old->phrase.event[i];
        c.sequence.active|=(uint16_t)(1u<<v->step);
        c.sequence.offset[v->step]=(int8_t)((int)v->note-(lane->track<8?60:64));
        c.sequence.span[v->step]=v->span;c.sequence.velocity[v->step]=v->velocity;
    }
    c.sequence.probability_on=1;c.sequence.probability=100;
    c.sequence.probability_seed=lane->probability_state?lane->probability_state:0x31415926u;
    c.period_ticks=old->step_ticks/DARP_SCALE_CLOCK_UNIT;
    c.note_ticks=c.period_ticks;c.velocity=100;
    uint8_t root=lane->track<8?60:64;arp_player p={0};
    if(arp_player_start(&p,&c,&root,1,0,adopt_silent,0))return -1;
    uint32_t elapsed=old->now-old->loop_start;
    unsigned slot=elapsed/old->step_ticks;
    if(slot>=16)return -1;
    arp_sequence_result ignored;
    for(unsigned i=1;i<=slot;i++)if(arp_sequence_next(&p.sequence,&ignored))return -1;
    p.tick=elapsed/DARP_SCALE_CLOCK_UNIT;p.next_tick=(slot+1)*c.period_ticks;
    p.sounding=old->sounding;p.note=old->note;
    p.off_tick=(old->off_at-old->loop_start)/DARP_SCALE_CLOCK_UNIT;
    for(unsigned i=0;i<old->phrase.count;i++)if(old->phrase.event[i].step<=slot)p.position=old->phrase.event[i].step;
    p.emit=emit;p.context=lane;
    lane->player=p;lane->melody_mode=0;lane->source_empty=0;
    lane->source_kind=ARP_SOURCE_FIXED;lane->source_root=root;lane->source_preset=darp_preset;
    lane->base_notes=lane->applied_notes=1;lane->manual_count=0;
    lane->last_clock=old->now;lane->fraction=elapsed%DARP_SCALE_CLOCK_UNIT;
    lane->musical_tick=p.tick;lane->last_revision=darp_revision-1u; /* apply any intervening main-page edits next */
    lane->probability_state=p.sequence.probability_state;
    old->running=old->sounding=0;return 0;
}
static int adopt_me_silent(void *context,const melody_note *event){(void)context;(void)event;return 0;}
/* Open/return to Melody from a running ARP without waiting for a new source.
 * Reconstruct the ME cursor silently at the existing musical-bar horizon and
 * retain the real held note/release, including already queued native events. */
static int adopt_melody(struct darp_lane *lane){
    arp_player *old=&lane->player;
    if(!old->running || old->finite)return -1;
    unsigned root=darp_source==ARP_SOURCE_FIXED?darp_fixed_root[lane->track]:darp_root_valid[lane->track]?darp_root[lane->track]:lane->source_root;
    melody_phrase phrase;if(darp_me_prepare(root,&phrase))return -1;
    uint32_t period=480u*lane->scale,step=period*DARP_SCALE_CLOCK_UNIT;
    uint32_t elapsed=(old->tick%(16u*period))*DARP_SCALE_CLOCK_UNIT+lane->fraction;
    uint32_t anchor=lane->last_clock-elapsed;
    melody_player next={0};
    if(melody_player_start_mode(&next,&phrase,anchor,step,MELODY_FWD,ME_LENGTH,ME_SEED,adopt_me_silent,0) || melody_player_advance(&next,lane->last_clock))return -1;
    next.sounding=old->sounding;next.note=old->note;
    if(old->sounding)next.off_at=lane->last_clock-lane->fraction+(old->off_tick-old->tick)*DARP_SCALE_CLOCK_UNIT;
    next.rise=darp_lfo_value(lane->track,DARP_LFO_ME_RISE,darp_me_knobs[6]);next.rise_ceiling=(uint8_t)darp_me_pitch_ceiling_track(lane->track);
    next.emit=me_emit;next.context=lane;
    darp_me_player=next;old->running=old->sounding=0;
    lane->melody_mode=1;lane->last_revision=darp_revision;
    me_root=root;me_applied_revision=darp_me_revision;darp_me_cycle(anchor);
    return 0;
}
void darp_dispatch(uint32_t *message,uint32_t date){
    darp_store_audio_select();
    darp_preserve_locks=0;if(message[2]>=DARP_TRACKS)return;
    darp_print_handoff_dispatch(message,date);
    struct darp_lane *lane=&lanes[message[2]];
    lane->dispatch_ours=0;lane->prepared_message=0;
    for(unsigned i=0;i<8;i++)if(lane->pending[i].pointer==(uint32_t)message){
        lane->dispatch_ours=1;
        if(lane->pending[i].generation!=lane->generation || (message[1]==1 && (!lane->active || !allowed(lane) || CORE_AUDIO_PATTERN!=lane->pattern))){message[3]=0xffffffffu;++darp_suppressed;}
        darp_preserve_locks=message[1]==1 && message[3]==1;
        lane->pending[i].pointer=0;return;
    }
    /* Native lock-only events (bit0 set, bit7 clear) must reach the OS
     * unchanged, without arming, cancelling or resetting the arp. */
    if(message[1]==1 && message[3]==1 && (message[9]&0x81u)==1u){
        if(lane->active && allowed(lane))darp_locks_begin(lane->track,message,date);
        return;
    }
    /* The native boundary trig must not attack a second time after the
     * musical reader has already rewound. Keep its P-locks through the
     * existing native lock-only route. Changed roots, sound locks, retrigs,
     * finite gates and deliberately placed non-boundary trigs stay native. */
    if(message[1]==1 && message[3]==1 && (message[9]&0x81u)==0x81u &&
       lane->active && !lane->wait_me_trig && allowed(lane) && lane->pattern==CORE_AUDIO_PATTERN &&
       !message[11] && !message[12] && (message[5]>>24)==lane->source_velocity && darp_root_valid[lane->track] && message[6]==darp_root[lane->track]){
        unsigned boundary=lane->boundary_valid && lane->boundary_date==date;
        for(uint32_t i=lane->cycle_read;i!=lane->cycle_write && !boundary;i++){
            unsigned at=i&7u;
            boundary=lane->cycle[at].generation==lane->generation && lane->cycle[at].pattern==lane->pattern && lane->cycle[at].date==date;
        }
        if(boundary){
            message[9]&=~0x80u;darp_locks_begin(lane->track,message,date);
            ++darp_cycle_continues[lane->track];return;
        }
    }
    /* A genuine source attack starts a new native parameter context. */
    if(message[1]==1 && message[3]>=1 && message[3]<0xffffffffu)
        darp_locks_finish(lane->track,1);
    /* A live/MIDI voice supersedes our sequencer ownership. Cancel future
     * generated notes, but never release the other source's voice. */
    if(message[1]==1 && message[3]>1 && message[3]<0xffffffffu){
        cancel(lane,CORE_AUDIO_CLOCK);return;
    }
    if(message[3]==1 && message[1]==2){
        ++lane->generation;lane->active=0;lane->player.running=0;lane->player.sounding=0;darp_me_player.running=0;darp_me_player.sounding=0;return;
    }
    if(message[1]!=1 || message[3]!=1 || !allowed(lane) || !(lane->track>=8 || lane->release_reserve.message) || room(lane)<2)return;
    const uint8_t *kit=*(const uint8_t *const volatile *)0x800019ac;
    uint32_t velocity=message[5]>>24;
    if(!kit || !supported(machine_id(lane)) || message[6]>127 || !velocity || velocity>127 || message[11]){
        ++lane->generation;lane->active=0;lane->player.running=0;lane->player.sounding=0;darp_me_player.running=0;darp_me_player.sounding=0;return;
    }
    /* +48 is musical duration; native UI LEN=INF yields zero. Only lengths
     * exactly on our fine scale-aware grid are accepted, never rounded silently. */
    if(message[12]>0x7fffffffu || message[12]%DARP_SCALE_CLOCK_UNIT)return;
    lane->source_velocity=velocity;
    if(ME_READER){
        unsigned source_root=darp_source==ARP_SOURCE_FIXED?darp_fixed_root[lane->track]:message[6];
        if(message[12] || darp_me_prepare(source_root,&me_prepared)){
            darp_me_error=message[12]?1:2;cancel(lane,date);return;
        }
        unsigned scale=darp_scale_units(lane->track,CORE_AUDIO_PATTERN);if(!scale)return;
        darp_root[lane->track]=message[6];darp_root_valid[lane->track]=1;me_root=source_root;
        if(darp_me_error==1)darp_me_error=0;
        lane->prepared_scale=scale;
        uint32_t step=(darp_me_imported?darp_periods[darp_decode(darp_settings).rate]:480u)*scale*DARP_SCALE_CLOCK_UNIT;
        melody_note first;
        unsigned length=ME_LENGTH,probability=ME_PROBABILITY;
        if(!length || length>16 || !step || step>0x7fffffffu || probability>100){darp_me_error=2;return;}
        int attack=melody_first_forward(&me_prepared,step,ME_SEED,probability,
                    darp_lfo_value(lane->track,DARP_LFO_ME_RISE,darp_me_knobs[6]),
                    darp_me_pitch_ceiling_track(lane->track),&first);
        lane->prepared_empty=!attack;lane->prepared_message=(uint32_t)message;
        if(attack){message[6]=first.note;message[5]=(uint32_t)first.velocity<<24;}
        message[12]=attack?first.tick:0;
        return;
    }
    darp_options o=mod_options(lane,darp_decode(darp_settings));
    lane->prepared=(arp_player_config){0};lane->prepared.sequence.mode=(arp_sequence_mode)o.mode;
    lane->prepared.sequence.range=(uint8_t)o.range;lane->prepared.sequence.length=darp_length;
    lane->prepared.sequence.active=darp_mask;
    if(!lane->probability_state)lane->probability_state=arp_probability_seed(date,lane->track);
    lane->prepared.sequence.probability_seed=lane->probability_state;
    lane->prepared.sequence.probability_on=1;lane->prepared.sequence.probability=darp_rhythm[lane->track].probability;
    for(unsigned i=0;i<16;i++)lane->prepared.sequence.offset[i]=darp_offsets[i];
    imported_timing(lane->track,&lane->prepared.sequence);
    lane->prepared_scale=darp_scale_units(lane->track,CORE_AUDIO_PATTERN);
    if(!lane->prepared_scale)return;
    lane->prepared.period_ticks=darp_periods[o.rate]*lane->prepared_scale;
    lane->prepared.note_ticks=darp_scale_note(darp_duration(o.note),lane->prepared_scale);
    darp_source_duration=message[12];
    lane->prepared.source_ticks=message[12]/DARP_SCALE_CLOCK_UNIT;lane->prepared.velocity=(uint8_t)velocity;
    darp_root[lane->track]=message[6];darp_root_valid[lane->track]=1;
    lane->source_kind=darp_source;lane->source_preset=darp_preset;
    lane->source_root=darp_source==ARP_SOURCE_FIXED?darp_fixed_root[lane->track]:message[6];
    if(darp_source==ARP_SOURCE_FIXED){lane->prepared.sequence.key=darp_key[lane->track];lane->prepared.sequence.scale=(uint8_t)lane->source_preset;}
    lane->base_notes=darp_chord_count;lane->manual_count=0;
    for(unsigned i=0;i<16;i++)lane->source_custom[i]=darp_chord_offsets[i];
    if(darp_source==ARP_SOURCE_ABSOLUTE){
        arp_manual_notes manual=darp_manual[lane->track];
        int copied=arp_manual_copy(&manual,lane->source_manual);
        if(copied<0){++darp_errors;return;}
        /* Empty CUSTOM follows each source trig without writing manual keys.
         * Selecting keys replaces this fallback; clearing them restores it. */
        if(!copied){lane->source_manual[0]=(uint8_t)message[6];copied=1;}
        lane->manual_count=(unsigned)copied;lane->base_notes=lane->manual_count;
    }
    lane->applied_notes=darp_lfo_value(lane->track,2,lane->base_notes?lane->base_notes:1);
    int count=resolve_pool(lane,lane->applied_notes,lane->prepared_notes);
    if(count<0){++darp_errors;return;}
    lane->prepared_empty=!count;
    if(!count){lane->prepared.sequence.active=0;lane->prepared_notes[0]=(uint8_t)message[6];count=1;}
    lane->prepared_count=(unsigned)count;
    arp_sequence preview;arp_sequence_result first;
    if(arp_sequence_init(&preview,&lane->prepared.sequence,lane->prepared_notes,lane->prepared_count) || arp_sequence_next(&preview,&first)){++darp_errors;return;}
    lane->prepared_message=(uint32_t)message;
    if(first.kind==ARP_SEQ_NOTE)message[6]=(uint32_t)first.pitch;
    uint32_t first_length=lane->prepared.sequence.span[0]?lane->prepared.sequence.span[0]*lane->prepared.period_ticks:lane->prepared.note_ticks;
    if(lane->prepared.sequence.velocity[0])message[5]=(uint32_t)lane->prepared.sequence.velocity[0]<<24;
    if(lane->prepared.source_ticks && lane->prepared.source_ticks<first_length)first_length=lane->prepared.source_ticks;
    message[12]=first_length*DARP_SCALE_CLOCK_UNIT;
}
void darp_start(uint32_t *message,uint32_t date){
    darp_skip_start=0;if(message[2]>=DARP_TRACKS)return;
    struct darp_lane *lane=&lanes[message[2]];
    if(lane->dispatch_ours)darp_print_attack(lane->track,message,date);
    if(message[3]!=1 || lane->dispatch_ours || lane->prepared_message!=(uint32_t)message || !allowed(lane) || !(lane->track>=8 || lane->release_reserve.message))return;
    lane->prepared_message=0;
    ++lane->generation;lane->active=0;lane->player.running=0;lane->player.sounding=0;
    darp_me_player.running=0;darp_me_player.sounding=0;
    lane->source_empty=lane->prepared_empty;lane->machine=machine_id(lane);lane->scale=lane->prepared_scale;
    lane->boundary_valid=0;lane->cycle_fault=0;
    lane->pattern=CORE_AUDIO_PATTERN;lane->last_clock=date;lane->fraction=0;lane->musical_tick=0;lane->emit_date=date;
    lane->initial=1;lane->active=1;lane->last_revision=darp_revision;
    lane->melody_mode=ME_READER;lane->wait_me_trig=0;
    if(lane->melody_mode){
        if(melody_player_start_config_rise(&darp_me_player,&me_prepared,date,ME_STEP,MELODY_FWD,ME_LENGTH,ME_SEED,ME_PROBABILITY,darp_lfo_value(lane->track,DARP_LFO_ME_RISE,darp_me_knobs[6]),darp_me_pitch_ceiling_track(lane->track),me_emit,lane)){
            ++darp_errors;lane->active=0;return;
        }
        me_applied_revision=darp_me_revision;darp_me_cycle(date);
    }else{
    if(arp_player_start(&lane->player,&lane->prepared,lane->prepared_notes,lane->prepared_count,0,emit,lane)){++darp_errors;lane->active=0;return;}
    lane->probability_state=lane->player.sequence.probability_state;
    }
    lane->initial=0;darp_skip_start=lane->melody_mode?!darp_me_player.sounding:!lane->player.sounding;++darp_arms;
    darp_print_source(lane->track,date,darp_skip_start);
    if(!darp_skip_start)darp_print_attack(lane->track,message,date);
    if(darp_skip_start && lane->track<8){
        /* Release a previous phrase without an attack on this REST. Native
         * ownership has already been updated to the accepted source note. */
        core_audio_note off={message[6],0,2,1,0,0,lane->track};
        uint32_t p=core_audio_try_post(&off,date);
        if(p)remember(lane,p);else{++darp_errors;cancel(lane,date);}
    }
}
static void service_lane_to(struct darp_lane *lane,uint32_t horizon,int ready){
    uint32_t now=CORE_AUDIO_CLOCK;
    int can_play=ready && eligible(lane);
    darp_locks_service(lane->track,now,can_play);
    if(!can_play || (lane->active && (CORE_AUDIO_PATTERN!=lane->pattern || machine_id(lane)!=lane->machine)))cancel(lane,now);
    unsigned me_reader=darp_me_enabled_tracks[lane->track] || darp_me_imported;
    if(lane->active && lane->melody_mode && !me_reader && darp_enabled){
        if(adopt_main(lane)){++darp_errors;cancel(lane,now);}
    }
    if(!me_reader)lane->wait_me_trig=0;
    unsigned reader=me_reader && !(lane->wait_me_trig && !lane->melody_mode);
    if(lane->active && !lane->melody_mode && reader){
        if(adopt_melody(lane)){darp_me_error=1;++darp_errors;cancel(lane,now);}
    }
    if(lane->active && lane->melody_mode!=reader)cancel(lane,now);
    if(!darp_enabled){if(!lane->player.sounding && (lane->release_reserve.message || lane->release_reserve.bucket))core_audio_unreserve(&lane->release_reserve);return;}
    if(lane->track<8 && !lane->release_reserve.message && !core_audio_reserve(&lane->release_reserve))return;
    if(!lane->active)return;
    if(lane->melody_mode){
        melody_player *player=&darp_me_player;
        unsigned scale=darp_scale_units(lane->track,CORE_AUDIO_PATTERN);
        /* A running scale edit is re-anchored by the next source trig.
         * Cancel rather than keep an incorrect rate before that anchor. */
        if(scale!=lane->scale){cancel(lane,now);return;}
        unsigned queued_mode=player->mode_queued?player->pending_mode:player->mode;
        unsigned queued_length=player->mode_queued?player->pending_length:player->length;
        uint32_t queued_step=player->mode_queued?player->pending_step_ticks:player->step_ticks;
        if(me_applied_revision!=darp_me_revision || lane->last_revision!=darp_revision || queued_mode!=MELODY_FWD || queued_length!=ME_LENGTH || queued_step!=ME_STEP){
            melody_phrase next;
            unsigned root=darp_source==ARP_SOURCE_FIXED?darp_fixed_root[lane->track]:me_root;
            if(!darp_me_prepare(root,&next)){
                if(melody_player_queue_mode(player,&next,ME_STEP,MELODY_FWD,ME_LENGTH)){++darp_errors;cancel(lane,now);return;}
                me_applied_revision=darp_me_revision;lane->last_revision=darp_revision;
            }
        }
        player->probability=(uint8_t)ME_PROBABILITY;
        player->rise=darp_lfo_value(lane->track,DARP_LFO_ME_RISE,darp_me_knobs[6]);player->rise_ceiling=(uint8_t)darp_me_pitch_ceiling_track(lane->track);
        uint32_t loops=player->loops;
        if(horizon-player->now>=0x80000000u)return;
        if(melody_player_advance(player,horizon)){
            ++darp_errors;cancel(lane,now);return;
        }
        if(player->loops!=loops)darp_me_cycle(player->loop_start);
        return;
    }
    /* Keep the source reader's full recipe until an accepted native trig.
     * Editing/validating the prepared ME must not alter that audible recipe. */
    if(!lane->wait_me_trig){
    darp_options o=mod_options(lane,darp_decode(darp_settings));
    int source_edit=0;
    if(lane->last_revision!=darp_revision){
        source_edit=refresh_source(lane);
        if(source_edit<0){++darp_errors;cancel(lane,now);return;}
    }
    unsigned wanted_notes=darp_lfo_value(lane->track,2,lane->base_notes?lane->base_notes:1);
    unsigned scale=darp_scale_units(lane->track,CORE_AUDIO_PATTERN);
    if(!scale){cancel(lane,now);return;}
    if(lane->scale!=scale || lane->last_revision!=darp_revision || o.mode!=(unsigned)lane->player.sequence.config.mode ||
       o.range!=lane->player.sequence.config.range || wanted_notes!=lane->applied_notes){
        arp_sequence_config cfg=lane->player.sequence.config;
        cfg.mode=(arp_sequence_mode)o.mode;cfg.range=(uint8_t)o.range;cfg.length=darp_length;cfg.active=lane->source_empty?0:darp_mask;
        cfg.probability_on=1;cfg.probability=darp_rhythm[lane->track].probability;
        for(unsigned i=0;i<16;i++)cfg.offset[i]=darp_offsets[i];
        imported_timing(lane->track,&cfg);
        cfg.key=lane->source_kind==ARP_SOURCE_FIXED?darp_key[lane->track]:0;
        cfg.scale=(uint8_t)lane->source_preset;
        if(wanted_notes!=lane->applied_notes || source_edit){
            uint8_t notes[16];int count=resolve_pool(lane,wanted_notes,notes);
            if(count<0){++darp_errors;cancel(lane,now);return;}
            lane->source_empty=!count;cfg.active=count?darp_mask:0;
            if(!count){notes[0]=(uint8_t)lane->source_root;count=1;}
            if(arp_player_repool(&lane->player,&cfg,notes,(unsigned)count)){++darp_errors;cancel(lane,now);return;}
            lane->applied_notes=wanted_notes;
        }
        /* Preserve progress within the current interval when scale changes.
         * At most 368640 ticks remain; x48 stays within uint32. */
        if(scale!=lane->scale){
            uint32_t remain=lane->player.next_tick-lane->player.tick;
            lane->player.next_tick=lane->player.tick+(remain*scale+lane->scale-1)/lane->scale;
            lane->scale=scale;
        }
        if(arp_player_edit(&lane->player,&cfg,darp_periods[o.rate]*scale,darp_scale_note(darp_duration(o.note),scale))){++darp_errors;cancel(lane,now);return;}
        lane->last_revision=darp_revision;
    }
    }
    uint32_t elapsed=horizon-lane->last_clock;
    /* A tempo decrease can pull the lookahead horizon back behind already
     * scheduled notes. Wait for it to catch up rather than cancelling them. */
    if(elapsed>=0x80000000u)return;
    if(elapsed>16u*DARP_UNITS_PER_TICK){++darp_errors;cancel(lane,now);return;}
    lane->last_clock=horizon;lane->fraction+=elapsed;
    while(lane->fraction>=DARP_SCALE_CLOCK_UNIT && lane->active){
        /* Skip quiet fine ticks; only invoke the player at actual deadlines.
         * This avoids multiplying per-render CPU work by the clock refinement.
         * All differences are modular within the existing bounded horizon. */
        uint32_t available=lane->fraction/DARP_SCALE_CLOCK_UNIT;
        uint32_t next=lane->player.next_tick-lane->player.tick;
        if(lane->player.sounding){
            uint32_t off=lane->player.off_tick-lane->player.tick;if(off<next)next=off;
        }
        if(lane->player.finite){
            uint32_t end=lane->player.end_tick-lane->player.tick;if(end<next)next=end;
        }
        if(!next){++darp_errors;cancel(lane,now);return;}
        uint32_t skip=next>available?available:next-1;
        lane->musical_tick+=skip;lane->player.tick+=skip;
        lane->fraction-=skip*DARP_SCALE_CLOCK_UNIT;
        if(next>available)break;
        lane->fraction-=DARP_SCALE_CLOCK_UNIT;++lane->musical_tick;
        lane->emit_date=horizon-lane->fraction;
        int result=arp_player_advance(&lane->player,lane->musical_tick);
        lane->probability_state=lane->player.sequence.probability_state;
        if(result){cancel(lane,now);return;}
        if(!lane->player.running)lane->active=0;
    }
}

static void service_lane(struct darp_lane *lane,int ready){
    if(!lane->active && !lane->player.sounding && !lane->cycle_fault &&
       lane->cycle_read==lane->cycle_write && !lane->wait_me_trig &&
       !lane->release_reserve.message && !lane->release_reserve.bucket && !darp_enabled){
        if(lane->track<8)darp_locks_service(lane->track,CORE_AUDIO_CLOCK,0);
        return;
    }
    uint32_t horizon=CORE_AUDIO_CLOCK+(lane->track<8?2*CORE_AUDIO_TEMPO:0);
    if(lane->cycle_fault){lane->cycle_fault=0;cancel(lane,CORE_AUDIO_CLOCK);}
    for(unsigned work=0;work<8 && lane->cycle_read!=lane->cycle_write;work++){
        unsigned at=lane->cycle_read&7u;
        uint32_t date=lane->cycle[at].date,pattern=lane->cycle[at].pattern;
        if(pattern!=CORE_AUDIO_PATTERN || !lane->active || lane->cycle[at].generation!=lane->generation){++lane->cycle_read;continue;}
        if(horizon-date>=0x80000000u)break;
        ++lane->cycle_read;
        uint32_t cursor=lane->melody_mode?darp_me_player.now:lane->last_clock;
        if(date-cursor>=0x80000000u){++darp_cycle_errors[lane->track];continue;}
        /* An already rendered timestamp cannot be replayed: that would
         * create a second attack. A coincident natural ME wrap is already
         * at the requested origin; otherwise report the late notification. */
        if(date==cursor){
            if(lane->melody_mode && darp_me_player.loop_start==date){
                ++darp_cycle_rewinds[lane->track];lane->boundary_date=date;lane->boundary_valid=1;
            }else ++darp_cycle_errors[lane->track];
            continue;
        }
        service_lane_to(lane,date-1u,ready);
        if(!lane->active)continue;
        int result;
        if(lane->melody_mode){
            result=melody_player_rewind(&darp_me_player,date);
            if(!result)darp_me_cycle(date);
        }else if(!lane->player.finite){
            if(lane->fraction)++lane->musical_tick;
            lane->fraction=0;lane->last_clock=lane->emit_date=date;
            result=arp_player_rewind(&lane->player,lane->musical_tick);
        }else result=0;
        if(result){++darp_errors;cancel(lane,CORE_AUDIO_CLOCK);}
        else{++darp_cycle_rewinds[lane->track];lane->boundary_date=date;lane->boundary_valid=1;}
    }
    service_lane_to(lane,horizon,ready);
    /* A stopped lane cannot retain notifications for a future playback. */
    if(!lane->active)lane->cycle_read=lane->cycle_write;
}

void darp_service(void){
    darp_print_poll();
    if(darp_temp_pending){
        for(unsigned t=0;t<DARP_TRACKS;t++){
            uint32_t generation=lanes[t].generation;
            cancel(&lanes[t],CORE_AUDIO_CLOCK);
            if(lanes[t].generation==generation)++lanes[t].generation;
            lanes[t].prepared_message=0;
            darp_locks_finish(t,0); /* native reload already installed its kit */
        }
        darp_temp_apply();
    }
    darp_store_audio_select();
    for(unsigned mt=0;mt<8;mt++)if(midi_context_pending&(1u<<mt)){if(!darp_midi_output_off(mt,CORE_AUDIO_CLOCK))midi_context_pending&=~(1u<<mt);}
    int ready=darp_store_audio_ready();
    for(unsigned t=0;t<DARP_TRACKS;t++)service_lane(&lanes[t],ready);
}

void darp_clear_track(unsigned t){
    if(t>=DARP_TRACKS)return;
    uint32_t sr=core_audio_irq_save();struct darp_lane *lane=&lanes[t];
    uint32_t generation=lane->generation,revision=darp_controls[t].revision+1u;
    cancel(lane,CORE_AUDIO_CLOCK);
    if(lane->generation==generation)++lane->generation;
    lane->prepared_message=0;lane->probability_state=0;
    darp_locks_finish(t,1);
    darp_me_reset_track(t);
    darp_controls[t]=(darp_track_controls)DARP_INITIAL;
    darp_controls[t].revision=revision;
    darp_rhythm[t]=(darp_rhythm_controls)RHYTHM_INITIAL;
    darp_manual[t]=(arp_manual_notes){.octave=5};
    darp_fixed_root[t]=60;darp_fixed_octave[t]=5;darp_key[t]=0;
    darp_root[t]=0;darp_root_valid[t]=0;
    darp_lfo3_clear(t);darp_print_clear_track(t);
    core_audio_irq_restore(sr);
}

void darp_store_reset_audio(void){
 for(unsigned t=0;t<DARP_TRACKS;t++){
  if(t>=8){midi_context_pending|=1u<<(t-8);darp_midi_output_cancel(t-8);}
  darp_lfo_reset_track(t);darp_me_reset_track(t);
  uint32_t gen=lanes[t].generation;cancel(&lanes[t],CORE_AUDIO_CLOCK);if(lanes[t].generation==gen)++lanes[t].generation;
  lanes[t].prepared_message=0;darp_locks_finish(t,0);
  if(t>=8){darp_controls[t]=(darp_track_controls)DARP_INITIAL;darp_rhythm[t]=(darp_rhythm_controls)RHYTHM_INITIAL;darp_manual[t]=(arp_manual_notes){.octave=5};darp_fixed_root[t]=60;darp_fixed_octave[t]=5;darp_key[t]=0;}
  /* Last heard TRIG roots belong to the old pattern/project, not its
   * successor. They are transient display/source state, never settings. */
  darp_root[t]=0;darp_root_valid[t]=0;
 }
}

/* Retire the old generator without posting another OFF at the handoff.
 * The real native boundary attack/release owns that transition. */
void darp_print_retire_audio(unsigned t){
 if(t>=DARP_TRACKS)return;
 struct darp_lane *lane=&lanes[t];++lane->generation;lane->active=0;
 if(t>=8)darp_midi_output_cancel(t-8);
 lane->player.running=0;lane->player.sounding=0;lane->prepared_message=0;
 darp_me_player_tracks[t].running=0;darp_me_player_tracks[t].sounding=0;
 darp_locks_finish(t,1);
}

/* Native MIDI kind-3 render dispatch. Prefix a reserved old OFF before
 * the source, preserving native lock-list ownership and ordering. Generated
 * notes pass through; the task-side candidates handle their lifetime. */
static uint32_t midi_prefix_join(uint32_t head,uint32_t tail){
 if(!head)return tail;
 if(!tail)return head;
 uint32_t p=head;for(unsigned i=0;i<8;i++){uint32_t next=((uint32_t *)p)[11];if(!next){((uint32_t *)p)[11]=tail;return head;}p=next;}return head;
}
uint32_t darp_midi_dispatch(uint32_t *message,uint32_t date){
 uint32_t p=message[4];if(!p || message[0]!=3)return 0;
 uint32_t *v=(uint32_t *)p;unsigned mt=v[1];if(mt>=8)return 0;
 darp_store_audio_select();uint32_t prefix=0;
 /* A context switch can occur earlier in the same render bucket on an
  * AUDIO event. Keep old releases reserved until they can precede this
  * first MIDI event; otherwise an old queued OFF could cut the new note. */
 for(unsigned t=0;t<8;t++)if(midi_context_pending&(1u<<t)){
  prefix=midi_prefix_join(prefix,darp_midi_output_take_release(t,date));midi_context_pending&=~(1u<<t);
 }
 if(darp_midi_output_owned(p))return prefix;
 unsigned t=mt+8;struct darp_lane *lane=&lanes[t];unsigned was_enabled=darp_controls[t].enabled;
 darp_print_handoff_dispatch(message,date);
 if(was_enabled && !darp_controls[t].enabled){darp_midi_output_cancel(mt);return midi_prefix_join(prefix,darp_midi_output_take_release(mt,date));}
 if((v[10]>1 && v[2]==1) || !darp_controls[t].enabled){
  darp_midi_output_cancel(mt);prefix=midi_prefix_join(prefix,darp_midi_output_take_release(mt,date));
  lane->active=lane->player.running=lane->player.sounding=0;darp_me_player.running=darp_me_player.sounding=0;++lane->generation;return prefix;
 }
 if(v[10]!=1 || v[2]!=1 || (v[3]&0x81u)!=0x81u)return prefix;
 unsigned count=v[4],root=*((uint8_t *)v+20),velocity=*((uint8_t *)v+31);
 if(!velocity){
  darp_midi_output_cancel(mt);prefix=midi_prefix_join(prefix,darp_midi_output_take_release(mt,date));
  lane->active=lane->player.running=lane->player.sounding=darp_me_player.running=darp_me_player.sounding=0;++lane->generation;
  v[3]&=~0x80u;return prefix;
 }
 if(!count || count>4 || root>127 || velocity>127 || v[6]>0x3fffffffu)return prefix;
 uint32_t fake[19]={0};fake[1]=1;fake[2]=t;fake[3]=1;fake[5]=velocity<<24;fake[6]=root;fake[9]=v[3];fake[12]=2*v[6];
 darp_dispatch(fake,date);
 if(lane->prepared_message!=(uint32_t)fake){if(!(fake[9]&0x80u))v[3]&=~0x80u;return prefix;}
 uint32_t previous=0;unsigned attack=!lane->prepared_empty;
 if(!ME_READER){arp_sequence preview;arp_sequence_result first;
  if(arp_sequence_init(&preview,&lane->prepared.sequence,lane->prepared_notes,lane->prepared_count) || arp_sequence_next(&preview,&first))attack=0;
  else attack=first.kind==ARP_SEQ_NOTE;
 }
 if(darp_midi_output_adopt(p,mt,fake[6],fake[5]>>24,date,attack,&previous)){
  darp_midi_output_cancel(mt);prefix=midi_prefix_join(prefix,darp_midi_output_take_release(mt,date));lane->active=0;lane->prepared_message=0;++darp_errors;return prefix;
 }
 darp_start(fake,date);return midi_prefix_join(prefix,previous);
}
