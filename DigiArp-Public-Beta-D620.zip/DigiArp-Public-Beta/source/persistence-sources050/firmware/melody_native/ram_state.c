/* SPDX-License-Identifier: MIT */
/* State validation/defaults only. No serializer, hash, disk or filesystem. */
#include "../../src/arp_snapshot.h"
int arp_snapshot_valid(const arp_snapshot_state *s){
 if(!s)return 0;
 for(unsigned t=0;t<8;t++){
  const arp_snapshot_track *p=&s->track[t];uint32_t v=p->settings;
  if(p->enabled>1 || (v&255)>5 || ((v>>8)&255)>17 || ((v>>16)&255)>127 || (v>>24)<1 || (v>>24)>8 || !p->length || p->length>16 || p->source<3 || p->source>5 || p->preset>=23 || !p->count || p->count>16 || p->manual_count>16 || p->manual_octave>10 || p->fixed_octave>10 || p->fixed_root>127 || p->key>12 || p->probability>100 || (p->pulses!=255 && p->pulses>p->length) || p->rotation>=p->length)return 0;
  for(unsigned l=0;l<2;l++)if(p->lfo[l] && (p->lfo[l]<53 || p->lfo[l]>55))return 0;
  for(unsigned i=0;i<16;i++){
   if(p->offsets[i]<-64 || p->offsets[i]>63)return 0;
   if(i<p->manual_count){if(p->manual[i]>127)return 0;for(unsigned j=0;j<i;j++)if(p->manual[i]==p->manual[j])return 0;}
  }
 }
 return 1;
}
void arp_snapshot_default(arp_snapshot_state *s){
 *s=(arp_snapshot_state){0};for(unsigned t=0;t<8;t++){
  arp_snapshot_track *p=&s->track[t];p->settings=0x011e0900u;p->mask=0xffff;p->length=16;p->source=3;p->preset=2;p->count=1;p->manual_octave=5;p->fixed_root=60;p->fixed_octave=5;p->probability=100;p->pulses=255;
 }
}
