/* SPDX-License-Identifier: GPL-2.0-or-later */
#include <stdint.h>
#include "native_ui.h"
extern unsigned char darp_native_bank_key(void *,void *);
volatile uint8_t *darp_ui_bank_view;
/* OS1.54 BankView::key; preserve native dispatch, only remember its live
 * view for the same +0x88 mode test used by 0x4003639e. No view writes. */
uint32_t darp_bank_key(void *view,void *event){
    darp_ui_bank_view=view;return darp_native_bank_key(view,event);
}
int darp_native_mute(void){
    return darp_ui_bank_view && darp_ui_bank_view[0x88]!=0;
}
int darp_native_recording(void){
    /* 0x40138928's initialized singleton; 0x4009359c reads these exact
     * enabled/record bytes. Never call the allocating singleton accessor. */
    const volatile uint8_t *ctx=*(const uint8_t *volatile *)0x421fab88;
    return ctx && ctx[0x161] && ctx[0x168];
}
