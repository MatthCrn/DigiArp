/* SPDX-License-Identifier: GPL-2.0-or-later */
#include "lfo.h"
#include "digitakt-mk1/core3.h"
#include "core_audio.h"
extern unsigned darp_lfo_editing(void);
static uint32_t ids[53+DARP_LFO_TARGETS],*borrowed,old_start,old_end;
/* The verified ModDestListView constructor's +b4 is the owning sound slot.
 * Only the audio LFO destination slots 4/12 get virtual items. */
void darp_lfo_list_extend(uint32_t *vector,uint32_t *model){
    unsigned slot=model[0xb4/4],track=model[0xa0/4];
    if(borrowed || fw_active_track>=8 || (slot!=4 && slot!=12) || track>=8)return;
    uint32_t lo=vector[0],hi=vector[1];
    if(lo<0x40000000u || hi<lo || hi>0x48000000u || (lo&3) || (hi-lo)%4 || (hi-lo)/4>53)return;
    unsigned n=(hi-lo)/4;const uint32_t *p=(const uint32_t *)lo;
    for(unsigned i=0;i<n;i++)ids[i]=p[i];
    for(unsigned i=0;i<DARP_LFO_TARGETS;i++)ids[n+i]=171+i;
    borrowed=vector;old_start=lo;old_end=hi;
    vector[0]=(uint32_t)ids;vector[1]=(uint32_t)(ids+n+DARP_LFO_TARGETS);
    uint32_t kit=*(volatile uint32_t *)0x4199ec44;
    int dest=darp_lfo_editing()?darp_lfo3[track][3]/256:
        *(volatile int16_t *)(kit+0x20+0xa2*track+20+2*slot)/256;
    unsigned r=dest>=DARP_LFO_DEST_FIRST && dest<=DARP_LFO_DEST_LAST?(unsigned)(dest-52):0;
    if(r && r<=DARP_LFO_TARGETS){model[0xa8/4]=170+r;model[0xac/4]=170+r;}
    else if(darp_lfo_editing()){
        for(unsigned i=0;i<n;i++){
            int native_slot=((int32_t (*)(int32_t))0x40078d80)(p[i]);
            if(native_slot==dest){model[0xa8/4]=p[i];model[0xac/4]=p[i];break;}
        }
    }
}
void darp_lfo_list_restore(void){
    if(!borrowed)return;
    borrowed[0]=old_start;borrowed[1]=old_end;borrowed=0;
}
void darp_lfo_row(void *result,int32_t id){
    static const char *const names[DARP_LFO_TARGETS]={"ARP: OCT","ARP: MODE","ARP: NOTES","ME RHY","ME MOT","ME OCT","ME VAR","ME PRESET","ME RISE"};
    if(id<171 || id>=171+DARP_LFO_TARGETS)return;
    char allocator=0;
    ((void (*)(void *,const char *,void *))0x4017af20)(result,names[id-171],&allocator);
}
/* Native encoder DEST stepper ABI, confirmed in OS1.54 disassembly.
 * Virtual slots 53..61 are values of DEST only, never sound-array indexes.
 * The native DSP rejects these values; pre/post additionally removes them. */
extern void darp_lfo_get_list(uint32_t out[2],void *reference,uint32_t mask);
extern int32_t darp_lfo_native_increment(void *,int32_t,int32_t,uint32_t);
int32_t darp_lfo_increment(void *reference,int32_t current,int32_t delta,uint32_t mask){
    if(fw_active_track>=8 || (mask!=3584 && mask!=1536))return darp_lfo_native_increment(reference,current,delta,mask);
    if(!delta)return current;
    uint32_t list[2];darp_lfo_get_list(list,reference,mask);
    const uint32_t *v=(const uint32_t *)list[0];
    const uint32_t *begin=(const uint32_t *)v[0];unsigned n=(v[1]-v[0])/4;
    int slot=current/256,id;
    if(slot>=DARP_LFO_DEST_FIRST && slot<=DARP_LFO_DEST_LAST)id=171+slot-53;
    else{
        uint32_t *vt=*(uint32_t **)reference;
        id=((int32_t (*)(void *,int32_t))vt[20])(reference,slot);
    }
    int index=0;
    for(unsigned i=0;i<n;i++)if(begin[i]==(unsigned)id){index=(int)i;break;}
    if(id>=171 && id<171+DARP_LFO_TARGETS)index=(int)n+id-171;
    int step=delta/256;
    index+=step;if(index<0)index=0;if(index>(int)n+DARP_LFO_TARGETS-1)index=(int)n+DARP_LFO_TARGETS-1;
    if(index>=(int)n)slot=53+index-(int)n;
    else slot=((int32_t (*)(int32_t))0x40078d80)((int32_t)begin[index]);
    ((void (*)(void *))0x40137944)(list+1);
    return slot*256;
}

extern int32_t darp_lfo_native_validate(void *,int32_t,int32_t);
int32_t darp_lfo_validate(void *reference,int32_t parameter,int32_t value){
    if((parameter==55 || parameter==64) && value>=53*256 && value<=DARP_LFO_DEST_LAST*256 && !(value&255))return 1;
    return darp_lfo_native_validate(reference,parameter,value);
}

extern void darp_lfo_native_change(void *,int32_t,int32_t);
void darp_lfo_change(uint32_t *model,int32_t id,int32_t reason){
    unsigned slot=model[0xb4/4],track=model[0xa0/4];
    if(!id && fw_active_track<8 && (slot==4 || slot==12) && track<8){
        uint32_t kit=*(volatile uint32_t *)0x4199ec44;
        int dest=darp_lfo_editing()?darp_lfo3[track][3]/256:
            *(volatile int16_t *)(kit+0x20+0xa2*track+20+2*slot)/256;
        if(dest>=DARP_LFO_DEST_FIRST && dest<=DARP_LFO_DEST_LAST)id=171+dest-53;
    }
    darp_lfo_native_change(model,id,reason);
}
extern int32_t darp_text_at(void *,const void *,int32_t,int32_t,int32_t,const char *);
/* Executed after the shared machine-pages prologue, so the native SRC
 * hook remains composable. Argument tuple: id,value,flag,reserved,bmp,x,y. */
extern void darp_lfo_observe(unsigned);
extern unsigned darp_lfo_editing(void);
int32_t darp_lfo_draw_destination(uint32_t *a){
    unsigned id=a[0];
    if(id==55 || id==64)darp_lfo_observe(id==55?1:2);
    if(id>=61 && id<=69 && darp_lfo_editing()){
        unsigned index=id==69?1:id-61;
        a[1]=(uint32_t)(int32_t)darp_lfo3[fw_active_track][index];
    }

    int slot=(int32_t)a[1]/256;
    if((a[0]!=55 && a[0]!=64) || slot<53 || slot>DARP_LFO_DEST_LAST)return 0;
    static const char *const labels[DARP_LFO_TARGETS]={"OCT","MODE","NOTES","RHY","MOT","OCT","VAR","PRESET","RISE"};
    void *bmp=(void *)a[4];int x=(int)a[5],y=(int)a[6];
    darp_text_at(bmp,fw_font5,x+3,y+11,-1,slot>=56?"ME":"ARP");
    darp_text_at(bmp,fw_font5,x+((slot==55 || slot==60)?0:3),y+3,-1,labels[slot-53]);
    return 1;
}

/* The popup's NO restores its opening ID through this exact call site. */
int32_t darp_lfo_id_slot(int32_t id){
    if(id>=171 && id<171+DARP_LFO_TARGETS)return id-118;
    return ((int32_t (*)(int32_t))0x40078d80)(id);
}

