/* SPDX-License-Identifier: GPL-2.0-or-later */
#include "temp_pattern.h"
#include "pattern_store.h"
#include "../../../project-persistence-lab050/project_manager.h"
#include "core_audio.h"
#include "digitakt-mk1/core3.h"
extern unsigned char darp_native_pattern_save(void *,unsigned,unsigned,unsigned,unsigned);
extern unsigned char darp_native_pattern_reload(void *,unsigned,unsigned,unsigned,unsigned);
/* Native Temp Area owner identity, same accessor/comparison as OS1.54. */
#define PROJECT_ID ((uint32_t (*)(void *))0x40014cd4)
static arp_snapshot_state saved,stage;
static uint32_t saved_project,staged_project,valid,staged_me;
volatile uint32_t darp_temp_pending,darp_temp_saves,darp_temp_reloads,darp_temp_misses;
void darp_temp_apply(void){if(staged_project!=darp_ram_project_id()){arp_snapshot_default(&stage);valid=0;staged_me=0;}darp_ram_restore(&stage);darp_project_temp_restore(staged_me,staged_project);darp_temp_pending=0;++darp_temp_reloads;}
unsigned darp_temp_save(void *project,unsigned temporary,unsigned pattern,unsigned sequence,unsigned kit){
 arp_snapshot_state next;unsigned ok=!darp_temp_pending;uint32_t irq=core_audio_irq_save();
 if(ok)darp_ram_capture(&next,(const unsigned char *)fw_kit);
 core_audio_irq_restore(irq);
 darp_project_temp_begin(ok && (temporary&255u) && (sequence&255u) && (kit&255u),PROJECT_ID(project));
 unsigned result=darp_native_pattern_save(project,temporary,pattern,sequence,kit);
 darp_project_temp_commit(result);
 if(result){valid=0;if((temporary&255u) && (sequence&255u) && (kit&255u) && ok && arp_snapshot_valid(&next)){
  saved=next;saved_project=PROJECT_ID(project);valid=1;++darp_temp_saves;
 }}return result;
}
unsigned darp_temp_reload(void *project,unsigned temporary,unsigned pattern,unsigned sequence,unsigned kit){
 unsigned result=darp_native_pattern_reload(project,temporary,pattern,sequence,kit);
 if(result && (kit&255u)){
  int match=(temporary&255u) && (sequence&255u) && valid && saved_project==PROJECT_ID(project);
  uint32_t irq=core_audio_irq_save();staged_me=(temporary&255u) && (sequence&255u) && darp_project_temp_available(PROJECT_ID(project));if(match)stage=saved;else{arp_snapshot_default(&stage);valid=0;++darp_temp_misses;}staged_project=PROJECT_ID(project);darp_temp_pending=1;core_audio_irq_restore(irq);
  if(match && fw_kit)for(unsigned t=0;t<8;t++)for(unsigned l=0;l<2;l++)if(stage.track[t].lfo[l]){
   int value=256*stage.track[t].lfo[l];*(volatile int16_t *)(fw_kit+0x20+0xa2*t+20+2*(4+8*l))=(int16_t)value;fw_set_param(value,(int32_t)t,(int32_t)(4+8*l));
  }
 }return result;
}
