/* SPDX-License-Identifier: GPL-2.0-or-later */
/* Bounded note queue adapter. Mirrors stock 1.54's insertion ordering,
 * including its busy root, without calling the allocator that spins empty.
 * Only generated kind-3 messages with native-pool MIDI payloads; explicit MIDI
 * index 0..7. Payload lifetime is handled separately, not a lock-copy API. */
#include "midi_queue.h"
#define W(p,k) (*(volatile uint32_t *)((p)+4u*(k)))
#define ROOT W(0x421f7ee0u,0)
#define FB W(0x421f7ee8u,0)
#define FM W(0x421f7eecu,0)
static int valid(uint32_t p,uint32_t lo,uint32_t hi,uint32_t stride) {
    return p>=lo && p<hi && (p-lo)%stride==0;
}
volatile uint32_t midi_queue_faults;
static int fault(void){++midi_queue_faults;return 0;}
static int message_valid(uint32_t p){return valid(p,0x421f58e0u,0x421f7ee0u,76);}
static int bucket_owned(uint32_t p){return valid(p,0x421f53e0u,0x421f58e0u,20);}
/* Stock also owns heap buckets: do not restrict the active list to our pool. */
static int bucket_valid(uint32_t p){return p>=0x40000000u && p<=0x47ffffecu && !(p&3u);}
static int reserve(midi_queue_reservation *r) {
    if(!r)return fault();
    if(r->message || r->bucket)return message_valid(r->message) && bucket_owned(r->bucket)?1:fault();
    uint32_t m=FM,b=FB;
    if((m && !message_valid(m)) || (b && !bucket_owned(b)))return fault();
    if(!m || !b)return 0;
    FM=W(m,18);FB=W(b,4);r->message=m;r->bucket=b;return 1;
}
static void unreserve(midi_queue_reservation *r) {
    if(!r){fault();return;}
    if((r->message && !message_valid(r->message)) || (r->bucket && !bucket_owned(r->bucket))){fault();return;}
    if(r->message){W(r->message,18)=FM;FM=r->message;r->message=0;}
    if(r->bucket){W(r->bucket,4)=FB;FB=r->bucket;r->bucket=0;}
}
int midi_queue_reserve(midi_queue_reservation *r) {
    uint32_t sr=core_audio_irq_save();int ok=reserve(r);core_audio_irq_restore(sr);return ok;
}
void midi_queue_unreserve(midi_queue_reservation *r) {
    uint32_t sr=core_audio_irq_save();unreserve(r);core_audio_irq_restore(sr);
}
/* Modular order within half-range, without implementation-defined signed casts. */
static int before(uint32_t a,uint32_t b){return (a-b)>0x7fffffffu;}
static uint32_t post(midi_queue_reservation *r,const midi_queue_note *e,uint32_t date) {
    if(!r || !e)return fault();
    if(!message_valid(r->message) || !bucket_owned(r->bucket))return fault();
    if(e->track>7 || !e->payload)return 0;
    uint32_t prev=0,cur=ROOT,same=0,n=0;
    if(cur && !bucket_valid(cur))return fault();
    if(cur && W(cur,0)){prev=cur;cur=W(cur,4);}
    while(cur) {
        if(++n>128 || !bucket_valid(cur))return fault();
        if(W(cur,1)==date){same=cur;break;}
        if(before(date,W(cur,1)))break;
        prev=cur;cur=W(cur,4);
    }
    uint32_t tail=same?W(same,3):0;
    if(same && !message_valid(tail))return fault();
    uint32_t m=r->message,b=r->bucket;
    for(unsigned i=0;i<19;i++)W(m,i)=0;
    W(m,0)=3;W(m,2)=e->track+8;W(m,3)=1;W(m,4)=e->payload;
    if(same) {
        W(tail,18)=m;W(same,3)=m;
        W(b,4)=FB;FB=b;
    } else {
        W(b,0)=0;W(b,1)=date;W(b,2)=m;W(b,3)=m;W(b,4)=cur;
        if(prev)W(prev,4)=b;else ROOT=b;
    }
    r->message=0;r->bucket=0;return m;
}
uint32_t midi_queue_post_reserved(midi_queue_reservation *r,const midi_queue_note *e,uint32_t date) {
    uint32_t sr=core_audio_irq_save();uint32_t m=post(r,e,date);core_audio_irq_restore(sr);return m;
}
uint32_t midi_queue_try_post(const midi_queue_note *e,uint32_t date) {
    uint32_t sr=core_audio_irq_save();midi_queue_reservation r={0,0};uint32_t m=0;
    if(reserve(&r)){m=post(&r,e,date);if(!m)unreserve(&r);}
    core_audio_irq_restore(sr);return m;
}
