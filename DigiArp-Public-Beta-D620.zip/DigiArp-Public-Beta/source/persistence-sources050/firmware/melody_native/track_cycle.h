/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef DARP_TRACK_CYCLE_H
#define DARP_TRACK_CYCLE_H
#include <stdint.h>
#include "core_audio.h"
/* Existing step preparation callback, before conditions. A nonzero prepared
 * pointer identifies native re-arm, which is not a new musical boundary. */
/* Exact native grid date before conditions; also usable without a running
 * arp lane so PRINT does not depend on another source attack. */
static inline int darp_cycle_step_date(int32_t t,uint32_t pattern,int32_t step,const void *prepared,uint32_t *date){
 if(t<0 || t>=16 || step || prepared || CORE_AUDIO_RUNNING!=1 || !pattern || pattern!=CORE_AUDIO_PATTERN)return 0;
 const uint8_t *p=(const uint8_t *)pattern;
 unsigned index=p[0x1ec59]==1?*(volatile uint8_t *)(0x4199ec71u+t):*(volatile uint8_t *)0x4199ec70;
 if(index>6)return 0;
 int ticks=(int)((const uint32_t *)0x4018ed20)[index];
 int phase=*(volatile int8_t *)(0x4199ecc4u+t);
 int remain=*(volatile int8_t *)(0x4199ecd4u+t);
 if(phase==0)ticks-=remain;
 if(*(volatile uint16_t *)0x4199ece4&(1u<<t))ticks-=remain;
 if(ticks<1 || ticks>48)return 0;
 *date=*(volatile uint32_t *)0x41992b98+(unsigned)(ticks-1)*900000u;return 1;
}
void darp_cycle_native_step(int32_t track,uint32_t pattern,int32_t step,const void *prepared);
#endif
