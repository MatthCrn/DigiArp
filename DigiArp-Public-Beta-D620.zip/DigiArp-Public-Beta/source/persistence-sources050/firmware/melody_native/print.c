#include "lfo.h"
/* SPDX-License-Identifier: GPL-2.0-or-later */
#include "print.h"
#include "midi_output.h"
#include "controls.h"
#include "core_audio.h"
#include "track_scale.h"
#include "track_cycle.h"
#include "pattern_store.h"
#include "digitakt-mk1/core3.h"
arp_print darp_print;
unsigned darp_print_track,darp_print_confirm,darp_print_ui_error;
static uint8_t before[911],after[911];
static uint32_t project,enabled,geometry;
static uint32_t boundary_message,retired;
volatile uint32_t darp_print_boundary;
/* UI errors: 1 no source trig, 3 microtiming, 4 arp/run,
 * 5 context edited, 6 unsupported duration, 7 stopped required, 8 LFO, 9 queue. */
static int eq(const uint8_t *a,const uint8_t *b,unsigned n){for(unsigned i=0;i<n;i++)if(a[i]!=b[i])return 0;return 1;}
static unsigned rd16(const uint8_t *p){return (unsigned)p[0]*256u+p[1];}
static uint8_t *track(void){return (uint8_t *)darp_print.context+911*darp_print_track;}
static unsigned count_steps(const uint8_t *pat,unsigned t){return pat[0x1ec59]==1?rd16(pat+911*t+0x388):rd16(pat+0x1ec54);}
static uint32_t geom(const uint8_t *pat,unsigned t){return count_steps(pat,t)|(darp_scale_units(t,(uint32_t)pat)<<8)|((uint32_t)pat[0x1ec59]<<16);}
int darp_print_arm(unsigned t){
 darp_print_ui_error=darp_print_confirm=0;
 boundary_message=retired=darp_print_boundary=0;
 if(t>=16 || CORE_AUDIO_RUNNING!=1 || !darp_controls[t].enabled){darp_print_ui_error=4;return -1;}
 uint32_t irq=core_audio_irq_save();const uint8_t *pat=(const uint8_t *)CORE_AUDIO_PATTERN;
 if(!pat || pat!=(const uint8_t *)CORE_AUDIO_PATTERN){core_audio_irq_restore(irq);return -1;}
 const uint8_t *tr=pat+911*t;unsigned steps=count_steps(pat,t),scale=darp_scale_units(t,(uint32_t)pat);unsigned attacks=0,micro=0;
 if(steps>=1 && steps<=64)for(unsigned i=0;i<steps;i++){
  unsigned w=rd16(tr+2*i),syn=(w&0x800u)?(w&0x80u):(rd16(tr+0x382)&0x80u);
  if((w&1u) && syn){attacks++;if(tr[0x100+i])micro=1;}
 }
 unsigned error=!attacks?1:micro?3:0;
 /* LFO modulation of arp parameters cannot yet be baked faithfully across
  * the native playback engine. Reject instead of retaining live arp LFOs. */
 const uint8_t *kit=*(const uint8_t *const volatile *)0x800019ac;
 if(kit && t<8)for(unsigned l=0;l<2;l++){int v=*(const int16_t *)(kit+0x20+0xa2*t+20+2*(4+8*l))/256;if(v>=DARP_LFO_DEST_FIRST && v<=DARP_LFO_DEST_LAST)error=8;}
 if(error || arp_print_arm(&darp_print,(uint32_t)pat,steps,scale*900000u)){
  core_audio_irq_restore(irq);darp_print_ui_error=error?error:4;return -1;
 }
 for(unsigned i=0;i<911;i++)before[i]=tr[i];
 darp_print_track=t;project=darp_ram_project_id();geometry=geom(pat,t);enabled=darp_controls[t].enabled;
 core_audio_irq_restore(irq);return 0;
}
/* FUNC+CLEAR must not leave a PRINT undo or pending handoff that could
 * recreate the track after the native handler clears it. No track writes. */
void darp_print_clear_track(unsigned t){
 if(t!=darp_print_track)return;
 uint32_t irq=core_audio_irq_save();
 darp_print=(arp_print){0};darp_print_confirm=darp_print_ui_error=0;
 boundary_message=retired=darp_print_boundary=0;
 core_audio_irq_restore(irq);
}
void darp_print_cancel(void){if(darp_print.phase==ARP_PRINT_PREPARED || darp_print.phase==ARP_PRINT_QUEUED)return;uint32_t irq=core_audio_irq_save();darp_print.phase=ARP_PRINT_IDLE;darp_print_confirm=darp_print_ui_error=0;core_audio_irq_restore(irq);}
/* Source attacks may reset the arp, never the capture window. */
void darp_print_source(unsigned t,uint32_t date,unsigned rest){
 if(t==darp_print_track && rest)arp_print_silence(&darp_print,date);
}
void darp_print_cycle(unsigned t,uint32_t pattern,uint32_t date){
 if(t<DARP_TRACKS && t==darp_print_track && pattern==darp_print.context && darp_controls[t].enabled)
  arp_print_begin(&darp_print,date);
}
void darp_print_attack(unsigned t,const uint32_t *m,uint32_t date){
 if(t==darp_print_track && m[1]==1 && m[3]==1)arp_print_attack(&darp_print,date,m[6],m[5]>>24,m[12]);
}
void darp_print_poll(void){
 if(darp_print.phase!=ARP_PRINT_ARMED && darp_print.phase!=ARP_PRINT_RECORDING)return;
 uint32_t context=CORE_AUDIO_PATTERN;
 if(project!=darp_ram_project_id() || (context==darp_print.context && geometry!=geom((const uint8_t *)context,darp_print_track)) || (CORE_AUDIO_MUTES&(1u<<darp_print_track)) || !darp_controls[darp_print_track].enabled)context=0;
 arp_print_poll(&darp_print,CORE_AUDIO_CLOCK,CORE_AUDIO_RUNNING==1,context);
}
int darp_print_commit(void){
 darp_print_confirm=0;
 if(darp_print.phase!=ARP_PRINT_READY || project!=darp_ram_project_id() || CORE_AUDIO_PATTERN!=darp_print.context || geometry!=geom((const uint8_t *)darp_print.context,darp_print_track) || !eq(before,track(),911)){darp_print_ui_error=5;return -1;}
 uint32_t midi_lengths[129];const uint32_t *lengths=(const uint32_t *)0x40191590;
 if(darp_print_track>=8){for(unsigned i=0;i<129;i++)midi_lengths[i]=lengths[i]*2u;lengths=midi_lengths;}
 int r=arp_print_build(&darp_print,before,after,lengths);
 if(r){darp_print_ui_error=6;return -1;}
 if(darp_print_track>=8)for(unsigned i=0;i<darp_print.steps;i++)if(darp_print.step[i].active){after[0x2c0+i]=64;after[0x300+i]=64;after[0x340+i]=64;}
 uint32_t irq=core_audio_irq_save();
 if(CORE_AUDIO_RUNNING==1){darp_print.phase=ARP_PRINT_PENDING;core_audio_irq_restore(irq);return 0;}
 for(unsigned i=0;i<911;i++)track()[i]=after[i];
 darp_controls[darp_print_track].enabled=0;++darp_controls[darp_print_track].revision;darp_print.phase=ARP_PRINT_DONE;
 core_audio_irq_restore(irq);
 /* Stock stopped-track prepare; also used by seq-events' sq_rearm. */
 ((void (*)(int32_t))0x4006fb82)((int32_t)darp_print_track);
 (void)darp_store_flush();return 0;
}
int darp_print_undo(void){
 if(CORE_AUDIO_RUNNING==1 || darp_print.phase!=ARP_PRINT_DONE || project!=darp_ram_project_id() || CORE_AUDIO_PATTERN!=darp_print.context || !eq(after,track(),911)){darp_print_ui_error=5;return -1;}
 uint32_t irq=core_audio_irq_save();for(unsigned i=0;i<911;i++)track()[i]=before[i];
 darp_controls[darp_print_track].enabled=enabled;++darp_controls[darp_print_track].revision;darp_print.phase=ARP_PRINT_IDLE;darp_print_ui_error=0;
 core_audio_irq_restore(irq);((void (*)(int32_t))0x4006fb82)((int32_t)darp_print_track);(void)darp_store_flush();return 0;
}

static int live_context(void){
 return project==darp_ram_project_id() && CORE_AUDIO_PATTERN==darp_print.context && geometry==geom((const uint8_t *)darp_print.context,darp_print_track);
}
static void abort_live(void){
 /* Restore only our untouched staged data, never overwrite a user's edit
  * or a new project that reuses the same RAM address. */
 if(project==darp_ram_project_id() && eq(after,track(),911)){
  for(unsigned i=0;i<911;i++)track()[i]=before[i];
 }else if(live_context()){
  darp_controls[darp_print_track].enabled=0;++darp_controls[darp_print_track].revision;
  darp_print_retire_audio(darp_print_track);
 }
 boundary_message=0;darp_print.error=ARP_PRINT_CONTEXT;darp_print.phase=ARP_PRINT_ERROR;
}
extern uint32_t darp_print_native_midi_fire(int32_t,void *,void *,int32_t,void *,void *);
extern uint32_t darp_print_native_fire(int32_t,void *,void *,int32_t,void *,void *);
uint32_t darp_print_fire(int32_t t,void *pat,void *kit,int32_t step,void *event,void *delay){
 darp_cycle_native_step(t,(uint32_t)pat,step,event);
 uint32_t date;
 if(darp_print.phase==ARP_PRINT_PENDING && t==(int32_t)darp_print_track &&
    darp_cycle_step_date(t,(uint32_t)pat,step,event,&date)){
  uint32_t irq=core_audio_irq_save();
  if(!live_context() || !eq(before,track(),911)){
   darp_print.error=ARP_PRINT_CONTEXT;darp_print.phase=ARP_PRINT_ERROR;
  }else{
   /* A silent marker retires the arp exactly at the grid date. Stage before
    * native preparation: even a consumed 1ST or a first-step rest works.
    * The marker is inaudible unless converted to a release for that rest. */
   core_audio_note marker={0,0,2,0xffffffffu,0,0,darp_print_track};
   uint32_t pointer=t<8?core_audio_try_post(&marker,date):darp_midi_output_marker((unsigned)t-8,date);
   if(!pointer){darp_print_ui_error=9;darp_print.error=ARP_PRINT_CONTEXT;darp_print.phase=ARP_PRINT_ERROR;}
   else{
    for(unsigned i=0;i<911;i++)if(before[i]!=after[i])track()[i]=after[i];
    boundary_message=pointer;darp_print_boundary=date;retired=0;darp_print.phase=ARP_PRINT_QUEUED;
   }
  }
  core_audio_irq_restore(irq);
 }
 return t<8?darp_print_native_fire(t,pat,kit,step,event,delay):darp_print_native_midi_fire(t,pat,kit,step,event,delay);
}
extern uint32_t darp_print_native_queue(void *,uint32_t);
uint32_t darp_print_queue(uint32_t *m,uint32_t date){return darp_print_native_queue(m,date);}
void darp_print_handoff_dispatch(uint32_t *m,uint32_t date){
 if(darp_print.phase!=ARP_PRINT_QUEUED || m[2]!=darp_print_track || date-darp_print_boundary>=0x80000000u)return;
 if(!live_context() || !eq(after,track(),911)){
  if((uint32_t)m==boundary_message)m[3]=0xffffffffu;
  abort_live();return;
 }
 if(!retired){
  darp_controls[darp_print_track].enabled=0;++darp_controls[darp_print_track].revision;
  darp_print_retire_audio(darp_print_track);retired=1;
 }
 if((uint32_t)m==boundary_message && date==darp_print_boundary){
  if(darp_print_track>=8){m[3]=1;}else if(!darp_print.step[0].active){
   uint32_t owner=*(const volatile uint32_t *)(0x4399eb54+4*darp_print_track);
   uint32_t held=*(const volatile uint32_t *)(0x4399ec80+4*darp_print_track);
   if(owner==1 && held<=127){m[1]=2;m[3]=1;m[6]=held;}else m[3]=0xffffffffu;
  }else m[3]=0xffffffffu;
  boundary_message=0;darp_print.phase=ARP_PRINT_DONE;
 }
}
void darp_print_ui_tick(void){
 unsigned phase=darp_print.phase;
 if(phase!=ARP_PRINT_PENDING && phase!=ARP_PRINT_PREPARED && phase!=ARP_PRINT_QUEUED)return;
 uint32_t irq=core_audio_irq_save();
 if(!live_context() || !eq(phase==ARP_PRINT_PENDING?before:after,track(),911)){
  if(phase==ARP_PRINT_PENDING){darp_print.error=ARP_PRINT_CONTEXT;darp_print.phase=ARP_PRINT_ERROR;}
  else abort_live();
  core_audio_irq_restore(irq);return;
 }
 if(CORE_AUDIO_RUNNING==1){core_audio_irq_restore(irq);return;}
 /* STOP remains an optional emergency path, not a prerequisite. */
 if(phase==ARP_PRINT_PENDING)for(unsigned i=0;i<911;i++)track()[i]=after[i];
 darp_controls[darp_print_track].enabled=0;++darp_controls[darp_print_track].revision;
 darp_print_retire_audio(darp_print_track);boundary_message=0;darp_print.phase=ARP_PRINT_DONE;
 core_audio_irq_restore(irq);((void (*)(int32_t))0x4006fb82)((int32_t)darp_print_track);(void)darp_store_flush();
}
