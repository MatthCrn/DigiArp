/* SPDX-License-Identifier: GPL-2.0-or-later */
#include "lfo.h"
#include "digitakt-mk1/core3.h"

extern unsigned darp_lfo_editing(void);
extern void *pd_allocate(unsigned);
unsigned darp_lfo_ui_scope;

/* A shadow is attached only while a native UI operation owns the reference.
 * The original parameter operations remain responsible for calibration,
 * modifiers, legal destination lists and validation. Only storage changes. */
typedef struct {
    uint32_t *original;
    uint32_t table[34];
} lfo_reference;
static lfo_reference *references;

static lfo_reference *shadow(void *reference){
    uint32_t *table=*(uint32_t **)reference;
    if(references)for(unsigned i=0;i<4;i++)
        if(table==references[i].table+2)return references+i;
    return 0;
}
static int index_of(unsigned parameter){
    if(!darp_lfo_editing())return -1;
    if(parameter==69)return 1;
    return parameter>=61 && parameter<=68?(int)parameter-61:-1;
}
static int32_t read_value(void *reference,unsigned parameter){
    int index=index_of(parameter);
    if(index>=0)return darp_lfo3[fw_active_track][index];
    lfo_reference *s=shadow(reference);
    return ((int32_t (*)(void *,unsigned))s->original[10])(reference,parameter);
}
static void write_value(void *reference,unsigned parameter,int32_t value,
                        int32_t a,int32_t b,int32_t c){
    int index=index_of(parameter);
    if(index>=0){darp_lfo3[fw_active_track][index]=(int16_t)value;return;}
    lfo_reference *s=shadow(reference);
    ((void (*)(void *,unsigned,int32_t,int32_t,int32_t,int32_t))s->original[29])
        (reference,parameter,value,a,b,c);
}
static void write_lock(void *reference,unsigned parameter,int32_t value,
                       int32_t step,int32_t flags){
    int index=index_of(parameter);
    /* Step locks require their own pattern storage. Preserve both live banks
     * until that storage is implemented. */
    if(index>=0)return;
    lfo_reference *s=shadow(reference);
    ((void (*)(void *,unsigned,int32_t,int32_t,int32_t))s->original[13])
        (reference,parameter,value,step,flags);
}
static void notify_value(void *reference,unsigned parameter){
    if(index_of(parameter)>=0)return;
    lfo_reference *s=shadow(reference);
    ((void (*)(void *,unsigned))s->original[24])(reference,parameter);
}
unsigned darp_lfo_bind_reference(void *reference,unsigned parameter){
    if(!darp_lfo_ui_scope || index_of(parameter)<0 || shadow(reference))return 1;
    if(!references){
        references=pd_allocate(4*sizeof *references);
        if(!references)return 0;
        for(unsigned i=0;i<4;i++)references[i].original=0;
    }
    uint32_t *original=*(uint32_t **)reference;
    for(unsigned i=0;i<4;i++){
        lfo_reference *s=references+i;
        if(s->original && s->original!=original)continue;
        if(!s->original){
            s->original=original;
            /* Preserve RTTI entries immediately before the address point. */
            for(unsigned k=0;k<34;k++)s->table[k]=original[(int)k-2];
            s->table[12]=(uint32_t)read_value;
            s->table[15]=(uint32_t)write_lock;
            s->table[26]=(uint32_t)notify_value;
            s->table[31]=(uint32_t)write_value;
        }
        *(uint32_t **)reference=s->table+2;
        return 1;
    }
    return 0;
}

unsigned darp_lfo_bind_group(void *reference,unsigned group){
    return group==3?darp_lfo_bind_reference(reference,61):1;
}
