| OS 1.54, one native LFO iteration. The frame offsets below match the
| stock routine at 0x400ed766, including its shared register epilogue.
| C arguments: track words, tempo, trigger (0/1), eight parameter words,
| and a private, four-byte-aligned 40-byte oscillator state.
        .section .run,"ax"
        .globl darp_native_lfo_tick
darp_native_lfo_tick:
        lea -64(%sp),%sp
        movem.l %d2-%d7/%a2-%a6,(%sp)
        movea.l 68(%sp),%a5
        move.l 76(%sp),52(%sp)
        moveq #7,%d0
        move.l %d0,56(%sp)
        clr.l 60(%sp)
        movea.l 80(%sp),%a3
        addq.l #6,%a3
        movea.l 84(%sp),%a2
        lea 36(%a2),%a2
        lea -32(%a2),%a4
        moveq #0,%d6
        jmp 0x400ed7a6
