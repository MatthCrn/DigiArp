#include "lfo.h"
/* SPDX-License-Identifier: GPL-2.0-or-later */
/* RAM-only context markers, derived from digi1_mods kitstore semantics.
 * No reserved serialized bytes, serializer or filesystem API is used. */
#include "pattern_store.h"
#include "../../../project-persistence-lab050/project_manager.h"
#include "controls.h"
#include "melody_native.h"
#include "core_audio.h"
#include "digitakt-mk1/core3.h"
#define KIT0 0x4191f018u
#define KIT_STRIDE 0x91eu
#define MARK 0x4b53u
#define MARKW(k,t) (*(volatile uint16_t *)((k)+0x20+0xa2*(t)+0x14+2*51))
typedef struct {arp_snapshot_state state;uint32_t generation,epoch;} bank_item;
static bank_item bank[128];
volatile uint32_t darp_store_context_serial;
static uint32_t bound=0xffffffffu,bound_generation,started,project_identity,epoch;
volatile int32_t darp_store_error;
volatile uint32_t darp_store_saves,darp_store_loads,darp_store_applies;
/* Native working ProjectData = 0x409bbbfc (startup 0x40009bc0).
 * Project::identity 0x40014cd4 reads data+8; native creation 0x40014d04
 * regenerates that field. Read only, no extra serialized field is added. */
uint32_t darp_ram_project_id(void){return *(const volatile uint32_t *)0x409bbc04;}
static int index_of(const void *kit){uint32_t p=(uint32_t)kit;if(p<KIT0)return -1;p-=KIT0;return p%KIT_STRIDE || p/KIT_STRIDE>=128?-1:(int)(p/KIT_STRIDE);}
static unsigned char *kit_at(unsigned i){return (unsigned char *)(KIT0+KIT_STRIDE*i);}
static unsigned lost(unsigned char *kit){unsigned r=0;for(unsigned t=0;t<8;t++)if(MARKW(kit,t)!=MARK)r|=1u<<t;return r;}
/* Check the usual intact kit without computing a missing-track mask. */
static int intact(unsigned char *kit){
 return MARKW(kit,0)==MARK && MARKW(kit,1)==MARK && MARKW(kit,2)==MARK &&
        MARKW(kit,3)==MARK && MARKW(kit,4)==MARK && MARKW(kit,5)==MARK &&
        MARKW(kit,6)==MARK && MARKW(kit,7)==MARK;
}
static void mark(unsigned char *kit){for(unsigned t=0;t<8;t++)MARKW(kit,t)=MARK;}
static void bump(bank_item *p){if(!++p->generation)++p->generation;}
void darp_ram_capture(arp_snapshot_state *s,const unsigned char *kit){
 uint8_t *z=(uint8_t *)s;for(unsigned i=0;i<sizeof *s;i++)z[i]=0;
 uint32_t irq=core_audio_irq_save();
 for(unsigned t=0;t<8;t++){
  arp_snapshot_track *p=&s->track[t];const volatile darp_track_controls *c=&darp_controls[t];
  p->enabled=(uint8_t)darp_me_arp_state_track(t);p->settings=c->settings;p->mask=c->mask;p->length=c->length;p->source=c->source;p->preset=c->preset;p->count=c->chord_count;
  for(unsigned i=0;i<16;i++){p->offsets[i]=c->offsets[i];p->manual[i]=darp_manual[t].notes[i];}
  p->manual_count=darp_manual[t].count;p->manual_octave=darp_manual[t].octave;p->fixed_root=darp_fixed_root[t];p->fixed_octave=darp_fixed_octave[t];p->key=darp_key[t];
  p->probability=darp_rhythm[t].probability;p->pulses=darp_rhythm[t].pulses;p->rotation=darp_rhythm[t].rotation;
  for(unsigned l=0;l<2;l++){int v=kit?*(const volatile int16_t *)(kit+0x20+0xa2*t+20+2*(4+8*l))/256:0;p->lfo[l]=(uint8_t)(v>=DARP_LFO_DEST_FIRST && v<=DARP_LFO_DEST_LAST?v:0);}
 }
 core_audio_irq_restore(irq);
}
void darp_ram_apply_controls(const arp_snapshot_state *s,unsigned char *kit){
 for(unsigned t=0;t<8;t++){
  const arp_snapshot_track *p=&s->track[t];volatile darp_track_controls *c=&darp_controls[t];
  c->enabled=p->enabled;c->settings=p->settings;c->mask=p->mask;c->length=p->length;c->source=p->source;c->preset=p->preset;c->chord_count=p->count;
  for(unsigned i=0;i<16;i++){c->offsets[i]=p->offsets[i];darp_manual[t].notes[i]=p->manual[i];}
  darp_manual[t].count=p->manual_count;darp_manual[t].octave=p->manual_octave;darp_fixed_root[t]=p->fixed_root;darp_fixed_octave[t]=p->fixed_octave;darp_key[t]=p->key;
  darp_rhythm[t]=(darp_rhythm_controls){p->probability,p->pulses,p->rotation,0};++c->revision;
  /* Same proven native word/target buffers as STEP restoration. Repair only
   * custom destinations lost by stock's serializer; no task APIs in audio. */
  for(unsigned l=0;l<2;l++)if(p->lfo[l]){
   unsigned slot=4+8*l;int16_t value=(int16_t)(256*p->lfo[l]);
   *(volatile int16_t *)(kit+0x20+0xa2*t+20+2*slot)=value;
   *(volatile int16_t *)(0x800014f0u+18+106*t+2*slot)=value;
   *(volatile int16_t *)(0x80002760u+18+106*t+2*slot)=value;
   *(volatile uint32_t *)(0x80002b2cu+4*(9+53*t+slot))=(uint32_t)(uint16_t)value*65536u;
  }
 }
}

static void stash(unsigned i,unsigned char *kit){
 if(i>=128 || !epoch || bank[i].epoch!=epoch || lost(kit)==255)return;
 darp_ram_capture(&bank[i].state,kit);darp_project_stash(i);++darp_store_saves;
}
void darp_store_audio_select(void){
 unsigned char *kit=*(unsigned char *const volatile *)0x800019ac;
 if(!started)return;
 if(bound<128 && kit==kit_at(bound) && epoch && darp_ram_project_id()==project_identity &&
    bound_generation==bank[bound].generation && intact(kit))return;
 int index=index_of(kit);
 if(index<0)return;
 uint32_t identity=darp_ram_project_id();
 if(!epoch || identity!=project_identity){
  project_identity=identity;if(!++epoch)++epoch;bound=0xffffffffu;
 }
 bank_item *p=&bank[index];unsigned missing=lost(kit);
 if(bound==(unsigned)index && bound_generation==p->generation && !missing)return;
 /* A departed pattern retains its live settings only in our RAM bank.
  * All markers lost means the native kit/project was deserialized in place;
  * never attach the departed context's values to that newly loaded kit. */
 if(bound!=(unsigned)index && bound<128)stash(bound,kit_at(bound));
 if(p->epoch!=epoch || missing==255){arp_snapshot_default(&p->state);p->epoch=epoch;bump(p);++darp_store_loads;}
 if(missing)mark(kit); /* partial Sound loads keep the arp's RAM state */
 if(bound==(unsigned)index && bound_generation==p->generation)return;
 ++darp_store_context_serial;darp_store_reset_audio();darp_ram_apply_controls(&p->state,kit);darp_project_apply((unsigned)index,kit);
 bound=(unsigned)index;bound_generation=p->generation;++darp_store_applies;
}
int darp_store_audio_ready(void){
 unsigned char *kit=*(unsigned char *const volatile *)0x800019ac;
 return bound<128 && kit==kit_at(bound) && started && epoch &&
        darp_ram_project_id()==project_identity && bank[bound].epoch==epoch &&
        bound_generation==bank[bound].generation && intact(kit);
}
void darp_store_before_event(void){
 if(!fw_kit || index_of(fw_kit)<0)return;
 uint32_t irq=core_audio_irq_save();started=1;darp_store_audio_select();core_audio_irq_restore(irq);
}
int darp_store_flush(void){
 darp_store_before_event();int i=index_of(fw_kit);
 if(i<0 || !darp_store_audio_ready() || bound!=(unsigned)i)return 0;
 /* The departed pattern is captured by stash() at the audio handoff.
  * Recopying its classic controls on every UI tick is unnecessary; the task
  * snapshot already includes those controls when any persisted field changes. */
 darp_project_stash_task((unsigned)i);return 0;
}
void darp_store_tick(void *unused){
 (void)unused;
 darp_project_tick();
 darp_store_before_event();
 if(darp_store_audio_ready() && index_of(fw_kit)==(int)bound)
  darp_project_poll_track(bound);
}
/* Called only for a proven native temporary restore, after installing its
 * controls. Mark/cache them before the next audio context check. */
void darp_ram_restore(const arp_snapshot_state *s){
 unsigned char *kit=*(unsigned char *const volatile *)0x800019ac;int i=index_of(kit);if(i<0)return;
 darp_store_audio_select();++darp_store_context_serial;darp_store_reset_audio();
 bank_item *p=&bank[i];p->state=*s;p->epoch=epoch;bump(p);mark(kit);darp_ram_apply_controls(s,kit);
 bound=(unsigned)i;bound_generation=p->generation;started=1;++darp_store_applies;
}

void darp_store_invalidate(void){uint32_t sr=core_audio_irq_save();++darp_store_context_serial;if(!++epoch)++epoch;bound=0xffffffffu;bound_generation=0;core_audio_irq_restore(sr);}

void darp_store_invalidate_pattern(unsigned index){
 if(index>=128)return;
 uint32_t sr=core_audio_irq_save();bank[index].epoch=0;
 if(bound==index){++darp_store_context_serial;bound=0xffffffffu;bound_generation=0;}
 core_audio_irq_restore(sr);
}

unsigned darp_store_snapshot_ready(unsigned index,uint32_t token){
 return token==darp_store_context_serial && index<128 && index_of(fw_kit)==(int)index && bound==index && darp_store_audio_ready();
}
