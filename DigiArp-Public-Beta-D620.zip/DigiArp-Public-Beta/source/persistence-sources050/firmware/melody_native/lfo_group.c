/* SPDX-License-Identifier: GPL-2.0-or-later */
#include <stdint.h>
#include "digitakt-mk1/core3.h"
extern unsigned darp_lfo_editing(void);
extern void *pd_allocate(unsigned);

/* Return the native page descriptor. Its title is a native std::string,
 * rendered by the original page with its original font, frame and position. */
uint32_t *darp_lfo_group(unsigned group){
    static uint32_t *third;
    uint32_t *native=(uint32_t *)(group<20?0x4197df88u+44*group:0x4197df5cu);
    if(group!=3 || !darp_lfo_editing())return native;
    if(!third){
        uint32_t *page=pd_allocate(44);
        if(!page)return native;

        char allocator=0;
        ((void (*)(void *,const char *,void *))0x4017af20)(page,"LFO3",&allocator);
        third=page;
    }
    for(unsigned i=1;i<11;i++)third[i]=native[i];
    return third;
}


/* The native two-page LFO view remains the editing surface. Report its
 * third bank to the header formatter without changing the view's cursor. */
unsigned darp_lfo_page_number(const uint32_t *view){
    if(fw_active_track>=8 || view[32]-view[31]!=8 || view[36]>=2)return 0;
    const uint32_t *groups=(const uint32_t *)view[31];
    if(groups[0]!=2 || groups[1]!=3)return 0;
    return darp_lfo_editing()?3:view[36]+1;
}
