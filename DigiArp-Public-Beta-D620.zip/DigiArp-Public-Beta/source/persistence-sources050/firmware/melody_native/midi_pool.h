/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef DARP_MIDI_POOL_H
#define DARP_MIDI_POOL_H
#include <stdint.h>
/* Experimental native DT1 OS1.54 payload pool, not a MIDI sender.
 * Audio-context caller supplies the existing IRQ guard. Zero means refusal.
 * Reservations may be released once, or handed to the native consumer once.
 * Handed-off nodes must never subsequently be released by this adapter. */
uint32_t darp_midi_pool_reserve(void);
int darp_midi_pool_release(uint32_t node);
int darp_midi_pool_handoff(uint32_t node);
extern volatile uint32_t darp_midi_pool_faults;
#endif
