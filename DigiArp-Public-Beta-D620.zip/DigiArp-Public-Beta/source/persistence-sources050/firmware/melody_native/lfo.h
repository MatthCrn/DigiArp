/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef DARP_LFO_H
#define DARP_LFO_H
#include "controls.h"
#include "../../src/arp_lfo_targets.h"
extern volatile uint8_t darp_lfo_routes[8][2];
extern volatile int32_t darp_lfo_delta[8][DARP_LFO_TARGETS];
unsigned darp_lfo_value(unsigned track,unsigned target,unsigned base);
unsigned darp_lfo_map_delta(unsigned target,unsigned base,int32_t delta);
extern volatile int16_t darp_lfo3[8][8];
void darp_lfo3_clear(unsigned track);
void darp_lfo_reset_track(unsigned track);
#endif
