| SPDX-License-Identifier: GPL-2.0-or-later
| OS1.54 audio step preparation, exact displaced prologue.
        .text
        .globl darp_print_native_fire
darp_print_native_fire:
        lea -60(%sp),%sp
        moveq #1,%d1
        movem.l %d2-%d7/%a2-%a6,(%sp)
        jmp 0x4006f4c8
| Native queue insertion, all sequencer paths; exact OS1.54 prologue.
        .globl darp_print_native_queue
darp_print_native_queue:
        lea -20(%sp),%sp
        movem.l %d2-%d4/%a2-%a3,(%sp)
        jmp 0x400ee3ec

        .globl darp_print_native_midi_fire
darp_print_native_midi_fire:
        lea -68(%sp),%sp
        moveq #1,%d1
        movem.l %d2-%d7/%a2-%a6,(%sp)
        jmp 0x4006f850
