/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef DARP_TEMP_PATTERN_H
#define DARP_TEMP_PATTERN_H
#include <stdint.h>
extern volatile uint32_t darp_temp_pending;
void darp_temp_apply(void);
#endif
