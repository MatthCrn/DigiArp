| SPDX-License-Identifier: GPL-2.0-or-later
| Exact prologues of OS1.54 native pattern Save/Reload. C wrappers call
| these trampolines with the original five stack arguments, never recurse.
        .text
        .globl darp_native_pattern_save
darp_native_pattern_save:
        lea -44(%sp),%sp
        movem.l %d2-%d7/%a2-%a4,(%sp)
        jmp 0x40016b1e
        .globl darp_native_pattern_reload
darp_native_pattern_reload:
        link.w %a6,#-44
        movem.l %d2-%d7/%a2-%a4,(%sp)
        jmp 0x40017c1e
