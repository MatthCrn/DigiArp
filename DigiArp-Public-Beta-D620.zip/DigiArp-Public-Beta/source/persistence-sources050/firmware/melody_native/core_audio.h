/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef CORE_AUDIO_DT1_H
#define CORE_AUDIO_DT1_H
#include <stdint.h>
/* Exact stock 1.54 ABI, inspected and guarded by the manifest hash/sites.
 * All queue operations mask interrupts, traverse at most 128 buckets and
 * return failure rather than wait for a pool. No native allocator calls. */
typedef struct { uint32_t message, bucket; } core_audio_reservation;
typedef struct { uint32_t note, velocity, on, source, flags, length, track; } core_audio_note;
uint32_t core_audio_irq_save(void);
void core_audio_irq_restore(uint32_t sr);
int core_audio_reserve(core_audio_reservation *r);
void core_audio_unreserve(core_audio_reservation *r);
uint32_t core_audio_post_reserved(core_audio_reservation *r,const core_audio_note *e,uint32_t date);
uint32_t core_audio_try_post(const core_audio_note *e,uint32_t date);
#define CORE_AUDIO_CLOCK (*(volatile uint32_t *)0x80001f4c)
#define CORE_AUDIO_TEMPO (*(volatile uint32_t *)0x4020df10)
#define CORE_AUDIO_RUNNING (*(volatile uint32_t *)0x4199ec2c)
#define CORE_AUDIO_PATTERN (*(volatile uint32_t *)0x4199ec38)
#define CORE_AUDIO_MUTES (*(volatile uint16_t *)0x4199f47c)
#endif
