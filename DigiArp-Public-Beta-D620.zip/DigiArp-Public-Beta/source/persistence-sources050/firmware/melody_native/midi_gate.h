/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef DARP_MIDI_GATE_H
#define DARP_MIDI_GATE_H
#include <stdint.h>
/* Caller holds the render/task IRQ guard for each operation. */
uint32_t darp_midi_gate_reserve(void);
int darp_midi_gate_release(uint32_t);
int darp_midi_gate_handoff(uint32_t);
extern volatile uint32_t darp_midi_gate_faults;
#endif
