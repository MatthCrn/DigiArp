/* SPDX-License-Identifier: GPL-2.0-or-later */
#include "midi_pool.h"
#define FIRST 0x421c4e3cu
#define END 0x421c5a3cu
#define STRIDE 48u
#define HEAD (*(volatile uint32_t *)0x421c4e38u)
#define WORD(p,n) (*(volatile uint32_t *)((p)+4u*(n)))
static uint32_t owned[2];
volatile uint32_t darp_midi_pool_faults;
static int valid(uint32_t p){return p>=FIRST && p<END && (p-FIRST)%STRIDE==0;}
static unsigned index_of(uint32_t p){return (p-FIRST)/STRIDE;}
static int fault(void){++darp_midi_pool_faults;return 0;}
/* 64 fixed native nodes. Validate before any mutation; also reject a free
 * node which is currently reserved by this adapter. No native allocator,
 * heap, wait loop, task call, or hardware output. */
static int free_chain(void){
 uint32_t seen[2]={0,0},p=HEAD;
 for(unsigned n=0;p;n++){
  if(n>=64 || !valid(p))return fault();
  unsigned i=index_of(p),bank=i>>5;uint32_t bit=1u<<(i&31);
  if((seen[bank]|owned[bank])&bit)return fault();
  seen[bank]|=bit;p=WORD(p,11);
 }
 return 1;
}
uint32_t darp_midi_pool_reserve(void){
 if(!free_chain())return 0;
 uint32_t p=HEAD;if(!p)return 0;
 unsigned i=index_of(p);HEAD=WORD(p,11);owned[i>>5]|=1u<<(i&31);
 for(unsigned w=0;w<12;w++)WORD(p,w)=0;
 return p;
}
static int is_owned(uint32_t p){
 if(!valid(p))return 0;
 unsigned i=index_of(p);return (owned[i>>5]&(1u<<(i&31)))!=0;
}
int darp_midi_pool_release(uint32_t p){
 if(!is_owned(p))return fault();
 if(!free_chain())return 0;
 unsigned i=index_of(p);WORD(p,11)=HEAD;HEAD=p;owned[i>>5]&=~(1u<<(i&31));return 1;
}
int darp_midi_pool_handoff(uint32_t p){
 if(!is_owned(p))return fault();
 unsigned i=index_of(p);owned[i>>5]&=~(1u<<(i&31));return 1;
}
