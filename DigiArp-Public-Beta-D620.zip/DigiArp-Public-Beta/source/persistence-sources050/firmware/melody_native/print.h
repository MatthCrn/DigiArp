/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef DARP_PRINT_H
#define DARP_PRINT_H
#include "../../src/arp_print.h"
extern arp_print darp_print;
extern unsigned darp_print_track,darp_print_confirm,darp_print_ui_error;
int darp_print_arm(unsigned);
void darp_print_cancel(void);
void darp_print_clear_track(unsigned);
void darp_print_source(unsigned,uint32_t,unsigned);
void darp_print_cycle(unsigned,uint32_t,uint32_t);
void darp_print_attack(unsigned,const uint32_t *,uint32_t);
void darp_print_poll(void);
int darp_print_commit(void);
int darp_print_undo(void);
void darp_print_ui_tick(void);
void darp_print_handoff_dispatch(uint32_t *,uint32_t);
void darp_print_retire_audio(unsigned);
extern volatile uint32_t darp_print_boundary;
#endif
