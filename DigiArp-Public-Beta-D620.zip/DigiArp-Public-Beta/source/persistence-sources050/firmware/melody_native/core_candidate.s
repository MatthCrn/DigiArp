| SPDX-License-Identifier: GPL-2.0-or-later
| Candidate DT1 events; 1.54 only. Render interrupt, callbacks bounded,
| no firmware calls. Subscribers receive (message, current bucket date).
| Every no-subscriber path replays all displaced stock instructions.
        .section .run,"ax"
        .macro notify table
        lea -20(%sp),%sp
        movem.l %d0-%d1/%a0-%a1/%a3,(%sp)
        lea \table,%a3
1:      move.l (%a3)+,%d0
        beq.s 2f
        move.l 4(%a5),-(%sp)
        move.l %a2,-(%sp)
        movea.l %d0,%a0
        jsr (%a0)
        addq.l #8,%sp
        bra.s 1b
2:      movem.l (%sp),%d0-%d1/%a0-%a1/%a3
        lea 20(%sp),%sp
        .endm
        .globl core_audio_dispatch
core_audio_dispatch:
        notify ev_audio_dispatch
        move.l 8(%a2),%d2
        move.l %d2,%d0
        rts
        .globl core_audio_start
core_audio_start:
        notify ev_audio_start
        tst.l darp_skip_start
        bne.s 3f
        moveq #1,%d0
        lsl.l %d2,%d0
        or.l %d0,%d3
3:      rts
        .globl core_audio_irq_save
core_audio_irq_save:
        moveq #0,%d0
        move.w %sr,%d0
        move.w #0x2700,%sr
        rts
        .globl core_audio_irq_restore
core_audio_irq_restore:
        move.l 4(%sp),%d0
        move.w %d0,%sr
        rts

| At stock 1.54 0x40077bca, the native same-sound path restores all active
| parameter locks to the sound defaults before applying the attack's list.
| Generated attacks carry no list: keep the native state instead. Native
| source attacks still tail-call the original restore with its unchanged ABI.
| No pointer into the native lock pool is retained by DigiArp.
        .globl darp_restore_locks
darp_restore_locks:
        tst.l darp_preserve_locks
        bne.s 4f
        jmp 0x40074a40
4:      rts

        .globl darp_midi_render
| Existing native type3 branch; append reserved OFF prefix before source.
darp_midi_render:
        lea -16(%sp),%sp
        movem.l %d0-%d1/%a0-%a1,(%sp)
        move.l 4(%a5),-(%sp)
        move.l %a2,-(%sp)
        jsr darp_midi_dispatch
        addq.l #8,%sp
        tst.l %d0
        beq.s 3f
        movea.l %d0,%a0
        move.l 4(%a5),32(%a0)
        tst.l %a3
        bne.s 1f
        movea.l %a0,%a3
        bra.s 2f
1:      movea.l -112(%a6),%a1
        move.l %a0,44(%a1)
2:      movea.l %a0,%a1
        moveq #7,%d1
4:      move.l 44(%a1),%d0
        beq.s 5f
        movea.l %d0,%a1
        subq.l #1,%d1
        bne.s 4b
5:      move.l %a1,-112(%a6)
3:      movem.l (%sp),%d0-%d1/%a0-%a1
        lea 16(%sp),%sp
        movea.l 16(%a2),%a0
        moveq #-1,%d2
        rts
