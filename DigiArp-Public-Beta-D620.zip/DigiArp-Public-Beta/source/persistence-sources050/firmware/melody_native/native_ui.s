| SPDX-License-Identifier: GPL-2.0-or-later
        .text
        .globl darp_native_bank_key
darp_native_bank_key:
        lea -16(%sp),%sp
        movem.l %d2-%d3/%a2-%a3,(%sp)
        jmp 0x400362bc
