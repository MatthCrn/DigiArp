/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef DARP_STEP_LOCKS_H
#define DARP_STEP_LOCKS_H
#include <stdint.h>
void darp_locks_begin(unsigned track,const uint32_t *message,uint32_t date);
void darp_locks_finish(unsigned track,int restore);
void darp_locks_service(unsigned track,uint32_t now,int allowed);
#endif
