/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef DARP_MIDI_QUEUE_H
#define DARP_MIDI_QUEUE_H
#include <stdint.h>
typedef struct {uint32_t message,bucket;} midi_queue_reservation;
typedef struct {uint32_t track,payload;} midi_queue_note;
uint32_t core_audio_irq_save(void);
void core_audio_irq_restore(uint32_t);
int midi_queue_reserve(midi_queue_reservation *);
void midi_queue_unreserve(midi_queue_reservation *);
uint32_t midi_queue_post_reserved(midi_queue_reservation *,const midi_queue_note *,uint32_t);
uint32_t midi_queue_try_post(const midi_queue_note *,uint32_t);
#endif
