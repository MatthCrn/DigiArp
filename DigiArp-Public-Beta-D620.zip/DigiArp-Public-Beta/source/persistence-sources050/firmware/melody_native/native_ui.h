/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef DARP_NATIVE_UI_H
#define DARP_NATIVE_UI_H
int darp_native_recording(void);
int darp_native_mute(void);
#endif
