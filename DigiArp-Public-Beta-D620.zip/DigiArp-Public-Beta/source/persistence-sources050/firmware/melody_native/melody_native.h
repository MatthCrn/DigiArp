/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef DARP_MELODY_NATIVE_H
#define DARP_MELODY_NATIVE_H
#include "../../src/melody_engine.h"
#include "../../src/melody_presets.h"
#include "../../src/melody_player.h"
#ifndef DARP_ME_TRACK
#define DARP_ME_TRACK 0u
#endif
extern volatile uint32_t darp_me_enabled_tracks[16];
#define darp_me_enabled (darp_me_enabled_tracks[DARP_ME_TRACK])
extern volatile uint32_t darp_me_ready_tracks[16];
#define darp_me_ready (darp_me_ready_tracks[DARP_ME_TRACK])
extern volatile uint32_t darp_me_revision_tracks[16];
#define darp_me_revision (darp_me_revision_tracks[DARP_ME_TRACK])
extern volatile uint32_t darp_me_error_tracks[16];
#define darp_me_error (darp_me_error_tracks[DARP_ME_TRACK])
extern volatile uint32_t darp_me_cycles_tracks[16];
#define darp_me_cycles (darp_me_cycles_tracks[DARP_ME_TRACK])
extern volatile uint32_t darp_me_frozen_tracks[16];
#define darp_me_frozen (darp_me_frozen_tracks[DARP_ME_TRACK])
extern volatile uint32_t darp_me_imported_tracks[16];
#define darp_me_imported (darp_me_imported_tracks[DARP_ME_TRACK])
extern volatile uint32_t darp_me_saved_tracks[16];
#define darp_me_saved (darp_me_saved_tracks[DARP_ME_TRACK])
extern volatile uint8_t darp_me_knobs_tracks[16][8];
#define darp_me_knobs (darp_me_knobs_tracks[DARP_ME_TRACK])
extern volatile melody_phrase darp_me_stage_tracks[16];
#define darp_me_stage (darp_me_stage_tracks[DARP_ME_TRACK])
extern melody_player darp_me_player_tracks[16];
#define darp_me_player (darp_me_player_tracks[DARP_ME_TRACK])
extern volatile uint8_t darp_me_span_tracks[16][16];
#define darp_me_span (darp_me_span_tracks[DARP_ME_TRACK])
extern volatile uint8_t darp_me_velocity_tracks[16][16];
#define darp_me_velocity (darp_me_velocity_tracks[DARP_ME_TRACK])
/* Slots: RHY, MOT, OCT, internal tension, auto-evolve, D preset, G RISE, E VAR position (0..5). */
extern const uint32_t darp_me_player_stride;
void darp_me_toggle_track(unsigned track);
void darp_me_leave_track(unsigned track);
unsigned darp_me_active_track(unsigned track);
void darp_me_tick_track(unsigned track);
void darp_me_turn_track(unsigned track,unsigned knob,int delta);
void darp_me_action_track(unsigned track,unsigned knob);
unsigned darp_me_filter_track(unsigned track);
unsigned darp_me_preset_custom_track(unsigned track);
void darp_me_cycle_track(unsigned track,uint32_t date);
void darp_me_reset_track(unsigned track);
unsigned darp_me_arp_state_track(unsigned track);
int darp_me_prepare_track(unsigned track,unsigned root,melody_phrase *out);
void darp_me_tick_all(void);
/* Pure native register fitting, including partial upward OCT4. */
unsigned darp_me_pitch_ceiling_track(unsigned track);
int darp_me_fit_register(melody_config *config,unsigned bass);
#ifndef DARP_ME_IMPLEMENTATION
#define darp_me_toggle() darp_me_toggle_track(DARP_ME_TRACK)
#define darp_me_leave() darp_me_leave_track(DARP_ME_TRACK)
#define darp_me_active() darp_me_active_track(DARP_ME_TRACK)
#define darp_me_tick() darp_me_tick_track(DARP_ME_TRACK)
#define darp_me_turn(knob,delta) darp_me_turn_track(DARP_ME_TRACK ,(knob),(delta))
#define darp_me_action(knob) darp_me_action_track(DARP_ME_TRACK ,(knob))
#define darp_me_filter() darp_me_filter_track(DARP_ME_TRACK)
#define darp_me_preset_custom() darp_me_preset_custom_track(DARP_ME_TRACK)
#define darp_me_cycle(date) darp_me_cycle_track(DARP_ME_TRACK ,(date))
#define darp_me_reset() darp_me_reset_track(DARP_ME_TRACK)
#define darp_me_arp_state() darp_me_arp_state_track(DARP_ME_TRACK)
#define darp_me_prepare(root,out) darp_me_prepare_track(DARP_ME_TRACK ,(root),(out))
#endif
#endif
