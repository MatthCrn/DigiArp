/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef DARP_TRACK_SCALE_H
#define DARP_TRACK_SCALE_H
#include <stdint.h>
/* 6x finer than the old 1920-PPQN clock. period * native table value
 * gives exact dates for all seven scales (3/4/6/8/12/24/48), including
 * SPEED 1/96 at 3/4x. No division or cumulative rounding of periods. */
#define DARP_SCALE_CLOCK_UNIT 1875u
/* Keep native length/deadline arithmetic inside its signed half-range. */
static inline uint32_t darp_scale_note(uint32_t base,unsigned scale){
    uint32_t ticks=base*scale,limit=0x7fffffffu/DARP_SCALE_CLOCK_UNIT;
    return ticks>limit?limit:ticks;
}
static inline unsigned darp_scale_units(unsigned track,uint32_t pattern){
    if(track>=16 || pattern<0x40000000u || pattern>0x47fe0000u)return 0;
    const uint8_t *p=(const uint8_t *)pattern;
    unsigned index=p[0x1ec59]==1?p[911*track+0x38b]:p[0x1ec5a];
    if(index>6)return 0;
    return ((const uint32_t *)0x4018ed20)[index];
}
#endif
