#include "lfo.h"
/* SPDX-License-Identifier: GPL-2.0-or-later */
#define DARP_ME_IMPLEMENTATION
#define DARP_ME_TRACK track
#include "melody_native.h"
#include "controls.h"
#include "../../../project-persistence-lab050/melody_record.h"
#include "core_audio.h"
#include "pattern_store.h"
#include "../../src/arp_pitch_set.h"
#include "../../src/melody_presets.h"
#include "../../src/melody_mutation.h"
#include "../../src/melody_order.h"
#include "digitakt-mk1/core3.h"

/* Stable pattern key across the audio/UI handoff. Synthetic host fixtures
 * without a native kit retain their existing pattern-pointer context. */
static uint32_t melody_context_key(void){
    uint32_t key=*(volatile uint32_t *)0x800019ac;
    if(key>=0x4191f018u && key<0x4191f018u+128u*0x91eu && !((key-0x4191f018u)%0x91eu))return key;
    return *(volatile uint32_t *)0x4199ec38;
}
/* Independent storage and random streams for the eight audio tracks. */
volatile uint32_t darp_me_enabled_tracks[16];
volatile uint32_t darp_me_ready_tracks[16];
volatile uint32_t darp_me_revision_tracks[16];
volatile uint32_t darp_me_error_tracks[16];
volatile uint32_t darp_me_cycles_tracks[16];
volatile uint32_t darp_me_frozen_tracks[16];
volatile uint32_t darp_me_imported_tracks[16];
volatile uint32_t darp_me_saved_tracks[16];
#define ME_DEFAULT {76,45,2,1,1,0,0,2}
volatile uint8_t darp_me_knobs_tracks[16][8]={ME_DEFAULT,ME_DEFAULT,ME_DEFAULT,ME_DEFAULT,ME_DEFAULT,ME_DEFAULT,ME_DEFAULT,ME_DEFAULT,ME_DEFAULT,ME_DEFAULT,ME_DEFAULT,ME_DEFAULT,ME_DEFAULT,ME_DEFAULT,ME_DEFAULT,ME_DEFAULT};
volatile melody_phrase darp_me_stage_tracks[16];
melody_player darp_me_player_tracks[16];
const uint32_t darp_me_player_stride=sizeof(melody_player);
volatile uint8_t darp_me_span_tracks[16][16],darp_me_velocity_tracks[16][16];
struct melody_private {
 melody_engine engine;
 melody_phrase main_view;uint32_t main_revision,main_loop;
 uint32_t creation_seed;
 int32_t modulation[5];uint32_t modulation_cycle;unsigned modulation_valid;
 uint32_t context,project,seen_cycles,stage_root,last_boundary,have_boundary;
 unsigned initialized,saved_arp,applied_preset,preset_edited,clean_valid;
 uint8_t free_knobs[4];int turns[8];melody_phrase clean_bank[2];
 darp_track_controls saved_source;darp_rhythm_controls saved_rhythm;arp_manual_notes saved_manual;
 uint8_t saved_fixed_root,saved_fixed_octave,saved_key;
};
#define PRIVATE_INITIAL {.free_knobs={76,45,2,1}}
static struct melody_private state[16]={PRIVATE_INITIAL,PRIVATE_INITIAL,PRIVATE_INITIAL,PRIVATE_INITIAL,PRIVATE_INITIAL,PRIVATE_INITIAL,PRIVATE_INITIAL,PRIVATE_INITIAL,PRIVATE_INITIAL,PRIVATE_INITIAL,PRIVATE_INITIAL,PRIVATE_INITIAL,PRIVATE_INITIAL,PRIVATE_INITIAL,PRIVATE_INITIAL,PRIVATE_INITIAL};
#define engine (state[track].engine)
#define context (state[track].context)
#define project (state[track].project)
#define seen_cycles (state[track].seen_cycles)
#define stage_root (state[track].stage_root)
#define last_boundary (state[track].last_boundary)
#define have_boundary (state[track].have_boundary)
#define initialized (state[track].initialized)
#define saved_arp (state[track].saved_arp)
#define applied_preset (state[track].applied_preset)
#define preset_edited (state[track].preset_edited)
#define clean_valid (state[track].clean_valid)
#define free_knobs (state[track].free_knobs)
#define turns (state[track].turns)
#define clean_bank (state[track].clean_bank)
#define saved_source (state[track].saved_source)
#define saved_rhythm (state[track].saved_rhythm)
#define saved_manual (state[track].saved_manual)
#define saved_fixed_root (state[track].saved_fixed_root)
#define saved_fixed_octave (state[track].saved_fixed_octave)
#define saved_key (state[track].saved_key)

extern volatile uint32_t darp_root[DARP_TRACKS],darp_root_valid[DARP_TRACKS];
static int same(const void *a,const void *b,unsigned n){
    typedef uint32_t aligned_word __attribute__((__may_alias__));
    const uint8_t *x=a,*y=b;
    if(!(((uintptr_t)x|(uintptr_t)y)&3u)){
        while(n>=4){
            if(*(const aligned_word *)x!=*(const aligned_word *)y)return 0;
            x+=4;y+=4;n-=4;
        }
    }
    while(n--)if(*x++!=*y++)return 0;
    return 1;
}
unsigned darp_me_active_track(unsigned track){return darp_me_enabled;}
unsigned darp_me_arp_state_track(unsigned track){return darp_me_active_track(track)?saved_arp:darp_controls[track].enabled;}
void darp_me_reset_track(unsigned track){
    if(darp_me_active_track(track))darp_controls[track].enabled=saved_arp;
    darp_me_enabled=darp_me_imported=darp_me_ready=darp_me_saved=0;
    for(unsigned i=0;i<16;i++)darp_me_span[i]=darp_me_velocity[i]=0;
    darp_me_player.running=darp_me_player.sounding=0;
    initialized=0;state[track].modulation_valid=0;applied_preset=preset_edited=0;clean_valid=0;
    for(unsigned i=0;i<4;i++)free_knobs[i]=(uint8_t)melody_preset_default(0,i);
    have_boundary=0;darp_me_cycles=seen_cycles=0;
    darp_me_frozen=darp_me_error=0;
    static const uint8_t defaults[8]={76,45,2,1,1,0,0,2};
    for(unsigned i=0;i<8;i++){darp_me_knobs[i]=defaults[i];turns[i]=0;}
}
/* New phrase identity is created only at a genuine uncached entry. The
 * high bit identifies native seeded variants; old fixed seeds retain their
 * original preset interpretation. No allocator or native RNG call. */
static uint32_t creation_serial=0x243f6a88u,session_ticks,last_creation_seed[16];
static uint32_t fresh_creation_seed(unsigned track){
    creation_serial+=0x9e3779b9u;
    uint32_t x=creation_serial^CORE_AUDIO_CLOCK^(session_ticks*0x85ebca6bu)^
        darp_ram_project_id()^melody_context_key()^(977u*track);
    x^=x>>16;x*=0x7feb352du;x^=x>>15;x*=0x846ca68bu;x^=x>>16;
    x|=0x80000000u;
    if(x==last_creation_seed[track])x^=0x01234567u;
    last_creation_seed[track]=x;return x;
}
static void publish_track(unsigned track);
/* Stage in the bank not owned by the audible phrase. Repeated edits before
 * a loop boundary may overwrite only the pending bank, never the heard one. */
static void remember_clean_track(unsigned track){
    uint32_t sr=core_audio_irq_save();
    unsigned live=darp_me_player.running?darp_me_player.phrase.reserved[0]&1u:engine.phrase.reserved[0]&1u;
    unsigned slot=live^1u;clean_bank[slot]=engine.phrase;clean_bank[slot].reserved[0]=(uint8_t)slot;
    engine.phrase.reserved[0]=(uint8_t)slot;clean_valid=1;core_audio_irq_restore(sr);
}
static melody_phrase clean_phrase_track(unsigned track,int heard){
    uint32_t sr=core_audio_irq_save();
    unsigned slot=heard && darp_me_player.running?darp_me_player.phrase.reserved[0]&1u:engine.phrase.reserved[0]&1u;
    melody_phrase p=clean_valid?clean_bank[slot]:engine.phrase;
    core_audio_irq_restore(sr);return p;
}
static void copy_main_phrase(unsigned track,const melody_phrase *phrase){
    darp_controls[track].mask=0;
    for(unsigned i=0;i<16;i++){
        darp_controls[track].offsets[i]=0;darp_me_span[i]=darp_me_velocity[i]=0;
    }
    for(unsigned i=0;i<phrase->count;i++){
        melody_event v=phrase->event[i];
        darp_controls[track].mask|=(uint16_t)(1u<<v.step);
        darp_controls[track].offsets[v.step]=(int8_t)((int)v.note-(track<8?60:64));
        darp_me_span[v.step]=v.span;darp_me_velocity[v.step]=v.velocity;
    }
    state[track].main_view=*phrase;
    state[track].main_revision=darp_controls[track].revision;
}

/* Import into the existing ARP controls, using a single MIDI-60 source.
 * Offset H then addresses the actual copied note in every active slot. */
static void import_main_track(unsigned track){
    saved_source=darp_controls[track];saved_rhythm=darp_rhythm[track];saved_manual=darp_manual[track];
    saved_fixed_root=darp_fixed_root[track];saved_fixed_octave=darp_fixed_octave[track];saved_key=darp_key[track];
    darp_controls[track].settings=darp_pack((darp_options){0,9,30,1});
    darp_controls[track].length=16;darp_controls[track].mask=0;
    darp_controls[track].source=ARP_SOURCE_FIXED;darp_controls[track].chord_count=1;
    darp_fixed_root[track]=track<8?60:64;darp_fixed_octave[track]=5;darp_key[track]=0;
    darp_rhythm[track]=(darp_rhythm_controls){100,255,0,0};
    copy_main_phrase(track,&engine.phrase);
    state[track].main_loop=darp_me_player.loops;
}

static melody_phrase main_phrase_track(unsigned track){
    melody_phrase p={0};p.length=16;
    unsigned mask=darp_me_imported?darp_controls[track].mask:darp_effective_mask(track);
    for(unsigned step=0;step<darp_controls[track].length;step++)if(mask&(1u<<step)){
        int note=(int)darp_fixed_root[track]+darp_controls[track].offsets[step];
        if(note<0)note=0;
        if(note>(track<8?123:127))note=track<8?123:127;
        unsigned gap=step+1;
        while(gap<darp_controls[track].length && !(mask&(1u<<gap)))++gap;
        unsigned span=darp_me_span[step]?darp_me_span[step]:1;
        if(span>gap-step)span=gap-step;
        p.event[p.count++]=(melody_event){(uint8_t)step,(uint8_t)span,(uint8_t)note,
            darp_me_velocity[step]?darp_me_velocity[step]:100,0,0,0};
    }
    p.reserved[0]=engine.phrase.reserved[0];p.reserved[1]=engine.phrase.reserved[1];
    const melody_phrase *basis=darp_me_imported?&state[track].main_view:&engine.phrase;
    unsigned j=0;
    for(unsigned i=0;i<p.count;i++){
        while(j<basis->count && basis->event[j].step<p.event[i].step)++j;
        if(j==basis->count)break;
        const melody_event *v=&basis->event[j];
        if(p.event[i].step==v->step && p.event[i].note==v->note){p.event[i].degree=v->degree;p.event[i].cell=v->cell;p.event[i].reserved=v->reserved;}
    }
    return p;
}
static void resume_melody_track(unsigned track){
    /* Preserve direct main-page edits when returning to the generator.
     * Its original source configuration is independent of the import anchor. */
    melody_phrase p=main_phrase_track(track);
    darp_controls[track]=saved_source;darp_rhythm[track]=saved_rhythm;darp_manual[track]=saved_manual;
    darp_fixed_root[track]=saved_fixed_root;darp_fixed_octave[track]=saved_fixed_octave;darp_key[track]=saved_key;
    const melody_phrase *displayed=&state[track].main_view;
    unsigned edited=p.count!=displayed->count;
    for(unsigned i=0;i<p.count && i<displayed->count;i++){
        const melody_event *a=&p.event[i],*b=&displayed->event[i];
        if(a->step!=b->step || a->span!=b->span || a->note!=b->note || a->velocity!=b->velocity)edited=1;
    }
    /* A pure page round-trip keeps the pre-PLAY bank and degree metadata.
     * Only actual per-step edits establish a new clean phrase. */
    if(edited){if(darp_me_knobs[5])preset_edited=1;engine.phrase=p;remember_clean_track(track);}
}
void darp_me_toggle_track(unsigned track){
    uint32_t sr=core_audio_irq_save();
    if(darp_me_enabled){
        if(!initialized){core_audio_irq_restore(sr);return;}
        if(darp_me_player.running)engine.phrase=darp_me_player.phrase;
        publish_track(track);
        import_main_track(track);darp_me_imported=darp_me_saved=1;darp_me_enabled=0;
    }else if(darp_me_imported){
        resume_melody_track(track);darp_me_imported=0;darp_me_enabled=1;
        darp_controls[track].enabled=1;seen_cycles=darp_me_cycles;publish_track(track);
    }else{
        unsigned cached=darp_me_saved && initialized && context==melody_context_key() && project==darp_ram_project_id();
        saved_arp=darp_controls[track].enabled;darp_controls[track].enabled=1;
        context=melody_context_key();project=darp_ram_project_id();
        darp_me_enabled=1;darp_me_error=0;
        if(cached){
            seen_cycles=darp_me_cycles;publish_track(track);
        }else{
            state[track].creation_seed=fresh_creation_seed(track);
            darp_me_ready=0;initialized=0;darp_me_cycles=seen_cycles=0;have_boundary=0;
        }
    }
    for(unsigned i=0;i<8;i++)turns[i]=0;
    ++darp_controls[track].revision;
    if(darp_me_imported)state[track].main_revision=darp_controls[track].revision;
    core_audio_irq_restore(sr);
}
/* Leave the ME performance state without destroying its phrase/settings.
 * Selecting a classic source mode uses this; FUNC+CLEAR is the actual reset. */
void darp_me_leave_track(unsigned track){
    if(!darp_me_enabled && !darp_me_imported)return;
    uint32_t sr=core_audio_irq_save();
    if(darp_me_imported)resume_melody_track(track);
    else if(darp_me_player.running)engine.phrase=darp_me_player.phrase;
    darp_me_enabled=darp_me_imported=0;darp_me_saved=initialized;
    darp_controls[track].enabled=saved_arp;
    ++darp_controls[track].revision;core_audio_irq_restore(sr);
}
/* Stock pitch index = note + (TUNE - 64) + 3, clamped to 87.
 * A down-tuned Sound needs notes above 84 to reach the same native maximum.
 * Use base Sound TUNE here; locks/LFOs can still alter the native result. */
unsigned darp_me_pitch_ceiling_track(unsigned track){
    if(track>=8)return 127;
    if(!fw_kit)return 84;
    int tune=*(volatile int16_t *)(FW_SOUND(fw_kit,track)+FW_SOUND_PARAM(0));
    if(tune<0)tune=0;
    if(tune>32512)tune=32512;
    int ceiling=(148*256-tune)/256;
    if(ceiling<0)ceiling=0;
    if(ceiling>127)ceiling=127;
    return (unsigned)ceiling;
}
unsigned darp_me_filter_track(unsigned track){
    if(track>=8 || !fw_kit)return 127;
    int value=*(volatile int16_t *)(FW_SOUND(fw_kit,track)+20+2*26);
    return value<0?0:value>32512?127:(unsigned)value/256;
}
void darp_me_turn_track(unsigned track,unsigned knob,int delta){
    if(knob>7)return;
    if(delta>64)delta=64;
    if(delta< -64)delta=-64;
    if(knob==7){
        if(track>=8)return;
        int step=delta;if(step>=16 || step<=-16)step*=2;
        int v=(int)darp_me_filter_track(track)+step;if(v<0)v=0;if(v>127)v=127;
        if(fw_kit && (unsigned)v!=darp_me_filter_track(track)){
            *(volatile int16_t *)(FW_SOUND(fw_kit,track)+20+2*26)=(int16_t)(v*256);fw_set_param(v*256,(int32_t)track,26);
        }
        return;
    }
    /* Internal slots: 3 tension, 4 auto-evolve, 5 preset, 6 RISE, 7 variation position (0..5). */
    if(knob==3)knob=5;
    else if(knob==4)knob=7; /* physical E: six-position VAR */
    else if(knob==5){knob=4;delta=-delta;} /* physical F: FREEZE */
    unsigned old_preset=darp_me_knobs[5];
    unsigned quantum=knob==2 || knob==4 || knob==5 || knob==7?16:1;
    if(quantum==1 && (delta>=16 || delta<=-16))delta*=2;
    turns[knob]+=delta;
    while(turns[knob]>=(int)quantum || turns[knob]<=-(int)quantum){
        int step=turns[knob]>0?1:-1;turns[knob]-=(int)quantum*step;
        int v=(int)darp_me_knobs[knob]+step;
        unsigned lo=knob==2?1:0,hi=knob==2?4:knob==4?1:knob==5?MELODY_PRESETS-1:knob==7?5:127;
        if(v>=(int)lo && v<=(int)hi)darp_me_knobs[knob]=(uint8_t)v;
    }
    if(knob==5 && old_preset!=darp_me_knobs[5]){
        uint32_t sr=core_audio_irq_save();
        if(!old_preset)for(unsigned i=0;i<4;i++)free_knobs[i]=darp_me_knobs[i];
        for(unsigned i=0;i<4;i++)darp_me_knobs[i]=darp_me_knobs[5]?(uint8_t)melody_preset_default(darp_me_knobs[5],i):free_knobs[i];
        preset_edited=0;core_audio_irq_restore(sr);
    }
}
unsigned darp_me_preset_custom_track(unsigned track){
    unsigned preset=darp_me_knobs[5];if(!preset)return 0;
    if(preset_edited || darp_me_knobs[7]!=2)return 1;
    for(unsigned i=0;i<4;i++)if(darp_me_knobs[i]!=melody_preset_default(preset,i))return 1;
    return 0;
}

void darp_me_action_track(unsigned track,unsigned knob){(void)track;(void)knob;}
void darp_me_cycle_track(unsigned track,uint32_t date){
    if(!have_boundary || date!=last_boundary){last_boundary=date;have_boundary=1;++darp_me_cycles;}
}
static void publish_track(unsigned track){
    uint32_t sr=core_audio_irq_save();
    darp_me_stage=engine.phrase;
    unsigned source=darp_me_imported?saved_source.source:darp_controls[track].source;
    unsigned fixed=darp_me_imported?saved_fixed_root:darp_fixed_root[track];
    stage_root=source==ARP_SOURCE_FIXED?fixed:darp_root_valid[track]?darp_root[track]:60;
    ++darp_me_revision;darp_me_ready=1;core_audio_irq_restore(sr);
}
int darp_me_prepare_track(unsigned track,unsigned root,melody_phrase *out){
    if(darp_me_imported){
        if(darp_rhythm[track].pulses==255){*out=darp_me_stage;return melody_phrase_valid(out)?0:-1;}
        melody_phrase phrase=darp_me_stage;
        melody_phrase filtered={0};filtered.length=16;
        filtered.reserved[0]=phrase.reserved[0];filtered.reserved[1]=phrase.reserved[1];
        unsigned mask=darp_effective_mask(track),cursor=0;
        for(unsigned step=0;step<darp_controls[track].length;step++)if(mask&(1u<<step)){
            while(cursor<phrase.count && phrase.event[cursor].step<step)++cursor;
            melody_event event={0};event.step=(uint8_t)step;event.span=1;event.velocity=100;
            if(cursor<phrase.count && phrase.event[cursor].step==step)event=phrase.event[cursor];
            else{
                int note=(int)darp_fixed_root[track]+darp_controls[track].offsets[step];
                if(note<0)note=0;
                if(note>(track<8?123:127))note=track<8?123:127;
                event.note=(uint8_t)note;
            }
            unsigned next=step+1;
            while(next<darp_controls[track].length && !(mask&(1u<<next)))++next;
            if(event.span>next-step)event.span=(uint8_t)(next-step);
            filtered.event[filtered.count++]=event;
        }
        *out=filtered;return melody_phrase_valid(out)?0:-1;
    }
    if(!darp_me_active_track(track) || !darp_me_ready || root>127)return -1;
    melody_phrase phrase=darp_me_stage;
    if(!melody_phrase_valid(&phrase))return -1;
    int shift=(int)root-(int)stage_root;
    for(unsigned i=0;i<phrase.count;i++){
        int note=phrase.event[i].note+shift;
        if(note<0 || note>(track<8?123:127))return -1;
        phrase.event[i].note=(uint8_t)note;
    }
    *out=phrase;return 0;
}
/* Fit positions 1..3 exactly as before. Position 4 uses position 3's
 * lower edge and adds a fourth octave upward, within the TUNE-aware limit.
 * A partial upper octave is allowed; the entire pool never shifts lower. */
int darp_me_fit_register(melody_config *config,unsigned bass){
    if(!config || config->root>127 || config->range<1 || config->range>4)return -1;
    melody_config c=*config;unsigned requested=c.range,ceiling=c.ceiling?c.ceiling:84;
    unsigned floor=ceiling>=84?36:ceiling>48?ceiling-48:0;
    if(requested==4)c.range=3;
    c.ceiling=0;
    unsigned register_root=c.root;if(bass && register_root>=12)register_root-=12;
    uint8_t pool[MELODY_POOL];int count;
    for(;;){
        c.root=(uint8_t)register_root;count=melody_pool(&c,pool);
        while((count<0 || pool[count-1]>ceiling) && c.root>=12){c.root-=12;count=melody_pool(&c,pool);}
        while(c.root<floor && c.root<=115){c.root+=12;count=melody_pool(&c,pool);}
        if(count>0 && pool[0]>=floor && pool[count-1]<=ceiling)break;
        if(c.range<=1)return -1;
        --c.range;
    }
    if(requested==4 && c.range==3)c.range=4;
    c.ceiling=(uint8_t)ceiling;
    if(melody_pool(&c,pool)<1)return -1;
    *config=c;return 0;
}
/* Keep the source's semitone/octave movement independent of the upper
 * edge of its theoretical pool. Derive the established OCT/BASS register
 * offset at the source octave's C reference, then cap only unavailable upper notes.
 * Fold the base itself only when it cannot fit the actual native band. */
static int source_register_root(melody_config *config,int root){
    melody_config c=*config;unsigned ceiling=c.ceiling;
    unsigned floor=ceiling>=84?36:ceiling>48?ceiling-48:0;
    while(root<(int)floor)root+=12;
    while(root>(int)ceiling)root-=12;
    uint8_t pool[MELODY_POOL];
    for(;;){
        c.root=(uint8_t)root;
        if(melody_pool(&c,pool)>0){*config=c;return 0;}
        if(root<(int)floor+12)return -1;
        root-=12;
    }
}
static int fit_source_register(melody_config *config,unsigned bass){
    melody_config c=*config,reference=c;unsigned source=c.root,origin=source/12u*12u;
    reference.root=(uint8_t)origin;
    if(c.source==MELODY_ARP)for(unsigned i=0;i<c.arp_count && i<16;i++)
        reference.arp[i]=(uint8_t)((c.arp[i]+132u-source)%12u);
    if(darp_me_fit_register(&reference,bass))return -1;
    c.range=reference.range;c.ceiling=reference.ceiling;
    if(source_register_root(&c,(int)source+(int)reference.root-(int)origin))return -1;
    *config=c;return 0;
}
static int contour_track(unsigned track,unsigned motion,unsigned range){
    melody_phrase before=engine.phrase;
    if(melody_edit(&engine,before.count,motion,range))return -1;
    for(unsigned i=0;i<before.count;i++){
        engine.phrase.event[i].step=before.event[i].step;
        engine.phrase.event[i].span=before.event[i].span;
    }
    return 0;
}
void darp_me_tick_track(unsigned track){
    if(!darp_me_active_track(track) && !darp_me_imported)return;
    if(context!=melody_context_key() || project!=darp_ram_project_id()){
        darp_me_reset_track(track);return;
    }
    if(darp_me_imported){
        if(state[track].main_revision!=darp_controls[track].revision){
            melody_phrase edited=main_phrase_track(track);
            const melody_phrase *displayed=&state[track].main_view;
            unsigned changed=edited.count!=displayed->count;
            for(unsigned i=0;i<edited.count && i<displayed->count;i++){
                const melody_event *a=&edited.event[i],*b=&displayed->event[i];
                if(a->step!=b->step || a->span!=b->span ||
                   a->note!=b->note || a->velocity!=b->velocity)changed=1;
            }
            if(changed){
                engine.phrase=edited;remember_clean_track(track);
                if(darp_me_knobs[5])preset_edited=1;
                publish_track(track);
                state[track].main_view=edited;
            }
            state[track].main_revision=darp_controls[track].revision;
        }
        uint32_t sr=core_audio_irq_save();
        unsigned running=darp_me_player.running;
        uint32_t loop=darp_me_player.loops;
        if(running && loop!=state[track].main_loop){
            melody_phrase heard=darp_me_player.phrase;
            copy_main_phrase(track,&heard);
            state[track].main_loop=loop;
        }
        core_audio_irq_restore(sr);
    }
    const volatile darp_track_controls *source=darp_me_imported?&saved_source:
        &darp_controls[track];
    /* Sample structural LFOs once per musical loop. Manual edits remain
     * immediate; FREEZE holds modulation of the phrase, never the base knobs. */
    if(!state[track].modulation_valid || ((!initialized || darp_me_knobs[4]) &&
       (!darp_me_player.running || state[track].modulation_cycle!=darp_me_cycles))){
        for(unsigned i=0;i<5;i++)state[track].modulation[i]=track<8?darp_lfo_delta[track][DARP_LFO_ME_RHY+i]:0;
        state[track].modulation_cycle=darp_me_cycles;state[track].modulation_valid=1;
    }
    unsigned preset=darp_lfo_map_delta(DARP_LFO_ME_PRESET,darp_me_knobs[5],state[track].modulation[4]);
    unsigned macro[4];for(unsigned i=0;i<4;i++)macro[i]=preset==darp_me_knobs[5]?darp_me_knobs[i]:preset?melody_preset_default(preset,i):free_knobs[i];
    melody_config c={0};c.seed=initialized?engine.config.seed:state[track].creation_seed;c.complexity=127;
    c.rhythm=(uint8_t)darp_lfo_map_delta(DARP_LFO_ME_RHY,macro[0],state[track].modulation[0]);
    c.motion=(uint8_t)darp_lfo_map_delta(DARP_LFO_ME_MOT,macro[1],state[track].modulation[1]);
    c.range=(uint8_t)darp_lfo_map_delta(DARP_LFO_ME_OCT,macro[2],state[track].modulation[2]);c.tension=(uint8_t)macro[3];
    static const uint8_t variation[6]={12,28,48,72,100,127};
    unsigned var=darp_lfo_map_delta(DARP_LFO_ME_VAR,darp_me_knobs[7],state[track].modulation[3]);
    c.density=64;c.repeat=1;c.variation=variation[var];
    c.root=source->source==ARP_SOURCE_FIXED?(darp_me_imported?saved_fixed_root:darp_fixed_root[track]):
        darp_root_valid[track]?(uint8_t)darp_root[track]:60;
    c.scale=source->preset;
    if(source->source==ARP_SOURCE_ABSOLUTE){
        const volatile arp_manual_notes *manual=darp_me_imported?&saved_manual:
            &darp_manual[track];
        c.source=MELODY_ARP;c.arp_count=manual->count;
        for(unsigned i=0;i<c.arp_count && i<16;i++)c.arp[i]=manual->notes[i];
        if(!c.arp_count){c.arp_count=1;c.arp[0]=c.root;}
    }
    unsigned source_root=c.root;
    c.ceiling=(uint8_t)darp_me_pitch_ceiling_track(track);
    if(track<8 && c.ceiling>123)c.ceiling=123; /* MIDI60 +/- native main-editor offsets */
    unsigned requested_range=c.range;
    /* Existing/cached records keep their exact register until a source,
     * OCT, preset or Sound headroom edit requests a new fit. No migration
     * or silent regeneration just because a project was loaded. */
    if(initialized && applied_preset==preset && source_root==stage_root &&
       requested_range==engine.config.range && c.ceiling==engine.config.ceiling &&
       c.source==engine.config.source && c.scale==engine.config.scale &&
       (c.source!=MELODY_ARP || (c.arp_count==engine.config.arp_count && same(c.arp,engine.config.arp,16)))){
        c.root=engine.config.root;c.range=engine.config.range;
    }else{
        if(fit_source_register(&c,preset==MELODY_PRESET_BASS)){darp_me_error=2;return;}
        if(initialized && applied_preset==preset && source_root!=stage_root &&
           requested_range==engine.config.range && c.ceiling==engine.config.ceiling &&
           c.source==MELODY_SCALE && engine.config.source==MELODY_SCALE && c.scale==engine.config.scale){
            unsigned anchor=engine.config.root;
            /* Repair a legacy whole-octave jump on the first actual source
             * edit, without migrating or changing an untouched saved phrase. */
            melody_config previous=c,legacy;previous.root=(uint8_t)stage_root;
            previous.range=(uint8_t)requested_range;legacy=previous;
            if(!fit_source_register(&previous,preset==MELODY_PRESET_BASS) &&
               !darp_me_fit_register(&legacy,preset==MELODY_PRESET_BASS) &&
               anchor==legacy.root)anchor=previous.root;
            if(source_register_root(&c,(int)anchor+(int)source_root-(int)stage_root)){darp_me_error=2;return;}
        }
    }
    if(preset==darp_me_knobs[5] && !state[track].modulation[2])darp_me_knobs[2]=c.range;
    if(darp_me_error==2)darp_me_error=0;
    unsigned changed=darp_me_ready && stage_root!=source_root;
    if(!initialized || applied_preset!=preset){
        if(melody_init(&engine,&c) || melody_rhythm(&engine,c.rhythm,0) || melody_tension(&engine,c.tension,0)){darp_me_error=2;return;}
        engine.undo_valid=0;initialized=1;changed=1;applied_preset=preset;preset_edited=0;seen_cycles=darp_me_cycles;
    }else{
        melody_config comparison=c;comparison.root=engine.config.root;
        comparison.motion=engine.config.motion;comparison.range=engine.config.range;
        if((c.range==4 || engine.config.range==4) && c.root!=engine.config.root)comparison.root=c.root;
        comparison.density=engine.config.density;comparison.rhythm=engine.config.rhythm;comparison.tension=engine.config.tension;comparison.variation=engine.config.variation;
        if(c.source==MELODY_ARP && c.root!=engine.config.root){
            int delta=(int)c.root-engine.config.root;
            for(unsigned i=0;i<c.arp_count;i++)comparison.arp[i]=(uint8_t)((int)c.arp[i]-delta);
        }
        if(!same(&comparison,&engine.config,sizeof c)){
            if(melody_init(&engine,&c) || melody_rhythm(&engine,c.rhythm,0) || melody_tension(&engine,c.tension,0)){darp_me_error=2;return;}changed=1;
        }else{
            melody_phrase before;melody_config before_config;
            unsigned edited=0;
            /* Fit the new range before root transposition at a high register. */
            if(c.range!=engine.config.range || c.motion!=engine.config.motion){
                before=engine.phrase;before_config=engine.config;
                if(contour_track(track,c.motion,c.range) || melody_tension(&engine,c.tension,0)){darp_me_error=2;return;}changed=1;edited=1;
            }
            if(c.root!=engine.config.root){if(melody_root(&engine,c.root)){
                /* A previous wider register must not prevent a safe root edit. */
                engine.undo_valid=0;if(melody_root(&engine,c.root)){
                    /* The root is still playable, but a formerly high note
                     * may exceed the new partial pool. Revoice in that pool
                     * instead of moving the whole phrase down an octave. */
                    if(melody_init(&engine,&c) || melody_rhythm(&engine,c.rhythm,0) || melody_tension(&engine,c.tension,0)){darp_me_error=2;return;}
                }
            }changed=1;}
            if(edited){engine.previous=before;engine.previous_config=before_config;engine.undo_valid=1;}
            if(c.rhythm!=engine.config.rhythm){if(melody_rhythm(&engine,c.rhythm,0) || melody_tension(&engine,c.tension,0)){darp_me_error=2;return;}changed=1;}
        }
    }
    engine.config.variation=c.variation;
    if(c.tension!=engine.config.tension){if(melody_tension(&engine,c.tension,0)){darp_me_error=2;return;}changed=1;}
    if(changed && preset){
        if(melody_preset_generate_variant(&engine,preset,0,(c.seed&0x80000000u)?c.seed:0)){darp_me_error=2;return;}
        preset_edited=0;
    }
    if(changed){
        remember_clean_track(track);
    }
    unsigned frozen=!darp_me_knobs[4];
    if(frozen && !darp_me_frozen){
        uint32_t sr=core_audio_irq_save();
        if(darp_me_player.running)engine.phrase=darp_me_player.phrase;
        core_audio_irq_restore(sr);changed=1;
    }
    darp_me_frozen=frozen;
    uint32_t cycles=darp_me_cycles;
    if(cycles-seen_cycles>4){seen_cycles=cycles;darp_me_error=3;return;}
    while(seen_cycles!=cycles){
        ++seen_cycles;
        if(!frozen){
            engine.phrase=clean_phrase_track(track,0);
            if(melody_variation(&engine,preset,c.variation)){darp_me_error=2;return;}
            remember_clean_track(track);
                preset_edited=0;changed=1;
        }
    }
    if(changed)publish_track(track);
}


void darp_me_tick_all(void){++session_ticks;for(unsigned track=0;track<16;track++)darp_me_tick_track(track);}

/* Persistence lab API. Capture/apply only; no on-device save/load hooks yet. */
static arp_snapshot_track record_controls(unsigned track,const unsigned char *kit,const darp_track_controls *c,const darp_rhythm_controls *rh,const arp_manual_notes *manual,unsigned root,unsigned octave,unsigned key){
    arp_snapshot_track p={0};p.enabled=(uint8_t)c->enabled;p.settings=c->settings;p.mask=c->mask;p.length=c->length;p.source=c->source;p.preset=c->preset;p.count=c->chord_count;
    for(unsigned i=0;i<16;i++){p.offsets[i]=c->offsets[i];p.manual[i]=manual->notes[i];}
    p.manual_count=manual->count;p.manual_octave=manual->octave;p.fixed_root=(uint8_t)root;p.fixed_octave=(uint8_t)octave;p.key=(uint8_t)key;
    p.probability=rh->probability;p.pulses=rh->pulses;p.rotation=rh->rotation;
    for(unsigned l=0;l<2;l++){int v=kit && track<8?*(const volatile int16_t *)(kit+0x20+0xa2*track+20+2*(4+8*l))/256:0;p.lfo[l]=(uint8_t)(v>=DARP_LFO_DEST_FIRST && v<=DARP_LFO_DEST_LAST?v:0);}
    return p;
}
static darp_track_controls unpack_controls(const arp_snapshot_track *p){
    darp_track_controls c={0};c.enabled=p->enabled;c.settings=p->settings;c.mask=p->mask;c.length=p->length;c.source=p->source;c.preset=p->preset;c.chord_count=p->count;
    for(unsigned i=0;i<16;i++)c.offsets[i]=p->offsets[i];
    return c;
}
/* Rebuild imported editor data from captured inputs, after releasing the
 * task snapshot guard. A sorted merge preserves degree/cell metadata in O(16). */
static melody_phrase snapshot_main_phrase(const melody_phrase *old,const darp_track_controls *ctl,unsigned root,unsigned mask,const uint8_t span[16],const uint8_t velocity[16]){
    melody_phrase p={0};p.length=16;unsigned match=0;
    for(unsigned step=0;step<ctl->length;step++)if(mask&(1u<<step)){
        int note=(int)root+ctl->offsets[step];if(note<0)note=0;if(note>127)note=127;
        unsigned gap=step+1;while(gap<ctl->length && !(mask&(1u<<gap)))++gap;
        unsigned duration=span[step]?span[step]:1;if(duration>gap-step)duration=gap-step;
        melody_event *v=&p.event[p.count++];*v=(melody_event){(uint8_t)step,(uint8_t)duration,(uint8_t)note,velocity[step]?velocity[step]:100,0,0,0};
        while(match<old->count && old->event[match].step<step)++match;
        if(match<old->count && old->event[match].step==step && old->event[match].note==note){v->degree=old->event[match].degree;v->cell=old->event[match].cell;v->reserved=old->event[match].reserved;}
    }
    p.reserved[0]=old->reserved[0];p.reserved[1]=old->reserved[1];return p;
}
int darp_me_snapshot_kit_track(unsigned track,const unsigned char *kit,me_record *out){
    if(track>=16 || !out)return -1;
    me_record r={0};darp_track_controls ctl,original;darp_rhythm_controls rhythm,original_rhythm;
    arp_manual_notes manual,original_manual;uint8_t roots[6],span[16],velocity[16];unsigned mask=0;
    /* Copy only changing source fields while guarded. Formatting, imported
     * phrase reconstruction, comparison and CRC never extend this guard. */
    uint32_t irq=core_audio_irq_save();
    if(track<8)for(unsigned i=0;i<8;i++)r.lfo3[i]=darp_lfo3[track][i];
    ctl=darp_controls[track];rhythm=darp_rhythm[track];manual=darp_manual[track];
    roots[0]=darp_fixed_root[track];roots[1]=darp_fixed_octave[track];roots[2]=darp_key[track];
    r.flags=(uint8_t)((initialized?1:0)|(darp_me_enabled?2:0)|(darp_me_imported?4:0)|(darp_me_saved?8:0)|(preset_edited?16:0));
    r.preset=(uint8_t)applied_preset;r.classic_enabled=(uint8_t)saved_arp;
    for(unsigned i=0;i<8;i++)r.knobs[i]=darp_me_knobs[i];
    for(unsigned i=0;i<4;i++)r.recall_knobs[i]=free_knobs[i];
    if(initialized){r.config=engine.config;r.phrase=engine.phrase;r.new_state=engine.new_state;r.mutation_state=engine.mutation_state;r.source_root=(uint8_t)stage_root;}
    else {r.phrase.length=16;r.source_root=roots[0];}
    unsigned classic=(unsigned)darp_me_arp_state_track(track);
    if(r.flags&ME_RECORD_IMPORTED){
        original=saved_source;original_rhythm=saved_rhythm;original_manual=saved_manual;
        roots[3]=saved_fixed_root;roots[4]=saved_fixed_octave;roots[5]=saved_key;mask=darp_effective_mask(track);
        for(unsigned i=0;i<16;i++){span[i]=darp_me_span[i];velocity[i]=darp_me_velocity[i];}
    }
    core_audio_irq_restore(irq);
    r.current=record_controls(track,kit,&ctl,&rhythm,&manual,roots[0],roots[1],roots[2]);r.current.enabled=(uint8_t)classic;
    if(r.flags&ME_RECORD_IMPORTED){
        r.original=record_controls(track,kit,&original,&original_rhythm,&original_manual,roots[3],roots[4],roots[5]);
        r.phrase=snapshot_main_phrase(&r.phrase,&ctl,roots[0],mask,span,velocity);
    }else r.original=r.current;
    *out=r;return 0;
}
int darp_me_snapshot_track(unsigned track,me_record *out){return darp_me_snapshot_kit_track(track,(const unsigned char *)fw_kit,out);}
int darp_me_record_capture_track(unsigned track,uint8_t out[ME_RECORD_BYTES]){
    me_record r;if(darp_me_snapshot_track(track,&r))return -1;return me_record_encode(&r,out);
}
int darp_me_apply_snapshot_track(unsigned track,const me_record *record){
    if(track>=16 || !record)return -1;
    me_record r=*record;
    /* The owner must quiesce old audio lanes before replacing a project. */
    uint32_t irq=core_audio_irq_save();
    if(darp_me_player.running || darp_me_player.sounding){core_audio_irq_restore(irq);return -2;}
    darp_me_reset_track(track);state[track]=(struct melody_private){0};
    darp_controls[track]=unpack_controls(&r.current);++darp_controls[track].revision;
    darp_rhythm[track]=(darp_rhythm_controls){r.current.probability,r.current.pulses,r.current.rotation,0};
    darp_manual[track].count=r.current.manual_count;darp_manual[track].octave=r.current.manual_octave;
    for(unsigned i=0;i<16;i++)darp_manual[track].notes[i]=r.current.manual[i];
    darp_fixed_root[track]=r.current.fixed_root;darp_fixed_octave[track]=r.current.fixed_octave;darp_key[track]=r.current.key;
    for(unsigned i=0;i<8;i++)darp_me_knobs[i]=r.knobs[i];
    for(unsigned i=0;i<4;i++)free_knobs[i]=r.recall_knobs[i];
    if(track<8)for(unsigned i=0;i<8;i++)darp_lfo3[track][i]=r.lfo3[i];
    initialized=!!(r.flags&1);darp_me_enabled=!!(r.flags&2);darp_me_imported=!!(r.flags&4);darp_me_saved=!!(r.flags&8);preset_edited=!!(r.flags&16);
    saved_arp=r.classic_enabled;applied_preset=r.preset;darp_me_frozen=!r.knobs[4];
    state[track].creation_seed=r.config.seed;
    context=melody_context_key();project=darp_ram_project_id();stage_root=r.source_root;
    if(initialized){engine=(melody_engine){0};engine.config=r.config;engine.phrase=r.phrase;engine.new_state=r.new_state;engine.mutation_state=r.mutation_state;engine.frozen=(uint8_t)darp_me_frozen;
        context=melody_context_key();project=darp_ram_project_id();stage_root=r.source_root;darp_root[track]=r.source_root;darp_root_valid[track]=1;
        remember_clean_track(track);darp_me_stage=engine.phrase;++darp_me_revision;darp_me_ready=1;
    }
    /* A frozen saved phrase includes its effective configuration, but never
     * writes LFO offsets into the user's knobs. Reconstruct the held offsets
     * so the first UI tick cannot regenerate it at the new LFO start phase. */
    if(initialized && darp_me_frozen){
        unsigned preset=r.preset,macro[3];
        for(unsigned j=0;j<3;j++)macro[j]=preset==r.knobs[5]?r.knobs[j]:preset?melody_preset_default(preset,j):r.recall_knobs[j];
        static const unsigned spans[5]={127,127,3,5,5};
        unsigned var=0;static const uint8_t values[6]={12,28,48,72,100,127};
        while(var<5 && values[var]<r.config.variation)++var;
        int difference[5]={(int)r.config.rhythm-(int)macro[0],(int)r.config.motion-(int)macro[1],
            (int)r.config.range-(int)macro[2],(int)var-(int)r.knobs[7],(int)preset-(int)r.knobs[5]};
        for(unsigned j=0;j<5;j++){
            int32_t n=difference[j]*32512;
            state[track].modulation[j]=n>=0?(n+(int)spans[j]/2)/(int)spans[j]:-((-n+(int)spans[j]/2)/(int)spans[j]);
        }
        state[track].modulation_valid=1;state[track].modulation_cycle=darp_me_cycles;
    }
    if(darp_me_enabled)darp_controls[track].enabled=1;
    if(darp_me_imported){
        saved_source=unpack_controls(&r.original);saved_rhythm=(darp_rhythm_controls){r.original.probability,r.original.pulses,r.original.rotation,0};
        saved_manual.count=r.original.manual_count;saved_manual.octave=r.original.manual_octave;for(unsigned i=0;i<16;i++)saved_manual.notes[i]=r.original.manual[i];
        saved_fixed_root=r.original.fixed_root;saved_fixed_octave=r.original.fixed_octave;saved_key=r.original.key;
        state[track].main_view=r.phrase;state[track].main_revision=darp_controls[track].revision;state[track].main_loop=darp_me_player.loops;
        for(unsigned i=0;i<16;i++)darp_me_span[i]=darp_me_velocity[i]=0;
        for(unsigned i=0;i<r.phrase.count;i++){melody_event v=r.phrase.event[i];darp_me_span[v.step]=v.span;darp_me_velocity[v.step]=v.velocity;}
    }
    core_audio_irq_restore(irq);return 0;
}

int darp_me_record_restore_track(unsigned track,const uint8_t *bytes,unsigned n){
    me_record r;if(me_record_decode(bytes,n,&r))return -1;return darp_me_apply_snapshot_track(track,&r);
}
