/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef DIGIARP_MOTIF_CONTROLS_H
#define DIGIARP_MOTIF_CONTROLS_H
#include <stdint.h>
#include "../../src/arp_euclid.h"
#include "../../src/arp_sequence.h"
#include "../../src/arp_keyboard.h"
/* UI publishes with audio interrupts masked; audio snapshots at source trig.
 * These are live controls; RAM context and project_manager own pointer-free snapshots. */
void darp_clear_track(unsigned track);
void darp_me_wait_source_trigger(unsigned track);
#define DARP_DEFAULT_SETTINGS 0x011e0900u
#define DARP_TRACKS 16u
typedef struct {
    uint32_t enabled,settings,revision;
    uint16_t mask;uint8_t length;int8_t offsets[16];
    uint8_t source,preset,chord_count;int8_t chord_offsets[16];
} __attribute__((aligned(4))) darp_track_controls;
_Static_assert(sizeof(darp_track_controls)==52,"controls ABI");
extern volatile darp_track_controls darp_controls[DARP_TRACKS];
typedef struct {uint8_t probability,pulses,rotation,reserved;} darp_rhythm_controls;
/* pulses=255: manual pattern, otherwise automatic 0..length. */
extern volatile darp_rhythm_controls darp_rhythm[DARP_TRACKS];
static inline uint16_t darp_effective_mask(unsigned t){
 return darp_rhythm[t].pulses==255?darp_controls[t].mask:
 arp_euclid_mask(darp_controls[t].length,darp_rhythm[t].pulses,darp_rhythm[t].rotation);
}
extern volatile uint32_t darp_ui_track;
extern volatile uint8_t darp_key[DARP_TRACKS]; /* 0 OFF, 1..12 C..B */
extern volatile arp_manual_notes darp_manual[DARP_TRACKS];
extern volatile uint8_t darp_fixed_root[DARP_TRACKS],darp_fixed_octave[DARP_TRACKS];
_Static_assert(sizeof(arp_manual_notes)==20,"manual notes ABI");
typedef struct {uint32_t mode,rate,note,range;} darp_options;
/* All 18 speed slots observed through native panel/glyph comparison. */
#define DARP_UNITS_PER_TICK 11250u /* 1920 PPQN, exact native 1/32-sixteenth LEN steps */
static const uint16_t darp_periods[18]={7680,3840,2560,1920,1536,1280,960,768,640,480,384,320,240,192,160,120,96,80};
static inline uint32_t darp_duration(unsigned index){
    if(index<=62)return 30u+15u*index;
    if(index<=78)return 960u+60u*(index-62u);
    if(index<=94)return 1920u+120u*(index-78u);
    if(index<=110)return 3840u+240u*(index-94u);
    if(index<=123)return 7680u+1920u*(index-110u);
    const uint16_t last[4]={38400,46080,53760,61440};
    return index<128?last[index-124]:0;
}
static inline darp_options darp_decode(uint32_t v){
    darp_options o={v&255u,(v>>8)&255u,(v>>16)&255u,v>>24};
    if(o.mode>5 || o.rate>17 || o.note>127 || o.range<1 || o.range>8)
        o=(darp_options){0,9,30,1};
    return o;
}
static inline uint32_t darp_pack(darp_options o){return o.mode|(o.rate<<8)|(o.note<<16)|(o.range<<24);}
#endif
