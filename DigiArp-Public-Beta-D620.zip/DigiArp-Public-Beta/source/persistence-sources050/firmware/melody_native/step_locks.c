/* SPDX-License-Identifier: GPL-2.0-or-later */
#include "step_locks.h"
#include "core_audio.h"
#include "controls.h"
/* Confirmed stock 1.54 apply/restore ABI: 0x40074b0a / 0x40074a40.
 * Every list is consumed during dispatch, never retained. Native fields only;
 * no pattern, sound, allocator or UI writes. */
struct step_locks {
    uint32_t active,until,pattern,kit,machine;
    uint32_t changed[2],masks[2];
    int16_t before[53];
};
static struct step_locks locks[8];
volatile uint32_t darp_lock_chains[DARP_TRACKS],darp_lock_restores[DARP_TRACKS];
static int reached(uint32_t now,uint32_t date){return now-date<0x80000000u;}
static unsigned machine(unsigned t,uint32_t kit){return *(const uint8_t *)(kit+0x20+0xa2*t+0x7e);}
static int context(unsigned t,const struct step_locks *s){
    uint32_t kit=*(volatile uint32_t *)0x800019ac;
    return kit && kit==s->kit && CORE_AUDIO_PATTERN==s->pattern && machine(t,kit)==s->machine;
}
static volatile int16_t *words(unsigned t){return (volatile int16_t *)(0x800014f0+18+106*t);}
static volatile uint32_t *masks(unsigned t){return (volatile uint32_t *)(0x4399eb14+8*t);}
/* Stock scheduler 0x4006fc3e..82 chooses the scale, and 0x4006ed38..46
 * converts each of its ticks to 900000 musical units. Table 0x4018ed20:
 * 3,4,6,8,12,24,48. Native pattern bytes may be unaligned. */
static uint32_t step_units(unsigned t,uint32_t pattern){
    if(pattern<0x40000000u || pattern>0x47fe0000u)return 0;
    const uint8_t *p=(const uint8_t *)pattern;
    unsigned index=p[0x1ec59]==1?p[911*t+0x38b]:p[0x1ec5a];
    if(index>6)return 0;
    return ((const uint32_t *)0x4018ed20)[index]*900000u;
}
void darp_locks_finish(unsigned t,int restore){
    if(t>=8)return;
    struct step_locks *s=&locks[t];
    if(!s->active)return;
    if(restore && context(t,s)){
        volatile int16_t *w=words(t);
        volatile uint32_t *m=masks(t);
        volatile int32_t *targets=(volatile int32_t *)(0x80002b2c+4*(9+53*t));
        for(unsigned i=0;i<53;i++)if(s->changed[i>>5]&(1u<<(i&31))){
            uint32_t bit=1u<<(i&31);w[i]=s->before[i];
            targets[i]=(int32_t)s->before[i]*65536;
            m[i>>5]=(m[i>>5]&~bit)|(s->masks[i>>5]&bit);
        }
        ++darp_lock_restores[t];
    }
    s->active=0;s->changed[0]=s->changed[1]=0;
}
void darp_locks_begin(unsigned t,const uint32_t *message,uint32_t date){
    if(t>=8)return;
    struct step_locks *s=&locks[t];
    uint32_t kit=*(volatile uint32_t *)0x800019ac,pattern=CORE_AUDIO_PATTERN;
    uint32_t span=step_units(t,pattern),p=message[17];
    if(!kit || !span || p<0x40000000u || p>0x47fffe44u || (p&1))return;
    const uint32_t *list=(const uint32_t *)p;
    unsigned n=list[2];
    if(!n || n>53)return;
    /* Same-date next lock wins before expiry. A gap starts a new snapshot.
     * Restore an old chain before capturing the next independent lock. */
    if(s->active && (!context(t,s) || (date!=s->until && reached(date,s->until))))
        darp_locks_finish(t,1);
    if(!s->active){
        volatile int16_t *w=words(t);volatile uint32_t *m=masks(t);
        s->pattern=pattern;s->kit=kit;s->machine=machine(t,kit);
        s->masks[0]=m[0];s->masks[1]=m[1];
        for(unsigned i=0;i<53;i++)s->before[i]=w[i];
        s->changed[0]=s->changed[1]=0;s->active=1;++darp_lock_chains[t];
    }
    for(unsigned k=0;k<n;k++){
        unsigned slot=*(const uint16_t *)(p+20+8*k);
        if(slot<53)s->changed[slot>>5]|=1u<<(slot&31);
    }
    s->until=date+span;
}
void darp_locks_service(unsigned t,uint32_t now,int allowed){
    if(t>=8 || !locks[t].active)return;
    if(!allowed || !context(t,&locks[t]) || reached(now,locks[t].until))darp_locks_finish(t,1);
}
