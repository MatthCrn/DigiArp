/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef DIGIARP_FONT_H
#define DIGIARP_FONT_H
/* Original 5x7 UI glyphs. No extracted Elektron font/bitmap content. Rows
 * are top to bottom, MSB at left. Explicit pixels avoid formatter state. */
static const uint8_t darp_letters[26][7]={
 {14,17,17,31,17,17,17},{30,17,17,30,17,17,30},{14,17,16,16,16,17,14},
 {30,17,17,17,17,17,30},{31,16,16,30,16,16,31},{31,16,16,30,16,16,16},
 {14,17,16,23,17,17,15},{17,17,17,31,17,17,17},{31,4,4,4,4,4,31},
 {7,2,2,2,18,18,12},{17,18,20,24,20,18,17},{16,16,16,16,16,16,31},
 {17,27,21,21,17,17,17},{17,25,21,19,17,17,17},{14,17,17,17,17,17,14},
 {30,17,17,30,16,16,16},{14,17,17,17,21,18,13},{30,17,17,30,20,18,17},
 {15,16,16,14,1,1,30},{31,4,4,4,4,4,4},{17,17,17,17,17,17,14},
 {17,17,17,17,17,10,4},{17,17,17,21,21,21,10},{17,17,10,4,10,17,17},
 {17,17,10,4,4,4,4},{31,1,2,4,8,16,31}
};
static const uint8_t darp_digits[10][7]={
 {14,17,19,21,25,17,14},{4,12,4,4,4,4,14},{14,17,1,2,4,8,31},
 {30,1,1,14,1,1,30},{2,6,10,18,31,2,2},{31,16,16,30,1,1,30},
 {14,16,16,30,17,17,14},{31,1,2,4,8,8,8},{14,17,17,14,17,17,14},
 {14,17,17,15,1,1,14}
};
static void darp_glyph_row(void *bmp,int x,int y,unsigned bits,unsigned width){
    unsigned i=0;
    while(i<width){
        if(!(bits&(1u<<(width-1-i)))){++i;continue;}
        unsigned first=i;
        while(i<width && (bits&(1u<<(width-1-i))))++i;
        fw_fillrect(bmp,x+(int)first,y,x+(int)i-1,y,1);
    }
}
static void text(void *bmp,int x,int y,const char *s){
    for(;*s && x<128;++s,x+=6){
        unsigned c=(unsigned char)*s;
        for(unsigned r=0;r<7;r++){
            unsigned bits=0;
            if(c>='A' && c<='Z')bits=darp_letters[c-'A'][r];
            else if(c>='0' && c<='9')bits=darp_digits[c-'0'][r];
            else if(c=='/')bits=(r==0?1:r==1?2:r==2?2:r==3?4:r==4?8:r==5?8:16);
            else if(c=='-' && r==3)bits=14;
            else if(c=='.' && r==6)bits=4;
            darp_glyph_row(bmp,x,y+6-(int)r,bits,5);
        }
    }
}
static void smalltext(void *bmp,int x,int y,const char *s){
    static const uint8_t rows[8][5]={{4,4,4,4,7},{7,4,6,4,7},{5,7,7,7,5},
        {7,5,5,5,7},{7,4,6,4,4},{3,4,2,1,6},{1,2,2,2,1},{4,2,2,2,4}};
    for(;*s && x<128;++s,x+=4){
        unsigned k=*s=='L'?0:*s=='E'?1:*s=='N'?2:*s=='O'?3:*s=='F'?4:*s=='S'?5:*s=='('?6:7;
        for(unsigned r=0;r<5;r++)darp_glyph_row(bmp,x,y+4-(int)r,rows[k][r],3);
    }
}
#endif
