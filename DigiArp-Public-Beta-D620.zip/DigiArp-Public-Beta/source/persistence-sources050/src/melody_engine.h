/* SPDX-License-Identifier: MIT */
#ifndef DIGIARP_MELODY_ENGINE_H
#define DIGIARP_MELODY_ENGINE_H
#include <stdint.h>
#define MELODY_STEPS 16u
#define MELODY_POOL 60u
#define MELODY_OCTAVES 5u
enum { MELODY_SCALE, MELODY_ARP };
enum { MELODY_TENSION_OFF,MELODY_TENSION_SOFT,MELODY_TENSION_MID,MELODY_TENSION_HARD };
/* Independent of the firmware and its existing 52-byte ARP controls ABI. */
typedef struct {
    uint32_t seed;
    uint8_t complexity,motion,rhythm,density,variation,repeat,tension,range;
    uint8_t root,scale,source,arp_count,arp[16];
    uint8_t ceiling; /* 0: complete MIDI pool; otherwise omit pitches above this limit. */
} melody_config;
typedef struct {
    uint8_t step,span,note,velocity;
    int16_t degree;
    uint8_t cell,reserved;
} melody_event;
typedef struct {
    melody_event event[MELODY_STEPS];
    uint8_t count,length;
    uint8_t reserved[2];
} melody_phrase;
typedef struct {
    melody_config config,previous_config;
    melody_phrase phrase,previous;
    uint32_t new_state,mutation_state;
    uint8_t frozen,undo_valid,repetitions,reserved;
} melody_engine;
_Static_assert(sizeof(melody_event)==8,"bounded event layout");
int melody_phrase_valid(const melody_phrase *p);
/* All invalid-input paths leave output/state untouched. seed=0 is valid.
 * SCALE uses the existing 23 pitch sets. ARP uses unique pitch classes
 * relative to root, ascending, expanded over range (1 to 5 octaves).
 * Without ceiling, the complete requested register must fit MIDI 0..127.
 * With ceiling, the last octave may be partial; omitted notes are never clipped. */
int melody_pool(const melody_config *c,uint8_t out[MELODY_POOL]);
int melody_init(melody_engine *e,const melody_config *c);
int melody_new(melody_engine *e);
int melody_evolve(melody_engine *e); /* returns modified event count */
int melody_repeat(melody_engine *e); /* complete phrase; evolve on REP */
void melody_freeze(melody_engine *e,int frozen);
int melody_undo(melody_engine *e); /* one level, consumed on success */
int melody_transpose(const melody_phrase *src,int semitones,melody_phrase *dst);
int melody_root(melody_engine *e,unsigned root);
/* Direct edits: count edits preserve surviving notes; range remaps the same
 * contour; motion revoices without changing attack positions. Atomic/undoable. */
int melody_edit(melody_engine *e,unsigned notes,unsigned motion,unsigned range);
int melody_vary(melody_engine *e); /* explicit pitch-only variation */
/* 0 = silence; 127 = 16 attacks; intermediate densities select different
 * placements and 1/2/4-step durations, without overlaps. */
int melody_rhythm(melody_engine *e,unsigned amount,int vary);
/* Four musical profiles (0..3): structural tones, rare weak-beat colour,
 * more passing/extension tones, accented tension. Each tension resolves to
 * the next stable event; timing/velocity and the allowed pitch pool stay intact. */
int melody_tension(melody_engine *e,unsigned profile,int vary);
/* Decorate an existing contour rather than generating the stable walk. */
int melody_tension_contour(melody_engine *e,unsigned profile,int vary);
int melody_anchor_pool(const melody_config *c,uint8_t degrees[MELODY_POOL]);
enum { MELODY_EDIT_NOTE,MELODY_EDIT_SPAN,MELODY_EDIT_ACTIVE,MELODY_EDIT_VELOCITY };
int melody_anchor_degrees(const melody_config *,const uint8_t *,int,uint8_t *);
/* Absolute step edit. Invalid arguments preserve the phrase. Activation can
 * shorten the preceding note to make room for a new attack. */
int melody_step_edit(melody_phrase *p,unsigned step,unsigned parameter,int delta);
#endif
