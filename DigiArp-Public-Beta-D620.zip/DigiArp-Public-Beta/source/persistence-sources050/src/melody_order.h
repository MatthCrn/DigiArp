/* SPDX-License-Identifier: MIT */
#ifndef MELODY_ORDER_H
#define MELODY_ORDER_H
#include "melody_engine.h"
enum {MELODY_FWD,MELODY_REV,MELODY_PING,MELODY_UP,MELODY_DOWN,MELODY_RAND,MELODY_SHUF,MELODY_WALK,MELODY_DICE,MELODY_ORDERS};
typedef struct {uint32_t rng;unsigned initialized,mode,count,cursor,backward;} melody_order_state;
const char *melody_order_name(unsigned mode);
/* Build a path through the original step addresses, including rests.
 * The phrase is read-only; no event is moved or rewritten. */
int melody_head_path(const melody_phrase *phrase,unsigned mode,unsigned length,melody_order_state *state,uint32_t seed,uint8_t path[16]);
#endif
