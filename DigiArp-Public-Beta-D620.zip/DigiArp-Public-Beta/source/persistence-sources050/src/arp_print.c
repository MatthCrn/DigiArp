/* SPDX-License-Identifier: MIT */
#include "arp_print.h"
static void fail(arp_print *p,unsigned error){p->error=error;p->phase=ARP_PRINT_ERROR;}
int arp_print_arm(arp_print *p,uint32_t context,unsigned steps,uint32_t step_units){
 if(!p || !context || !steps || steps>64 || !step_units || step_units>0xfffffffeu/steps)return -1;
 *p=(arp_print){0};p->phase=ARP_PRINT_ARMED;p->context=context;p->steps=steps;p->step_units=step_units;return 0;
}
void arp_print_begin(arp_print *p,uint32_t date){if(p && p->phase==ARP_PRINT_ARMED){p->start=date;p->phase=ARP_PRINT_RECORDING;}}
void arp_print_poll(arp_print *p,uint32_t date,int running,uint32_t context){
 if(!p || (p->phase!=ARP_PRINT_ARMED && p->phase!=ARP_PRINT_RECORDING))return;
 if(context!=p->context){fail(p,ARP_PRINT_CONTEXT);return;}
 if(p->phase==ARP_PRINT_RECORDING){
  uint32_t elapsed=date-p->start;
  if(elapsed<0x80000000u)p->clock_started=1;
  if(p->clock_started && elapsed>=p->steps*p->step_units){
   if(p->count)p->phase=ARP_PRINT_READY;else fail(p,ARP_PRINT_EMPTY);return;
  }
 }
 if(!running)fail(p,ARP_PRINT_STOPPED);
}
void arp_print_attack(arp_print *p,uint32_t date,unsigned note,unsigned velocity,uint32_t duration){
 if(!p || p->phase!=ARP_PRINT_RECORDING)return;
 uint32_t elapsed=date-p->start;
 /* Before a future start and after the exclusive end are both outside.
  * Completion follows the real clock, never a lookahead attack. */
 if(elapsed>=p->steps*p->step_units)return;
 if(note>127 || !velocity || velocity>127){fail(p,ARP_PRINT_NOTE);return;}
 if(elapsed%p->step_units){fail(p,ARP_PRINT_GRID);return;}
 unsigned i=elapsed/p->step_units;
 /* Native reset and already queued arp attack can share an exact date.
  * The final monophonic attack wins; do not count another capture step. */
 if(!p->step[i].active)++p->count;
 p->step[i]=(arp_print_step){duration,1,(uint8_t)note,(uint8_t)velocity,0};
}
/* A reset whose first slot is a rest can cancel an already queued ON at
 * that very date. Keep the realized silence, including the previous release. */
void arp_print_silence(arp_print *p,uint32_t date){
 if(!p || p->phase!=ARP_PRINT_RECORDING)return;
 uint32_t elapsed=date-p->start;if(elapsed>=p->steps*p->step_units)return;
 if(elapsed%p->step_units){fail(p,ARP_PRINT_GRID);return;}
 unsigned i=elapsed/p->step_units;
 if(p->step[i].active){p->step[i]=(arp_print_step){0};--p->count;}
 for(unsigned j=i;j>0;){
  --j;if(!p->step[j].active)continue;
  uint32_t duration=(i-j)*p->step_units;
  if(!p->step[j].duration || p->step[j].duration>duration)p->step[j].duration=duration;
  break;
 }
}
static unsigned word(const uint8_t *p){return (unsigned)p[0]*256u+p[1];}
int arp_print_build(const arp_print *p,const uint8_t source[ARP_PRINT_TRACK_BYTES],uint8_t output[ARP_PRINT_TRACK_BYTES],const uint32_t table[129]){
 if(!p || !source || !output || !table || p->phase!=ARP_PRINT_READY || !p->count || !p->steps || p->steps>64)return -1;
 uint8_t next[ARP_PRINT_TRACK_BYTES];for(unsigned i=0;i<sizeof next;i++)next[i]=source[i];
 for(unsigned i=0;i<p->steps;i++){
  const arp_print_step *n=&p->step[i];unsigned w=word(source+2*i);
  if(n->active){
   int length=-1;
   if(!n->duration)length=127;
   else for(unsigned j=0;j<127;j++)if(table[j+1]==n->duration){length=(int)j;break;}
   if(length<0)return -2; /* refuse duration loss, leave output untouched */
   next[2*i]=0x08;next[2*i+1]=0x81; /* SYN explicitly ON, no retrigs */
   next[0x80+i]=n->velocity;next[0xc0+i]=(uint8_t)length;next[0x100+i]=0;
   next[0x200+i]=255;next[0x280+i]=n->note;
  }else if((w&1u) && ((w&0x800u)?(w&0x80u):(word(source+0x382)&0x80u))){
   w&=~1u;next[2*i]=(uint8_t)(w>>8);next[2*i+1]=(uint8_t)w;
  } /* Existing yellow trigless locks remain in place. */
 }
 next[0x38c]=100; /* realized probabilities must not be applied a second time */
 for(unsigned i=0;i<sizeof next;i++)output[i]=next[i];
 return 0;
}
