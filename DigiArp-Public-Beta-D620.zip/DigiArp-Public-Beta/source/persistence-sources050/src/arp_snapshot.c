#include "arp_lfo_targets.h"
/* SPDX-License-Identifier: MIT */
#include "arp_snapshot.h"
static void w16(uint8_t *b,unsigned x){b[0]=(uint8_t)(x>>8);b[1]=(uint8_t)x;}
static unsigned r16(const uint8_t *b){return 256u*b[0]+b[1];}
static void w32(uint8_t *b,uint32_t x){w16(b,x>>16);w16(b+2,x&65535u);}
static uint32_t r32(const uint8_t *b){return (uint32_t)r16(b)*65536u+r16(b+2);}
static uint32_t crc(const uint8_t *p,unsigned n){uint32_t c=~0u;for(unsigned i=0;i<n;i++){c^=p[i];for(unsigned j=0;j<8;j++)c=(c>>1)^(0xedb88320u&(0u-(c&1u)));}return ~c;}
int arp_snapshot_valid(const arp_snapshot_state *s){
 if(!s)return 0;
 for(unsigned t=0;t<8;t++){
  const arp_snapshot_track *p=&s->track[t];uint32_t v=p->settings;
  if(p->enabled>1 || (v&255)>5 || ((v>>8)&255)>17 || ((v>>16)&255)>127 || (v>>24)<1 || (v>>24)>8 || !p->length || p->length>16 || p->source<3 || p->source>5 || p->preset>=23 || !p->count || p->count>16 || p->manual_count>16 || p->manual_octave>10 || p->fixed_octave>10 || p->fixed_root>127 || p->key>12 || p->probability>100 || (p->pulses!=255 && p->pulses>p->length) || p->rotation>=p->length)return 0;
  for(unsigned l=0;l<2;l++)if(p->lfo[l] && (p->lfo[l]<53 || p->lfo[l]>DARP_LFO_DEST_LAST))return 0;
  for(unsigned i=0;i<16;i++){
   if(p->offsets[i]<-64 || p->offsets[i]>63)return 0;
   if(i<p->manual_count){if(p->manual[i]>127)return 0;for(unsigned j=0;j<i;j++)if(p->manual[i]==p->manual[j])return 0;}
  }
 }
 return 1;
}
void arp_snapshot_default(arp_snapshot_state *s){
 *s=(arp_snapshot_state){0};for(unsigned t=0;t<8;t++){
  arp_snapshot_track *p=&s->track[t];p->settings=0x011e0900u;p->mask=0xffff;p->length=16;p->source=3;p->preset=2;p->count=1;p->manual_octave=5;p->fixed_root=60;p->fixed_octave=5;p->probability=100;p->pulses=255;
 }
}
int arp_snapshot_encode(const arp_snapshot_state *s,uint8_t b[ARP_SNAPSHOT_BYTES]){
 if(!b || !arp_snapshot_valid(s))return -1;
 for(unsigned i=0;i<ARP_SNAPSHOT_BYTES;i++)b[i]=0;
 b[0]='D';b[1]='A';b[2]='R';b[3]='2';w16(b+4,2);w16(b+6,ARP_SNAPSHOT_BYTES);b[12]=8;uint8_t *d=b+16;
 for(unsigned t=0;t<8;t++){
  const arp_snapshot_track *p=&s->track[t];*d++=p->enabled;w32(d,p->settings);d+=4;w16(d,p->mask);d+=2;*d++=p->length;
  for(unsigned i=0;i<16;i++)*d++=(uint8_t)p->offsets[i];
  *d++=p->source;*d++=p->preset;*d++=p->count;*d++=p->manual_count;
  for(unsigned i=0;i<16;i++)*d++=i<p->manual_count?p->manual[i]:0;
  *d++=p->manual_octave;*d++=p->fixed_root;*d++=p->fixed_octave;*d++=p->key;*d++=p->probability;*d++=p->pulses;*d++=p->rotation;*d++=p->lfo[0];*d++=p->lfo[1];
 }
 w32(b+8,crc(b+12,ARP_SNAPSHOT_BYTES-12));return 0;
}
int arp_snapshot_decode(const uint8_t *b,unsigned n,arp_snapshot_state *s){
 if(!b || !s || n!=ARP_SNAPSHOT_BYTES || b[0]!='D' || b[1]!='A' || b[2]!='R' || b[3]!='2' || r16(b+4)!=2 || r16(b+6)!=n || b[12]!=8 || b[13] || b[14] || b[15] || r32(b+8)!=crc(b+12,n-12))return -1;
 arp_snapshot_state next={0};const uint8_t *d=b+16;
 for(unsigned t=0;t<8;t++){
  arp_snapshot_track *p=&next.track[t];p->enabled=*d++;p->settings=r32(d);d+=4;p->mask=(uint16_t)r16(d);d+=2;p->length=*d++;
  for(unsigned i=0;i<16;i++){unsigned v=*d++;p->offsets[i]=(int8_t)(v<128?(int)v:(int)v-256);}
  p->source=*d++;p->preset=*d++;p->count=*d++;p->manual_count=*d++;
  for(unsigned i=0;i<16;i++)p->manual[i]=*d++;
  p->manual_octave=*d++;p->fixed_root=*d++;p->fixed_octave=*d++;p->key=*d++;p->probability=*d++;p->pulses=*d++;p->rotation=*d++;p->lfo[0]=*d++;p->lfo[1]=*d++;
  if(p->manual_count<=16)for(unsigned i=p->manual_count;i<16;i++)if(p->manual[i])return -1;
 }
 if(!arp_snapshot_valid(&next))return -1;
 *s=next;return 0;
}
void arp_snapshot_ref(const uint8_t id[16],uint8_t ref[24]){ref[0]='D';ref[1]='A';ref[2]='R';ref[3]='2';for(unsigned i=0;i<16;i++)ref[4+i]=id[i];w32(ref+20,crc(ref,20));}
int arp_snapshot_ref_valid(const uint8_t ref[24]){return ref && ref[0]=='D' && ref[1]=='A' && ref[2]=='R' && ref[3]=='2' && r32(ref+20)==crc(ref,20);}
static uint32_t rr(uint32_t x,unsigned n){return (x>>n)|(x<<(32-n));}
/* SHA-256, truncated to 128 bits for immutable object names. */
void arp_snapshot_id(const uint8_t *p,unsigned n,uint8_t out[16]){
 static const uint32_t k[64]={0x428a2f98u,0x71374491u,0xb5c0fbcfu,0xe9b5dba5u,0x3956c25bu,0x59f111f1u,0x923f82a4u,0xab1c5ed5u,0xd807aa98u,0x12835b01u,0x243185beu,0x550c7dc3u,0x72be5d74u,0x80deb1feu,0x9bdc06a7u,0xc19bf174u,0xe49b69c1u,0xefbe4786u,0xfc19dc6u,0x240ca1ccu,0x2de92c6fu,0x4a7484aau,0x5cb0a9dcu,0x76f988dau,0x983e5152u,0xa831c66du,0xb00327c8u,0xbf597fc7u,0xc6e00bf3u,0xd5a79147u,0x6ca6351u,0x14292967u,0x27b70a85u,0x2e1b2138u,0x4d2c6dfcu,0x53380d13u,0x650a7354u,0x766a0abbu,0x81c2c92eu,0x92722c85u,0xa2bfe8a1u,0xa81a664bu,0xc24b8b70u,0xc76c51a3u,0xd192e819u,0xd6990624u,0xf40e3585u,0x106aa070u,0x19a4c116u,0x1e376c08u,0x2748774cu,0x34b0bcb5u,0x391c0cb3u,0x4ed8aa4au,0x5b9cca4fu,0x682e6ff3u,0x748f82eeu,0x78a5636fu,0x84c87814u,0x8cc70208u,0x90befffau,0xa4506cebu,0xbef9a3f7u,0xc67178f2u};
 uint32_t h[8]={0x6a09e667u,0xbb67ae85u,0x3c6ef372u,0xa54ff53au,0x510e527fu,0x9b05688cu,0x1f83d9abu,0x5be0cd19u};
 unsigned blocks=(n+9u+63u)/64u;
 for(unsigned block=0;block<blocks;block++){
  uint8_t bytes[64];uint32_t w[64];
  for(unsigned i=0;i<64;i++){unsigned pos=block*64+i;bytes[i]=pos<n?p[pos]:pos==n?128:0;}
  if(block+1==blocks){uint32_t bits=n*8u;w32(bytes+60,bits);}
  for(unsigned i=0;i<16;i++)w[i]=r32(bytes+4*i);
  for(unsigned i=16;i<64;i++){uint32_t a=w[i-15],b=w[i-2];w[i]=w[i-16]+(rr(a,7)^rr(a,18)^(a>>3))+w[i-7]+(rr(b,17)^rr(b,19)^(b>>10));}
  uint32_t a=h[0],b=h[1],c=h[2],d=h[3],e=h[4],f=h[5],g=h[6],z=h[7];
  for(unsigned i=0;i<64;i++){
   uint32_t t=z+(rr(e,6)^rr(e,11)^rr(e,25))+((e&f)^(~e&g))+k[i]+w[i];
   uint32_t u=(rr(a,2)^rr(a,13)^rr(a,22))+((a&b)^(a&c)^(b&c));z=g;g=f;f=e;e=d+t;d=c;c=b;b=a;a=t+u;
  }
  h[0]+=a;h[1]+=b;h[2]+=c;h[3]+=d;h[4]+=e;h[5]+=f;h[6]+=g;h[7]+=z;
 }
 for(unsigned i=0;i<4;i++)w32(out+4*i,h[i]);
}
