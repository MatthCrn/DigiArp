/* SPDX-License-Identifier: MIT */
#ifndef DIGIARP_SEQUENCE_H
#define DIGIARP_SEQUENCE_H
#include <stdint.h>
#define ARP_SEQUENCE_NOTES 16u
#define ARP_SEQUENCE_STEPS 16u
typedef enum { ARP_SEQ_TRUE, ARP_SEQ_UP, ARP_SEQ_DOWN, ARP_SEQ_CYCL, ARP_SEQ_RANDOM, ARP_SEQ_SHUFFLE } arp_sequence_mode;
typedef struct {
    arp_sequence_mode mode;
    uint8_t range,length;
    int8_t offset[ARP_SEQUENCE_STEPS];
    uint16_t active;
    uint8_t probability,probability_on; /* optional 0..100%; zero init preserves legacy */
    uint32_t probability_seed; /* nonzero seed supplied by persistent track stream */
    /* Imported Melody timing/velocity. Zero keeps the ordinary ARP setting. */
    uint8_t span[ARP_SEQUENCE_STEPS],velocity[ARP_SEQUENCE_STEPS];
    uint8_t key,scale; /* key 0=chromatic offsets, 1..12=C..B; scale=preset */
} arp_sequence_config;
typedef enum { ARP_SEQ_NOTE, ARP_SEQ_REST, ARP_SEQ_OUT_OF_RANGE } arp_sequence_kind;
typedef struct {
    arp_sequence_kind kind;
    int16_t pitch; /* signed intermediate; consume as a note only for NOTE */
    uint8_t position,octave;
} arp_sequence_result;
typedef struct {
    arp_sequence_config config;
    uint32_t random_state,probability_state;
    uint8_t bag[128],bag_position,bag_count;
    uint8_t notes[ARP_SEQUENCE_NOTES],count,index,octave,position,descending;
} arp_sequence;
/* Pure bounded note selection, no timing/voices/UI/heap. Config/source are
 * copied on success, invalid input leaves the state unchanged. Unique source
 * notes only; TRUE preserves their input order, other modes sort ascending.
 * Range advances after a complete traversal; CYCL after the returning low
 * note (not the initial low note). Derived from stock 1.44 measurements.
 * Muted positions advance only the motif, not the source traversal.
 * Mixed per-position offsets and complete out-of-range policy need more
 * reference cases; don't infer a full firmware integration from this API. */
/* RANDOM samples with replacement; SHUFFLE permutes all count*range entries.
 * Fixed seed derived from source notes; restarting the same pool reproduces it.
 * Muted slots do not consume RNG. Modulo reduction has slight statistical bias. */
int arp_sequence_init(arp_sequence *s,const arp_sequence_config *cfg,
                      const uint8_t *notes,unsigned count);
int arp_sequence_next(arp_sequence *s,arp_sequence_result *result);
#endif
