/* SPDX-License-Identifier: MIT */
#ifndef DIGIARP_CHORD_H
#define DIGIARP_CHORD_H
#include <stdint.h>
#define ARP_CHORD_MAX 16u
#define ARP_CHORD_PRESETS 9u
enum { ARP_SOURCE_SINGLE, ARP_SOURCE_PRESET, ARP_SOURCE_CUSTOM };
/* Ordered, unique semitone offsets relative to the native source trig.
 * Invalid input returns -1 without writing output; no heap or firmware data. */
int arp_chord_offsets(unsigned source,unsigned preset,const int8_t *custom,
                      unsigned count,int8_t out[ARP_CHORD_MAX]);
/* Drop source pitches outside 0..127, preserving entry order. Returns
 * 0 for a wholly out-of-range chord, -1 for invalid input. No wrapping. */
int arp_chord_resolve(unsigned root,const int8_t *offsets,unsigned count,
                     uint8_t out[ARP_CHORD_MAX]);
#endif
