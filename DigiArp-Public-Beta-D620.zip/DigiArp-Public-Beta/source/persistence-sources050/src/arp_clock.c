/* SPDX-License-Identifier: MIT */
#include "arp_clock.h"
int arp_clock_init(arp_clock *c, uint32_t bpm_milli) {
    if (!c || bpm_milli < 20000 || bpm_milli > 400000) return -1;
    c->bpm_milli = bpm_milli; c->remainder = 0; return 0;
}
uint32_t arp_clock_next_us(arp_clock *c) {
    uint32_t divisor = c->bpm_milli * ARP_PPQN;
    uint64_t numerator = UINT64_C(60000000000) + c->remainder;
    c->remainder = (uint32_t)(numerator % divisor);
    return (uint32_t)(numerator / divisor);
}
uint32_t arp_rate_ticks(unsigned d, unsigned variant) {
    if ((d != 4 && d != 8 && d != 16 && d != 32 && d != 64) || variant > 2) return 0;
    uint32_t t = ARP_PPQN * 4 / d;
    return variant == 1 ? t * 3 / 2 : variant == 2 ? t * 2 / 3 : t;
}
