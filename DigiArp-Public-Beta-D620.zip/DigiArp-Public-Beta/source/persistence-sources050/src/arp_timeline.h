/* SPDX-License-Identifier: MIT */
#ifndef DIGIARP_TIMELINE_H
#define DIGIARP_TIMELINE_H
#include <stdint.h>
/* DT1 1.54 experiment: 5,400,000 units per sixteenth, 960 PPQN.
 * Musical time, independent of BPM. No hardware access or queue ownership.
 * Reanchor between batches; dates must stay within half of the u32 range.
 * Caller must cancel outstanding events on transport discontinuities. */
#define ARP_TIMELINE_UNITS_PER_TICK 22500u
typedef struct { uint64_t tick; uint32_t date; } arp_timeline;
int arp_timeline_init(arp_timeline *t, uint64_t tick, uint32_t date);
/* Reject past/too distant ticks, leaving output unchanged. Wrap is intentional. */
int arp_timeline_date(const arp_timeline *t, uint64_t tick, uint32_t *date);
#endif
