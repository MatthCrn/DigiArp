/* SPDX-License-Identifier: MIT */
#include "arp_store.h"
#include "arp_pitch_set.h"
static void u16(uint8_t *p,unsigned n){p[0]=(uint8_t)(n>>8);p[1]=(uint8_t)n;}
static void u32(uint8_t *p,uint32_t n){u16(p,n>>16);u16(p+2,n&65535u);}
static unsigned r16(const uint8_t *p){return (unsigned)p[0]*256u+p[1];}
static uint32_t r32(const uint8_t *p){return (uint32_t)r16(p)*65536u+r16(p+2);}
static uint32_t crc(const uint8_t *p){
    uint32_t c=0xffffffffu;
    for(unsigned i=0;i<ARP_STORE_BYTES;i++){
        if(i>=32 && i<36)continue;
        c^=p[i];
        for(unsigned j=0;j<8;j++)c=(c>>1)^(0xedb88320u&(0u-(c&1u)));
    }
    return ~c;
}
int arp_store_valid(const arp_store_state *s){
    if(!s)return 0;
    for(unsigned t=0;t<8;t++){
        const arp_store_track *p=&s->track[t];uint32_t v=p->settings;
        if(p->enabled>1 || (v&255)>5 || ((v>>8)&255)>17 || ((v>>16)&255)>127 ||
           (v>>24)<1 || (v>>24)>8 || p->length<1 || p->length>16 ||
           p->source<3 || p->source>5 || p->preset>=ARP_PITCH_SETS ||
           p->count<1 || p->count>16 || p->manual_count>16 ||
           p->manual_octave>10 || p->fixed_octave>10 || p->fixed_root>127)return 0;
        for(unsigned i=0;i<16;i++){
            if(p->offsets[i]<-64 || p->offsets[i]>63 ||
               p->legacy_offsets[i]<-64 || p->legacy_offsets[i]>63)return 0;
            if(i<p->manual_count){
                if(p->manual[i]>127)return 0;
                for(unsigned j=0;j<i;j++)if(p->manual[i]==p->manual[j])return 0;
            }
        }
    }
    return 1;
}
int arp_store_encode(const arp_store_state *s,const arp_store_key *k,uint32_t seq,uint8_t out[ARP_STORE_BYTES]){
    if(!out || !k || k->pattern>127 || !seq || !arp_store_valid(s))return ARP_STORE_INVALID;
    for(unsigned i=0;i<ARP_STORE_BYTES;i++)out[i]=0;
    out[0]='D';out[1]='A';out[2]='R';out[3]='1';u16(out+4,1);u16(out+6,ARP_STORE_BYTES);
    u32(out+8,seq);for(unsigned i=0;i<16;i++)out[12+i]=k->project[i];
    out[28]=k->pattern;out[29]=8;
    uint8_t *d=out+36;
    for(unsigned t=0;t<8;t++){
        const arp_store_track *p=&s->track[t];
        *d++=p->enabled;u32(d,p->settings);d+=4;u16(d,p->mask);d+=2;*d++=p->length;
        for(unsigned i=0;i<16;i++)*d++=(uint8_t)p->offsets[i];
        *d++=p->source;*d++=p->preset;*d++=p->count;
        for(unsigned i=0;i<16;i++)*d++=(uint8_t)p->legacy_offsets[i];
        *d++=p->manual_count;
        for(unsigned i=0;i<16;i++)*d++=i<p->manual_count?p->manual[i]:0;
        *d++=p->manual_octave;*d++=p->fixed_root;*d++=p->fixed_octave;
    }
    u32(out+32,crc(out));return ARP_STORE_OK;
}
int arp_store_decode(const uint8_t *b,unsigned n,const arp_store_key *k,arp_store_state *s,uint32_t *seq){
    if(!b || !k || !s || !seq || k->pattern>127)return ARP_STORE_INVALID;
    if(n!=ARP_STORE_BYTES || b[0]!='D' || b[1]!='A' || b[2]!='R' || b[3]!='1' ||
       r16(b+4)!=1 || r16(b+6)!=ARP_STORE_BYTES || b[28]!=k->pattern ||
       b[29]!=8 || b[30] || b[31] || !r32(b+8) || crc(b)!=r32(b+32))return ARP_STORE_CORRUPT;
    for(unsigned i=0;i<16;i++)if(b[12+i]!=k->project[i])return ARP_STORE_CORRUPT;
    arp_store_state next={0};const uint8_t *d=b+36;
    for(unsigned t=0;t<8;t++){
        arp_store_track *p=&next.track[t];
        p->enabled=*d++;p->settings=r32(d);d+=4;p->mask=(uint16_t)r16(d);d+=2;p->length=*d++;
        for(unsigned i=0;i<16;i++){unsigned v=*d++;p->offsets[i]=(int8_t)(v<128?(int)v:(int)v-256);}
        p->source=*d++;p->preset=*d++;p->count=*d++;
        for(unsigned i=0;i<16;i++){unsigned v=*d++;p->legacy_offsets[i]=(int8_t)(v<128?(int)v:(int)v-256);}
        p->manual_count=*d++;
        for(unsigned i=0;i<16;i++)p->manual[i]=*d++;
        p->manual_octave=*d++;p->fixed_root=*d++;p->fixed_octave=*d++;
        if(p->manual_count<=16)for(unsigned i=p->manual_count;i<16;i++)if(p->manual[i])return ARP_STORE_CORRUPT;
    }
    if(!arp_store_valid(&next))return ARP_STORE_CORRUPT;
    *s=next;*seq=r32(b+8);return ARP_STORE_OK;
}
static int equal(const uint8_t *a,const uint8_t *b,unsigned n){
    for(unsigned i=0;i<n;i++)if(a[i]!=b[i])return 0;
    return 1;
}
static int scan(const arp_store_io *io,const arp_store_key *k,arp_store_workspace *w,int *which,uint32_t *sequence){
    int valid[2]={0},size[2];uint32_t seq[2]={0};arp_store_state scratch;
    if(!io || !io->read || !k || k->pattern>127 || !w)return ARP_STORE_INVALID;
    for(unsigned i=0;i<2;i++){
        size[i]=io->read(io->context,k,i,w->slot[i],ARP_STORE_BYTES);
        if(size[i]<0)return ARP_STORE_IO;
        valid[i]=arp_store_decode(w->slot[i],(unsigned)size[i],k,&scratch,&seq[i])==0;
    }
    if(!valid[0] && !valid[1])return !size[0]&&!size[1]?ARP_STORE_MISSING:ARP_STORE_CORRUPT;
    unsigned pick=valid[0]?0:1;
    if(valid[0] && valid[1]){
        uint32_t delta=seq[1]-seq[0];
        if(delta==0x80000000u || (!delta && !equal(w->slot[0],w->slot[1],ARP_STORE_BYTES)))return ARP_STORE_CONFLICT;
        if(delta && delta<0x80000000u)pick=1;
    }
    *which=(int)pick;*sequence=seq[pick];return ARP_STORE_OK;
}
int arp_store_load(const arp_store_io *io,const arp_store_key *k,arp_store_state *s,arp_store_workspace *w){
    int which;uint32_t seq;if(!s)return ARP_STORE_INVALID;
    int r=scan(io,k,w,&which,&seq);if(r)return r;
    return arp_store_decode(w->slot[which],ARP_STORE_BYTES,k,s,&seq);
}
int arp_store_save(const arp_store_io *io,const arp_store_key *k,const arp_store_state *s,arp_store_workspace *w){
    int which=1;uint32_t seq=0;
    if(!io || !io->write || !io->sync || !arp_store_valid(s))return ARP_STORE_INVALID;
    int r=scan(io,k,w,&which,&seq);
    if(r!=0 && r!=ARP_STORE_MISSING)return r;
    unsigned target=(unsigned)which^1u,verify=target^1u;seq++;if(!seq)seq=1;
    if(arp_store_encode(s,k,seq,w->slot[target]))return ARP_STORE_INVALID;
    if(io->write(io->context,k,target,w->slot[target],ARP_STORE_BYTES)!=(int)ARP_STORE_BYTES ||
       io->sync(io->context,k,target)<0)return ARP_STORE_IO;
    int n=io->read(io->context,k,target,w->slot[verify],ARP_STORE_BYTES);
    if(n!=(int)ARP_STORE_BYTES || !equal(w->slot[target],w->slot[verify],ARP_STORE_BYTES))return ARP_STORE_IO;
    return ARP_STORE_OK;
}
