/* SPDX-License-Identifier: MIT */
#include "arp_timeline.h"
#include "arp_clock.h"
_Static_assert(ARP_PPQN * ARP_TIMELINE_UNITS_PER_TICK == 21600000u,
               "quarter-note timeline scale");
int arp_timeline_init(arp_timeline *t, uint64_t tick, uint32_t date) {
    if (!t) return -1;
    t->tick = tick; t->date = date; return 0;
}
int arp_timeline_date(const arp_timeline *t, uint64_t tick, uint32_t *date) {
    if (!t || !date || tick < t->tick) return -1;
    uint64_t delta = tick - t->tick;
    if (delta > INT32_MAX / ARP_TIMELINE_UNITS_PER_TICK) return -1;
    *date = t->date + (uint32_t)(delta * ARP_TIMELINE_UNITS_PER_TICK);
    return 0;
}
