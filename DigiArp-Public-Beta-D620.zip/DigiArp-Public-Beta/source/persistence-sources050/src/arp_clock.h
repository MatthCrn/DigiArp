/* SPDX-License-Identifier: MIT */
#ifndef DIGIARP_CLOCK_H
#define DIGIARP_CLOCK_H
#include <stdint.h>
#define ARP_PPQN 960u
/* Pure simulated clock: BPM in thousandths, 20.000..400.000. */
typedef struct { uint32_t bpm_milli, remainder; } arp_clock;
int arp_clock_init(arp_clock *c, uint32_t bpm_milli);
uint32_t arp_clock_next_us(arp_clock *c);
/* denominator 4,8,16,32,64; variant 0 straight,1 dotted,2 triplet */
uint32_t arp_rate_ticks(unsigned denominator, unsigned variant);
#endif
