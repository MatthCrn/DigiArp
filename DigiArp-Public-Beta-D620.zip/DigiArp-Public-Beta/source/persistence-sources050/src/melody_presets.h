/* SPDX-License-Identifier: MIT */
#ifndef DIGIARP_MELODY_PRESETS_H
#define DIGIARP_MELODY_PRESETS_H
#include "melody_engine.h"
enum { MELODY_PRESET_FREE,MELODY_PRESET_BASS,MELODY_PRESET_ARP,MELODY_PRESET_ROLL,MELODY_PRESET_MELO,MELODY_PRESET_FLOW,MELODY_PRESETS };
const char *melody_preset_name(unsigned preset);
unsigned melody_preset_default(unsigned preset,unsigned parameter);
/* FREE is a strict no-op. Other roles regenerate bounded placement, stable
 * contour, durations and accents. ARP keeps chord figures; ROLL keeps a bass
 * palette. Other roles decorate their contour with TENSION. FLOW preserves ARP from 0.46.
 * Root/scale/source/range remain caller-owned; no Sound or tempo access. */
#define MELODY_ARP_FIGURES 16u
/* Equal eight-value MOTION bands, including repeats and interlocking cells. */
unsigned melody_arp_reach(unsigned anchors,unsigned motion);
unsigned melody_arp_period(unsigned reach,unsigned mode);
unsigned melody_arp_index(unsigned position,unsigned reach,unsigned mode,unsigned phase);
/* Nearest source note first; wider chord tones deliberately rare. */
unsigned melody_roll_degree(const melody_config *c,const uint8_t *anchors,unsigned count,unsigned notes,uint32_t rank);
int melody_preset_generate(melody_engine *e,unsigned preset,int vary);
/* Creation identity selects a stable musical family; zero preserves legacy. */
int melody_preset_generate_variant(melody_engine *e,unsigned preset,int vary,uint32_t identity);
#endif
