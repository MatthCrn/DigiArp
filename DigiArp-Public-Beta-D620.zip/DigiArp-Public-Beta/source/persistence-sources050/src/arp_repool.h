/* SPDX-License-Identifier: MIT */
#ifndef ARP_REPOOL_H
#define ARP_REPOOL_H
#include "arp_player.h"
int arp_player_repool(arp_player *,const arp_sequence_config *,const uint8_t *,unsigned);
#endif
