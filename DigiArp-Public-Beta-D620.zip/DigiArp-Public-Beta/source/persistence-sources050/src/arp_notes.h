/* SPDX-License-Identifier: MIT */
#ifndef DIGIARP_NOTES_H
#define DIGIARP_NOTES_H
#include <stddef.h>
#include <stdint.h>
#define ARP_MAX_SOURCE 16
#define ARP_MAX_NOTES 64
/* Sort and deduplicate sources and octave extension. Reject invalid source;
 * omit extended notes outside 0..127. out_count changes only on success. */
int arp_notes_build(const uint8_t *src, size_t count, unsigned octaves,
                    uint8_t out[ARP_MAX_NOTES], uint8_t *out_count);
#endif
