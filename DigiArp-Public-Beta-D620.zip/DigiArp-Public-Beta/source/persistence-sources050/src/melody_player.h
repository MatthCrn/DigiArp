/* SPDX-License-Identifier: MIT */
#ifndef DIGIARP_MELODY_PLAYER_H
#define DIGIARP_MELODY_PLAYER_H
#include "melody_engine.h"
#include "melody_order.h"
#include "melody_rise.h"
enum { MELODY_OFF,MELODY_ON };
typedef struct {uint32_t tick;uint8_t kind,note,velocity,reserved;} melody_note;
typedef int (*melody_emit)(void *,const melody_note *);
typedef struct {
    melody_phrase phrase,pending;
    melody_emit emit;void *context;
    uint32_t now,loop_start,step_ticks,off_at,loops;
    uint8_t running,sounding,note,index,queued,reserved[3];
    melody_order_state head;
    uint32_t seed,pending_step_ticks,gate_ticks,probability_state;
    uint8_t path[16],visit,position,length,mode,pending_length,pending_mode,mode_queued,note_span,probability,rise,rise_ceiling,base_note;
} melody_player;
/* No heap, no firmware access. Maximum 16 steps/phrase and 64 iterations per
 * advance. OFF precedes ON at equal timestamps. Wrap-safe within half-range.
 * Callback failure stops the player; backend remains responsible for release
 * if the OFF callback itself failed. */
int melody_player_start(melody_player *p,const melody_phrase *phrase,
                        uint32_t tick,uint32_t step_ticks,melody_emit emit,void *ctx);
int melody_player_advance(melody_player *p,uint32_t tick);
int melody_player_queue(melody_player *p,const melody_phrase *phrase);
/* Preview of a validated forward phrase, with tick holding the first gate duration. */
int melody_first_forward(const melody_phrase *,uint32_t step,unsigned seed,unsigned probability,unsigned rise,unsigned ceiling,melody_note *note);
int melody_player_start_config_rise(melody_player *p,const melody_phrase *phrase,uint32_t tick,uint32_t step_ticks,unsigned mode,unsigned length,uint32_t seed,unsigned probability,unsigned rise,unsigned ceiling,melody_emit emit,void *ctx);
int melody_player_start_config(melody_player *p,const melody_phrase *phrase,uint32_t tick,uint32_t step_ticks,unsigned mode,unsigned length,uint32_t seed,unsigned probability,melody_emit emit,void *ctx);
int melody_player_start_mode(melody_player *p,const melody_phrase *phrase,uint32_t tick,uint32_t step_ticks,unsigned mode,unsigned length,uint32_t seed,melody_emit emit,void *ctx);
int melody_player_queue_mode(melody_player *p,const melody_phrase *phrase,uint32_t step_ticks,unsigned mode,unsigned length);
/* A held note keeps its original OFF pitch; only future attacks transpose. */
int melody_player_transpose(melody_player *p,int semitones);
int melody_player_stop(melody_player *p,uint32_t tick);
/* Rewind the head without an artificial voice release or root attack. */
int melody_player_rewind(melody_player *p,uint32_t tick);
unsigned melody_player_position(const melody_player *p);
uint32_t melody_player_gate(const melody_player *p);
#endif
