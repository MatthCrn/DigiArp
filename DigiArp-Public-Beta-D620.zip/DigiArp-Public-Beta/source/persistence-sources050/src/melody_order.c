/* SPDX-License-Identifier: MIT */
#include "melody_order.h"
static uint32_t random_next(uint32_t *s){uint32_t x=*s?*s:0x6d2b79f5u;x^=x<<13;x^=x>>17;x^=x<<5;*s=x;return x;}
const char *melody_order_name(unsigned mode){static const char *const names[]={"FWD","REV","PING","UP","DOWN","RAND","SHUF","WALK","DICE"};return mode<MELODY_ORDERS?names[mode]:"?";}
static unsigned pitch(const melody_phrase *p,unsigned step){for(unsigned i=0;i<p->count;i++)if(p->event[i].step==step)return p->event[i].note;return 256;}
int melody_head_path(const melody_phrase *phrase,unsigned mode,unsigned length,melody_order_state *state,uint32_t seed,uint8_t path[16]){
 if(!phrase || !state || !path || mode>=MELODY_ORDERS || !length || length>16 || !melody_phrase_valid(phrase))return -1;
 melody_order_state next=*state;
 if(!next.initialized || next.mode!=mode || next.count!=length)next=(melody_order_state){seed^0xa341316cu,1,mode,length,0,0};
 uint8_t out[16]={0};
 for(unsigned i=0;i<length;i++)out[i]=(uint8_t)(mode==MELODY_REV?length-1-i:i);
 if(mode==MELODY_UP || mode==MELODY_DOWN){
  for(unsigned i=1;i<length;i++)for(unsigned j=i;j;j--){
   unsigned a=pitch(phrase,out[j-1]),b=pitch(phrase,out[j]);
   int ordered=a==256?b==256:b==256?1:mode==MELODY_UP?a<=b:a>=b;
   if(ordered)break;
   uint8_t v=out[j-1];out[j-1]=out[j];out[j]=v;
  }
 }
 if(mode==MELODY_SHUF)for(unsigned i=length-1;i;i--){unsigned j=random_next(&next.rng)%(i+1);uint8_t v=out[i];out[i]=out[j];out[j]=v;}
 for(unsigned i=0;i<length;i++){
  if(mode==MELODY_RAND)out[i]=(uint8_t)(random_next(&next.rng)%length);
  if(mode==MELODY_PING || mode==MELODY_WALK){
   out[i]=(uint8_t)next.cursor;
   if(length>1){
    if(mode==MELODY_WALK)next.backward=random_next(&next.rng)&1u;
    if(!next.cursor)next.backward=0;else if(next.cursor==length-1)next.backward=1;
    if(next.backward)--next.cursor;else ++next.cursor;
   }
  }
 }
 for(unsigned i=0;i<16;i++)path[i]=out[i];
 *state=next;return 0;
}
