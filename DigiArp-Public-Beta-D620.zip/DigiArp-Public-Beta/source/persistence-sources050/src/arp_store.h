/* SPDX-License-Identifier: MIT */
#ifndef DIGIARP_STORE_H
#define DIGIARP_STORE_H
#include <stdint.h>
#define ARP_STORE_TRACKS 8u
#define ARP_STORE_BYTES 540u
/* Explicit format, independent of firmware struct padding and byte order.
 * Revision counters, running notes, queues and LFO output are never saved. */
typedef struct {
    uint32_t settings;
    uint16_t mask;
    uint8_t enabled,length,source,preset,count;
    int8_t offsets[16],legacy_offsets[16];
    uint8_t manual_count,manual[16],manual_octave,fixed_root,fixed_octave;
} arp_store_track;
typedef struct { arp_store_track track[ARP_STORE_TRACKS]; } arp_store_state;
typedef struct { uint8_t project[16],pattern; } arp_store_key;
enum { ARP_STORE_OK=0, ARP_STORE_MISSING=1,
       ARP_STORE_INVALID=-1, ARP_STORE_IO=-2, ARP_STORE_CORRUPT=-3,
       ARP_STORE_CONFLICT=-4 };
/* Backend is UI/task-context only. read: exact byte count, 0 missing, <0 error.
 * write: exact byte count or failure. sync: 0 success, <0 failure.
 * Caller supplies a PROVEN project identity and pattern; no firmware addresses
 * or on-device filesystem calls are assumed by this portable component. */
typedef struct {
    void *context;
    int (*read)(void *,const arp_store_key *,unsigned,uint8_t *,unsigned);
    int (*write)(void *,const arp_store_key *,unsigned,const uint8_t *,unsigned);
    int (*sync)(void *,const arp_store_key *,unsigned);
} arp_store_io;
typedef struct { uint8_t slot[2][ARP_STORE_BYTES]; } arp_store_workspace;
int arp_store_valid(const arp_store_state *state);
int arp_store_encode(const arp_store_state *,const arp_store_key *,uint32_t,uint8_t [ARP_STORE_BYTES]);
/* All failures leave state/sequence unchanged. Exact size and key required. */
int arp_store_decode(const uint8_t *,unsigned,const arp_store_key *,arp_store_state *,uint32_t *);
int arp_store_load(const arp_store_io *,const arp_store_key *,arp_store_state *,arp_store_workspace *);
/* Alternate slots, synchronize, read back and compare. Never overwrite the
 * newest valid slot. An interrupted save can leave the previous OR new valid
 * record; a failing return must not be represented as a completed save. */
int arp_store_save(const arp_store_io *,const arp_store_key *,const arp_store_state *,arp_store_workspace *);
#endif
