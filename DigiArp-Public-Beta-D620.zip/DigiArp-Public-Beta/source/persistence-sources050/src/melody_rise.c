/* SPDX-License-Identifier: MIT */
#include "melody_rise.h"
unsigned melody_rise_note(unsigned note,unsigned step,unsigned amount,uint32_t seed,unsigned ceiling){
    if(!amount || note>ceiling || ceiling>127 || amount>127 || note>127)return note;
    uint32_t rank=seed^((step+1u)*0x9e3779b9u);
    rank^=rank>>16;rank*=0x7feb352du;rank^=rank>>15;rank*=0x846ca68bu;rank^=rank>>16;
    unsigned threshold=rank%127u;
    if(!(step%4u))threshold=64u+threshold/2u;
    unsigned available=(ceiling-note)/12u;
    unsigned scaled=amount*available,octaves=scaled/127u;
    if(threshold<scaled%127u)++octaves;
    if(octaves>available)octaves=available;
    return note+12u*octaves;
}
