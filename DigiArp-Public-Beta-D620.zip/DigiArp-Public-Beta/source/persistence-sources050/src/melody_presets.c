/* SPDX-License-Identifier: MIT */
#include "melody_presets.h"
static uint32_t random_next(uint32_t *s){uint32_t x=*s?*s:0x6d2b79f5u;x^=x<<13;x^=x>>17;x^=x<<5;*s=x;return x;}
const char *melody_preset_name(unsigned preset){
    static const char *const names[]={"FREE","BASS","ARP","ROLL","MELO","FLOW"};
    return preset<MELODY_PRESETS?names[preset]:"?";
}
unsigned melody_preset_default(unsigned preset,unsigned parameter){
    static const uint8_t values[MELODY_PRESETS][4]={
        {76,45,2,MELODY_TENSION_SOFT}, {55,25,1,MELODY_TENSION_SOFT},
        {72,64,2,MELODY_TENSION_OFF}, {96,20,1,MELODY_TENSION_OFF},
        {64,60,2,MELODY_TENSION_SOFT}, {64,64,2,MELODY_TENSION_OFF}};
    return preset<MELODY_PRESETS && parameter<4?values[preset][parameter]:0;
}
unsigned melody_arp_reach(unsigned anchors,unsigned motion){
    if(anchors<2 || !motion)return 1;
    if(anchors==2)return 2;
    return 2u+((anchors-2u)*motion+126u)/127u;
}
unsigned melody_arp_period(unsigned reach,unsigned mode){
    if(reach<2)return 1;
    if(mode==2 || mode==3 || mode==5 || mode==10)return 2u*(reach-1u);
    if(mode==6)return reach*reach;
    if(mode==4 || mode==9 || mode==12)return 2u*reach;
    if(mode==11 || mode==14 || mode==15)return 3u*reach;
    if(mode==13)return 4u*reach;
    return reach;
}
unsigned melody_arp_index(unsigned position,unsigned reach,unsigned mode,unsigned phase){
    if(reach<2)return 0;
    unsigned pos=position+phase,at=pos%reach;
    if(mode==2 || mode==3){
        unsigned period=2u*(reach-1u);at=pos%period;
        unsigned i=at<reach?at:period-at;return mode==3?reach-1u-i:i;
    }
    if(mode==8)return at%2?reach-1u-at/2u:at/2u;
    if(mode==5){at=pos%(2u*(reach-1u));return at%2?1+at/2u:0;}
    if(mode==6)return (pos*2u+pos/reach)%reach;
    if(mode==7){unsigned mid=(reach-1u)/2u;return at%2?mid+(at+1u)/2u:mid-at/2u;}
    if(mode==4)return (pos/2u)%reach;
    if(mode==9)return reach-1u-(pos/2u)%reach;
    if(mode==10){at=pos%(2u*(reach-1u));return at%2?at/2u:reach-1u;}
    if(mode==11)return (pos/3u+(pos%3u==1u?1u:0u))%reach;
    if(mode==12)return (pos/2u+2u*(pos%2u))%reach;
    if(mode==13){at=(pos/4u)%reach;return pos%4u==1u || pos%4u==2u?reach-1u-at:at;}
    if(mode==14)return (pos/3u+pos%3u)%reach;
    if(mode==15){static const uint8_t broken[3]={0,2,1};return reach-1u-(pos/3u+broken[pos%3u])%reach;}
    return mode==1?reach-1u-at:at;
}
unsigned melody_roll_degree(const melody_config *c,const uint8_t *anchors,unsigned count,unsigned notes,uint32_t rank){
    if(notes<2)return anchors[0];
    unsigned high=c->motion>63?(c->motion-63u)/8u:0u;
    unsigned local=c->motion>31?(c->motion-31u)/6u:0u;
    unsigned reach=1+((count-1u)*c->motion+126u)/127u,draw=rank%128u;
    if(high && draw>=128u-high && reach>2)return anchors[2u+(rank>>8)%(reach-2u)];
    if(local && draw>=128u-high-local && count>1)return anchors[1];
    return 1; /* First sorted source note above the fundamental. */
}
static int generate_preset(melody_engine *e,unsigned preset,int vary,uint32_t identity){
    if(!e || preset>=MELODY_PRESETS || !melody_phrase_valid(&e->phrase))return -1;
    if(preset==MELODY_PRESET_FREE)return 0;
    uint8_t pool[MELODY_POOL],anchors[MELODY_POOL];
    int n=melody_pool(&e->config,pool),anchor_count=melody_anchor_degrees(&e->config,pool,n,anchors);
    if(n<0 || anchor_count<1)return -1;
    if(preset==MELODY_PRESET_BASS){
        for(unsigned j=1;j<(unsigned)anchor_count;j++)if((pool[anchors[j]]+120u-e->config.root)%12==7){
            uint8_t v=anchors[1];anchors[1]=anchors[j];anchors[j]=v;break;
        }
    }
    /* A smooth convex opening preserves Motion's spacious low/mid range,
     * then rejoins the full grid without an endpoint override. x - k*x*(1-x),
     * 0 <= k <= 1/2: increasing in RHY and MOTION, bounded slope 1/2..3/2.
     * Integer arithmetic fits uint32_t, endpoints 0/1/126/127 -> 0/1/15/16. */
    unsigned count=0;
    if(e->config.rhythm){
        unsigned x=e->config.rhythm-1u;
        unsigned curve=x*(32004u-(127u-e->config.motion)*(126u-x));
        count=1u+15u*curve/4032504u;
    }
    uint32_t state=e->mutation_state,token=vary?random_next(&state):e->new_state^0x9e3779b9u;
    unsigned mask=0;
    if(preset==MELODY_PRESET_ARP || preset==MELODY_PRESET_FLOW){
        for(unsigned i=0;i<count;i++)mask|=1u<<(i*16/count);
    }else if(preset==MELODY_PRESET_BASS){
        static const uint8_t order[4][16]={
            {0,6,8,14,3,10,12,4,7,15,2,5,9,11,1,13},
            {0,7,8,14,3,10,12,4,6,15,2,5,9,11,1,13},
            {0,4,8,12,6,14,3,10,7,15,2,5,9,11,1,13},
            {0,3,8,11,6,14,4,12,7,15,2,5,9,10,1,13}};
        for(unsigned i=0;i<count;i++)mask|=1u<<order[identity?((identity>>4)&3u):vary?(token&1u):0][i];
    }else if(preset==MELODY_PRESET_ROLL){
        static const uint8_t order[4][16]={
            {0,8,4,12,2,6,10,14,1,3,5,7,9,11,13,15},
            {0,8,4,12,2,10,7,15,6,14,3,11,1,9,5,13},
            {0,8,4,12,3,11,6,14,2,10,7,15,1,9,5,13},
            {0,8,4,12,2,10,6,15,7,14,3,11,1,9,5,13}};
        for(unsigned i=0;i<count;i++)mask|=1u<<order[identity?((identity>>6)&3u):0][i];
    }else{
        static const uint8_t half[4][8]={{0,2,4,6,3,5,7,1},{0,4,2,6,3,7,1,5},
            {0,3,4,6,2,5,7,1},{0,4,3,7,2,6,1,5}};
        for(unsigned i=0;i<count;i++)mask|=1u<<(half[identity?((identity>>8)&3u):0][i/2]+8*(i%2));
    }
    if(preset!=MELODY_PRESET_ARP && count>1 && count<16 && e->config.rhythm%8u){
        unsigned from[16],to[16],nf=0,nt=0;
        for(unsigned j=1;j<16;j++)if(j%4){
            if(mask&(1u<<j))from[nf++]=j;
            else if(!(j%2) || e->config.rhythm%8u>=4)to[nt++]=j;
        }
        if(nf && nt){unsigned phase=e->config.rhythm%8u;mask^=1u<<from[(phase-1u)%nf];mask|=1u<<to[(phase-1u)%nt];}
    }
    /* ROLL opens a ranked set of colour slots directly: no second random
     * veto after choosing a note. A quarter of eligible slots, rounded up;
     * downbeats 0/8 stay rooted and weaker positions open first. */
    unsigned roll_colour[16]={0};
    if(preset==MELODY_PRESET_ROLL && e->config.motion>=8 && n>1){
        unsigned slots[16],keys[16],eligible=0;
        for(unsigned step=0;step<16;step++)if((mask&(1u<<step)) && step%8){
            uint32_t rank=e->config.seed^(step*0x9e3779b9u);rank^=rank>>16;rank*=0x7feb352du;rank^=rank>>15;
            unsigned key=(rank&127u)+(step%4?0u:128u),at=eligible++;
            while(at && keys[at-1]>key){keys[at]=keys[at-1];slots[at]=slots[at-1];--at;}
            keys[at]=key;slots[at]=step;
        }
        unsigned budget=(eligible*(e->config.motion-7u)+479u)/480u;
        for(unsigned j=0;j<budget;j++){
            uint32_t rank=e->config.seed^(slots[j]*0x85ebca6bu);rank^=rank>>16;rank*=0x7feb352du;rank^=rank>>15;
            roll_colour[slots[j]]=melody_roll_degree(&e->config,anchors,(unsigned)anchor_count,(unsigned)n,rank);
        }
    }
    melody_phrase p={0};p.length=16;
    for(unsigned step=0;step<16;step++)if(mask&(1u<<step)){
        unsigned i=p.count,index=0;
        if(preset==MELODY_PRESET_BASS){
            unsigned fifth=0;
            for(unsigned j=0;j<(unsigned)anchor_count;j++)if((pool[anchors[j]]+120u-e->config.root)%12==7){fifth=j;break;}
            if(step%8 && i%3==2)index=fifth;
            if(step%8 && e->config.motion>=48 && i%4==1)index=anchor_count>1?1:0;
            if(e->config.motion>=96 && step%8 && anchor_count>3)index=(index+3u)%(unsigned)anchor_count;
        }else if(preset==MELODY_PRESET_FLOW){
            unsigned phase=identity?identity%(unsigned)anchor_count:vary?(token%2u):0;
            if(e->config.motion<43)index=(i+phase)%(unsigned)anchor_count;
            else if(e->config.motion<=85 && anchor_count>1){
                unsigned period=2u*((unsigned)anchor_count-1u),at=(i+phase)%period;
                index=at<(unsigned)anchor_count?at:period-at;
            }else index=(i*2u+i/3u+phase)%(unsigned)anchor_count;
            if(identity&0x1000u)index=(unsigned)anchor_count-1u-index;
        }else{
            static const uint8_t motif[4][4]={{0,1,2,1},{0,2,1,2},{0,1,1,2},{0,2,1,1}};
            unsigned reach=1+((unsigned)anchor_count-1u)*e->config.motion/127u;
            index=(motif[identity?((identity>>10)&3u):0][i%4]*reach/2u)%(unsigned)anchor_count;
            if(vary && i>=4 && i+2==count)index=(index+(token&1u))%(unsigned)anchor_count;
            if(!i || i+1==count)index=0;
        }
        /* Stable per-position thresholds avoid reseeding the phrase when B moves.
         * Root on strong beats, nearby chord tones first, wider colour later. */
        unsigned motion=e->config.motion;
        uint32_t rank=e->config.seed^(step*0x9e3779b9u);rank^=rank>>16;rank*=0x7feb352du;rank^=rank>>15;
        unsigned reach=1+(((unsigned)anchor_count-1u)*motion+126u)/127u;
        if(preset==MELODY_PRESET_ARP){
            unsigned arp_reach=melody_arp_reach((unsigned)anchor_count,motion);
            unsigned mode=(motion/8u+(identity?((identity>>12)&15u):0))%MELODY_ARP_FIGURES;
            unsigned phase=identity?identity%melody_arp_period(arp_reach,mode):0;
            index=melody_arp_index(i,arp_reach,mode,phase);
        }
        else if(preset==MELODY_PRESET_ROLL)index=0; /* Full source pool used below. */
        else if(!i || motion==0 || (rank%128u)>=motion)index=0;
        else {
            if(index>=reach)index=reach-1;
            if(motion>48 && step%4 && ((rank>>8)%128u)<motion-48)
                index=(rank>>16)%reach;
            if(!(step%8) && (preset==MELODY_PRESET_BASS || preset==MELODY_PRESET_ROLL))index=0;
        }
        unsigned next=step+1;while(next<16 && !(mask&(1u<<next)))++next;
        unsigned gap=next-step,duration=1;
        if(preset==MELODY_PRESET_BASS && !(step%8) && gap>=3)duration=2;
        if(preset==MELODY_PRESET_MELO)duration=gap>=4 && i+1==count?4:gap>=2?2:1;
        /* Eighth/quarter sustains in the gaps, sixteenth attacks in dense rolls. */
        if(gap>=2 && preset!=MELODY_PRESET_MELO && ((rank>>4)%128u)<(96u-motion/2u))duration=2;
        if(gap>=4 && motion<48 && !(step%4))duration=4;
        if(gap>=2 && e->config.rhythm%8u>=4 && preset!=MELODY_PRESET_MELO)duration=duration==1?2:1;
        unsigned velocity=step%4?88:108;
        if(preset==MELODY_PRESET_BASS)velocity=step%4?(i%3?96:80):112;
        if(preset==MELODY_PRESET_ROLL)velocity=(step%4?88:112)+(vary?(token&3u):0);
        if(preset==MELODY_PRESET_MELO)velocity=i%4?92:108;
        /* A touch more accent contrast as Motion opens, without changing the
         * preset's quarter-note accents or making the low end jumpy. */
        if(step%4)velocity=velocity-4u+(motion*((rank>>12)%9u))/127u;
        unsigned degree=preset==MELODY_PRESET_ROLL?roll_colour[step]:anchors[index];
        p.event[p.count++]=(melody_event){(uint8_t)step,(uint8_t)duration,pool[degree],(uint8_t)velocity,(int16_t)degree,(uint8_t)(i/4),0};
    }
    if(!melody_phrase_valid(&p))return -1;
    melody_engine result=*e;result.phrase=p;result.mutation_state=state;
    if(preset!=MELODY_PRESET_ARP && preset!=MELODY_PRESET_ROLL && melody_tension_contour(&result,e->config.motion<32?MELODY_TENSION_OFF:e->config.tension,0))return -1;
    result.config.tension=e->config.tension;
    result.previous=e->phrase;result.previous_config=e->config;result.undo_valid=1;
    *e=result;return 0;
}

int melody_preset_generate(melody_engine *e,unsigned preset,int vary){return generate_preset(e,preset,vary,0);}
int melody_preset_generate_variant(melody_engine *e,unsigned preset,int vary,uint32_t identity){return generate_preset(e,preset,vary,identity);}
