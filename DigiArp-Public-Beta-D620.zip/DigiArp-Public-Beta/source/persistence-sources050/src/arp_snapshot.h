/* SPDX-License-Identifier: MIT */
#ifndef DIGIARP_SNAPSHOT_H
#define DIGIARP_SNAPSHOT_H
#include <stdint.h>
#define ARP_SNAPSHOT_BYTES 440u
#define ARP_REF_BYTES 24u
/* Only current functional controls; deprecated source-offset arrays are
 * not used by TRIG/CUSTOM/FIXED and stay outside this format. */
typedef struct {
 uint32_t settings;
 uint16_t mask;
 uint8_t enabled,length,source,preset,count;
 int8_t offsets[16];
 uint8_t manual_count,manual[16],manual_octave,fixed_root,fixed_octave;
 uint8_t key,probability,pulses,rotation,lfo[2];
} arp_snapshot_track;
typedef struct {arp_snapshot_track track[8];} arp_snapshot_state;
int arp_snapshot_valid(const arp_snapshot_state *);
void arp_snapshot_default(arp_snapshot_state *);
int arp_snapshot_encode(const arp_snapshot_state *,uint8_t [ARP_SNAPSHOT_BYTES]);
int arp_snapshot_decode(const uint8_t *,unsigned,arp_snapshot_state *);
void arp_snapshot_id(const uint8_t *,unsigned,uint8_t [16]);
void arp_snapshot_ref(const uint8_t [16],uint8_t [ARP_REF_BYTES]);
int arp_snapshot_ref_valid(const uint8_t [ARP_REF_BYTES]);
#endif
