/* SPDX-License-Identifier: MIT */
#ifndef MELODY_RISE_H
#define MELODY_RISE_H
#include <stdint.h>
/* Stable per-step octave lift; no random state is consumed. Saturation uses
 * whole octaves only, so the pitch class and source note stay intact. */
unsigned melody_rise_note(unsigned note,unsigned step,unsigned amount,uint32_t seed,unsigned ceiling);
#endif
