/* SPDX-License-Identifier: MIT */
#ifndef DIGIARP_LZ_H
#define DIGIARP_LZ_H
#include <stdint.h>
int arp_lz_pack(const uint8_t *,unsigned,uint8_t *,unsigned,uint32_t [1024]);
int arp_lz_unpack(const uint8_t *,unsigned,uint8_t *,unsigned);
#endif
