/* SPDX-License-Identifier: MIT */
#ifndef DIGIARP_MELODY_MUTATION_H
#define DIGIARP_MELODY_MUTATION_H
#include "melody_presets.h"
/* Amount 0 is a strict no-op. Variation keeps scale and attack count;
 * Chaos may change pitch classes and, above 80, add/remove attacks.
 * Both keep the 16-step horizon, MIDI36..84 and bounded work. */
int melody_variation(melody_engine *e,unsigned preset,unsigned amount);
int melody_chaos(melody_engine *e,unsigned amount,int vary);
#endif
