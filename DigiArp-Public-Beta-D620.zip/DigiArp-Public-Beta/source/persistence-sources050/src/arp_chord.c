/* SPDX-License-Identifier: MIT */
#include "arp_chord.h"
int arp_chord_offsets(unsigned source,unsigned preset,const int8_t *custom,
                      unsigned count,int8_t out[ARP_CHORD_MAX]){
    static const int8_t chords[9][4]={{0,4,7,0},{0,3,7,0},{0,4,7,10},
        {0,3,7,10},{0,4,7,11},{0,2,7,0},{0,5,7,0},{0,3,6,0},{0,4,8,0}};
    if(!out || source>ARP_SOURCE_CUSTOM || preset>=ARP_CHORD_PRESETS)return -1;
    if(source==ARP_SOURCE_SINGLE){out[0]=0;return 1;}
    if(source==ARP_SOURCE_PRESET){
        count=preset>=2 && preset<=4?4:3;
        for(unsigned i=0;i<count;i++)out[i]=chords[preset][i];
        return (int)count;
    }
    if(!custom || !count || count>ARP_CHORD_MAX)return -1;
    for(unsigned i=0;i<count;i++){
        if(custom[i]<-48 || custom[i]>63)return -1;
        for(unsigned j=0;j<i;j++)if(custom[i]==custom[j])return -1;
    }
    for(unsigned i=0;i<count;i++)out[i]=custom[i];
    return (int)count;
}
int arp_chord_resolve(unsigned root,const int8_t *offsets,unsigned count,
                     uint8_t out[ARP_CHORD_MAX]){
    if(root>127 || !offsets || !out || !count || count>ARP_CHORD_MAX)return -1;
    for(unsigned i=0;i<count;i++){
        if(offsets[i]<-48 || offsets[i]>63)return -1;
        for(unsigned j=0;j<i;j++)if(offsets[i]==offsets[j])return -1;
    }
    unsigned n=0;
    for(unsigned i=0;i<count;i++){
        int note=(int)root+offsets[i];if(note>=0 && note<=127)out[n++]=(uint8_t)note;
    }
    return (int)n;
}
