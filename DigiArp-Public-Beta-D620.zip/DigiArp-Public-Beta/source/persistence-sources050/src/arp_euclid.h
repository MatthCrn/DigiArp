/* SPDX-License-Identifier: MIT */
#ifndef DIGIARP_EUCLID_H
#define DIGIARP_EUCLID_H
#include <stdint.h>
/* Maximally even bucket distribution, first beat at 0, clockwise rotation.
 * At most 16 bounded iterations; no pattern storage writes or allocation. */
static inline uint16_t arp_euclid_mask(unsigned steps,unsigned pulses,unsigned rotation){
 if(!steps || steps>16 || pulses>steps)return 0;
 uint16_t mask=0;rotation%=steps;
 for(unsigned i=0;i<steps;i++)if((i*pulses)%steps<pulses)mask|=(uint16_t)(1u<<((i+rotation)%steps));
 return mask;
}
#endif
