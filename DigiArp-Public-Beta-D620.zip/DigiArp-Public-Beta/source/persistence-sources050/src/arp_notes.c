/* SPDX-License-Identifier: MIT */
#include "arp_notes.h"
int arp_notes_build(const uint8_t *src, size_t count, unsigned octaves,
                    uint8_t out[ARP_MAX_NOTES], uint8_t *out_count) {
    uint8_t seen[128] = {0};
    unsigned n = 0;
    if (!src || !out || !out_count || !count || count > ARP_MAX_SOURCE ||
        !octaves || octaves > 4) return -1;
    for (size_t i = 0; i < count; ++i) {
        if (src[i] > 127) return -1;
        for (unsigned o = 0; o < octaves; ++o) {
            unsigned note = src[i] + 12 * o;
            if (note <= 127) seen[note] = 1;
        }
    }
    for (unsigned i = 0; i < 128; ++i) if (seen[i]) out[n++] = (uint8_t)i;
    *out_count = (uint8_t)n;
    return 0;
}
