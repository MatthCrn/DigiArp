/* SPDX-License-Identifier: MIT */
#include "arp_engine.h"
#include "arp_clock.h"
#include <string.h>
static void event(arp_engine *a, arp_event_kind kind, uint64_t tick) {
    arp_event e = {tick, kind, a->active_note, kind == ARP_ON ? a->config.velocity : 0};
    a->emit(a->ctx, &e);
}
static void release(arp_engine *a, uint64_t tick) {
    if (a->sounding) { a->sounding = false; event(a, ARP_OFF, tick); }
}
static void onset(arp_engine *a, uint64_t tick) {
    uint32_t index;
    if (a->config.mode == ARP_RANDOM) {
        uint32_t x = a->rng;
        x ^= x << 13; x ^= x >> 17; x ^= x << 5;
        a->rng = x; index = x % a->count; /* slight modulo bias documented */
    } else {
        index = a->cursor;
        uint32_t cycle=a->count;
        if ((a->config.mode==ARP_UP_DOWN || a->config.mode==ARP_DOWN_UP) && a->count>1) {
            cycle=2u*a->count-2u;
            if(index>=a->count)index=cycle-index;
        }
        if (a->config.mode == ARP_DOWN || a->config.mode==ARP_DOWN_UP) index = a->count - 1 - index;
        a->cursor = (a->cursor + 1) % cycle;
    }
    a->active_note = a->notes[index]; a->sounding = true; event(a, ARP_ON, tick);
}
int arp_init(arp_engine *a, arp_emit emit, void *ctx) {
    if (!a || !emit) return -1;
    memset(a, 0, sizeof *a); a->emit = emit; a->ctx = ctx;
    arp_config cfg = {ARP_UP, ARP_PPQN / 4, 1, 50, 1, 100};
    return arp_configure(a, &cfg);
}
int arp_configure(arp_engine *a, const arp_config *cfg) {
    if (!a || !cfg || !a->emit || a->running || a->count ||
        (cfg->mode != ARP_UP && cfg->mode != ARP_DOWN && cfg->mode != ARP_RANDOM &&
         cfg->mode != ARP_UP_DOWN && cfg->mode != ARP_DOWN_UP) ||
        !cfg->period_ticks || cfg->period_ticks > ARP_PPQN * 4 ||
        !cfg->gate_percent || cfg->gate_percent > 100 || !cfg->octaves ||
        cfg->octaves > 4 || !cfg->velocity || cfg->velocity > 127) return -1;
    a->config = *cfg;
    a->gate_ticks = cfg->period_ticks * cfg->gate_percent / 100;
    if (!a->gate_ticks) a->gate_ticks = 1;
    return 0;
}
int arp_set_notes(arp_engine *a, const uint8_t *notes, size_t count) {
    uint8_t buf[ARP_MAX_NOTES], n;
    if (!a || a->running || arp_notes_build(notes, count, a->config.octaves, buf, &n)) return -1;
    memcpy(a->notes, buf, n); a->count = n; return 0;
}
int arp_stop(arp_engine *a, uint64_t tick) {
    if (!a || (a->running && tick < a->last_tick)) return -1;
    release(a, tick); a->running = false; return 0;
}
int arp_start(arp_engine *a, uint64_t tick) {
    if (!a || !a->emit || !a->count || (a->running && tick < a->last_tick)) return -1;
    release(a, tick); a->cursor = 0; a->phase = 0;
    a->rng = a->config.seed ? a->config.seed : 1;
    a->last_tick = tick; a->running = true; onset(a, tick); return 0;
}
int arp_tick(arp_engine *a, uint64_t tick) {
    if (!a) return -1;
    if (!a->running) return 0;
    if (tick < a->last_tick) return -1;
    if (tick == a->last_tick) return 0;
    if (tick - a->last_tick != 1) { (void)arp_stop(a, tick); return -1; }
    a->last_tick = tick; ++a->phase;
    if (a->phase >= a->gate_ticks) release(a, tick);
    if (a->phase == a->config.period_ticks) {
        a->phase = 0; onset(a, tick);
    }
    return 0;
}
