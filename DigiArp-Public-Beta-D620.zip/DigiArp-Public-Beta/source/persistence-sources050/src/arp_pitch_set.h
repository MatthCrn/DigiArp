/* SPDX-License-Identifier: MIT */
#ifndef DIGIARP_PITCH_SET_H
#define DIGIARP_PITCH_SET_H
#include <stdint.h>
#define ARP_PITCH_SETS 23u
#define ARP_SOURCE_GENERATED 3u
/* First N degrees above the trig root, continued through octaves. No heap.
 * 1..16 notes, unique offsets 0..63. Invalid input leaves output unchanged. */
int arp_pitch_set(unsigned set,unsigned count,int8_t out[16]);
const char *arp_pitch_set_name(unsigned set);
#endif
