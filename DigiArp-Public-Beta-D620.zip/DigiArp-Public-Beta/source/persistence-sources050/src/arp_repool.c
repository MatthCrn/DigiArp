/* SPDX-License-Identifier: MIT */
#include "arp_repool.h"
int arp_player_repool(arp_player *p,const arp_sequence_config *cfg,const uint8_t *notes,unsigned count){
    if(!p || !p->running)return -1;
    arp_sequence next;
    if(arp_sequence_init(&next,cfg,notes,count))return -1;
    next.position=p->sequence.position<cfg->length?p->sequence.position:0;
    next.index=p->sequence.index%count;
    next.octave=p->sequence.octave%cfg->range;
    next.probability_state=p->sequence.probability_state;
    next.descending=p->sequence.descending;next.random_state=p->sequence.random_state;
    for(unsigned i=0;i<count;i++)p->source_notes[i]=notes[i];
    p->sequence=next;return 0;
}
