/* SPDX-License-Identifier: MIT */
#include "melody_engine.h"
#include "arp_pitch_set.h"

static uint32_t next(uint32_t *s){
    uint32_t x=*s?*s:0x6d2b79f5u;
    x^=x<<13;x^=x>>17;x^=x<<5;*s=x;return x;
}
static unsigned distance(unsigned a,unsigned b){return a>b?a-b:b-a;}
int melody_phrase_valid(const melody_phrase *p){
    if(!p || p->length!=MELODY_STEPS || p->count>MELODY_STEPS)return 0;
    unsigned until=0;
    for(unsigned i=0;i<p->count;i++){
        const melody_event *v=&p->event[i];
        if(v->step<until || !v->span || v->step+v->span>p->length ||
           v->note>127 || !v->velocity || v->velocity>127 || v->degree<0 ||
           v->degree>=(int)MELODY_POOL)return 0;
        until=v->step+v->span;
    }
    return 1;
}
int melody_pool(const melody_config *c,uint8_t out[MELODY_POOL]){
    if(!c || !out || c->root>127 || c->scale>=ARP_PITCH_SETS ||
       c->source>MELODY_ARP || c->range<1 || c->range>MELODY_OCTAVES ||
       c->repeat<1 || c->repeat>16 || c->complexity>127 || c->motion>127 ||
       c->ceiling>127 || c->rhythm>127 || c->density>127 || c->variation>127 || c->tension>MELODY_TENSION_HARD)return -1;
    uint8_t classes[12]={0},pool[MELODY_POOL];unsigned count=0;
    if(c->source==MELODY_ARP){
        if(!c->arp_count || c->arp_count>16)return -1;
        for(unsigned i=0;i<c->arp_count;i++){
            if(c->arp[i]>127)return -1;
            classes[(c->arp[i]+132u-c->root)%12]=1;
        }
    }else{
        int8_t offsets[16];
        if(arp_pitch_set(c->scale,16,offsets)<0)return -1;
        for(unsigned i=0;i<16 && offsets[i]<12;i++)classes[(unsigned)offsets[i]]=1;
    }
    for(unsigned octave=0;octave<c->range;octave++)for(unsigned i=0;i<12;i++)if(classes[i]){
        unsigned note=c->root+12*octave+i;
        if(c->ceiling && note>c->ceiling)continue;
        if(note>127)return -1;
        pool[count++]=(uint8_t)note;
    }
    if(!count)return -1;
    for(unsigned i=0;i<count;i++)out[i]=pool[i];
    return (int)count;
}
static unsigned stable(const melody_config *c,unsigned degree,unsigned tones){
    unsigned d=degree%tones;
    return !d || (c->source==MELODY_SCALE && (d==2 || d==4));
}
static unsigned choose(const melody_config *c,unsigned previous,int direction,
                       unsigned count,unsigned tones,int cadence,uint32_t *rng){
    unsigned weights[MELODY_POOL],total=0;
    unsigned tension=127u*c->tension/MELODY_TENSION_HARD;
    unsigned jump=1+6u*c->motion/127;
    for(unsigned i=0;i<count;i++){
        unsigned delta=distance(i,previous),w=0;
        if(delta<=jump){
            w=delta?(jump+1-delta)*16u:18u;
            if((direction>0 && i>previous) || (direction<0 && i<previous))w+=24;
            if(stable(c,i,tones))w+=2u*(127-tension);
            else w+=2u*tension;
            if(cadence && !(i%tones))w+=6u*(127-tension);
        }
        weights[i]=w;total+=w;
    }
    unsigned pick=next(rng)%total;
    for(unsigned i=0;i<count;i++){if(pick<weights[i])return i;pick-=weights[i];}
    return previous;
}
static unsigned span(unsigned gap,unsigned rhythm,uint32_t *rng){
    if(rhythm<32 || gap<2)return 1;
    unsigned r=next(rng)%128;
    if(gap>=4 && r<rhythm/2)return 4;
    return r<rhythm?2:1;
}
static int generate(const melody_config *c,uint32_t *rng,melody_phrase *p){
    uint8_t pool[MELODY_POOL];int n=melody_pool(c,pool);if(n<0)return -1;
    *p=(melody_phrase){0};p->length=MELODY_STEPS;
    unsigned count=(16u*c->density+63)/127;
    p->count=(uint8_t)count;if(!count)return 0;
    uint8_t positions[16],used[16]={0};
    for(unsigned i=0;i<count;i++){positions[i]=(uint8_t)(i*16/count);used[positions[i]]=1;}
    /* Bounded one-pass grid displacement; anchor at step zero survives. */
    for(unsigned i=1;i<count;i++)if(next(rng)%128<c->rhythm){
        int offset=(next(rng)&1u)?1:-1,at=positions[i]+offset;
        if(at>0 && at<16 && !used[at]){used[positions[i]]=0;positions[i]=(uint8_t)at;used[at]=1;}
    }
    for(unsigned i=1;i<count;i++)for(unsigned j=i;j && positions[j]<positions[j-1];j--){
        uint8_t t=positions[j];positions[j]=positions[j-1];positions[j-1]=t;
    }
    unsigned tones=0;while(tones<(unsigned)n && pool[tones]<c->root+12u)++tones;
    unsigned cell_length=2+2u*c->complexity/127,cell[4]={0},previous=0;
    int direction=(next(rng)&1u)?1:-1;
    for(unsigned i=1;i<cell_length;i++){
        cell[i]=choose(c,previous,direction,(unsigned)n,tones,0,rng);
        if(cell[i]!=previous)direction=cell[i]>previous?1:-1;
        previous=cell[i];
    }
    previous=0;
    for(unsigned i=0;i<count;i++){
        unsigned degree=cell[i%cell_length];
        if(i>=cell_length && next(rng)%128<c->complexity)
            degree=choose(c,previous,direction,(unsigned)n,tones,i+1==count,rng);
        if(i && degree!=previous)direction=degree>previous?1:-1;
        unsigned gap=(i+1<count?positions[i+1]:16)-positions[i];
        p->event[i]=(melody_event){positions[i],(uint8_t)span(gap,c->rhythm,rng),pool[degree],
            (uint8_t)(positions[i]%4?88:104),(int16_t)degree,(uint8_t)(i/cell_length),0};
        previous=degree;
    }
    return 0;
}
int melody_init(melody_engine *e,const melody_config *c){
    if(!e || !c)return -1;
    melody_engine v={0};v.config=*c;
    v.new_state=c->seed^0xa341316cu;v.mutation_state=c->seed^0xc8013ea4u;
    if(generate(c,&v.new_state,&v.phrase))return -1;
    *e=v;return 0;
}
int melody_new(melody_engine *e){
    if(!e)return -1;
    melody_phrase p;uint32_t rng=e->new_state;
    if(generate(&e->config,&rng,&p))return -1;
    e->previous=e->phrase;e->previous_config=e->config;e->undo_valid=1;e->phrase=p;e->new_state=rng;e->repetitions=0;
    return 0;
}
int melody_evolve(melody_engine *e){
    if(!e)return -1;
    if(e->frozen || !e->config.variation || e->phrase.count<2)return 0;
    uint8_t pool[MELODY_POOL];int n=melody_pool(&e->config,pool);if(n<0)return -1;
    melody_phrase p=e->phrase;uint32_t rng=e->mutation_state;
    unsigned tones=0;while(tones<(unsigned)n && pool[tones]<e->config.root+12u)++tones;
    unsigned budget=1+3u*e->config.variation/127,changed=0,used=0;
    for(unsigned k=0;k<budget && k+1<p.count;k++){
        unsigned candidates[16],count=0;
        for(unsigned i=1;i<p.count;i++)if(!(used&(1u<<i)))candidates[count++]=i;
        unsigned i=candidates[next(&rng)%count];used|=1u<<i;
        melody_event *v=&p.event[i];unsigned kind=next(&rng)%3;
        if(kind==0){
            unsigned degree=choose(&e->config,p.event[i-1].degree,1,(unsigned)n,tones,i+1==p.count,&rng);
            if(degree==(unsigned)v->degree && n>1)degree=((unsigned)v->degree+1u)%(unsigned)n;
            if(degree!=(unsigned)v->degree){v->degree=(int16_t)degree;v->note=pool[degree];changed++;}
        }else if(kind==1){
            unsigned gap=(i+1<p.count?p.event[i+1].step:16)-v->step;
            unsigned duration=e->config.rhythm>=32 && v->span==1 && gap>=2?2:1;
            if(v->span!=duration){v->span=(uint8_t)duration;changed++;}
        }else{
            v->velocity=v->velocity<100?108:84;changed++;
        }
    }
    e->mutation_state=rng;
    if(changed){e->previous=e->phrase;e->previous_config=e->config;e->undo_valid=1;e->phrase=p;}
    return (int)changed;
}
int melody_repeat(melody_engine *e){
    if(!e)return -1;
    if(e->frozen || !e->config.variation)return 0;
    if(++e->repetitions<e->config.repeat)return 0;
    e->repetitions=0;return melody_evolve(e);
}
void melody_freeze(melody_engine *e,int frozen){if(e)e->frozen=(uint8_t)(frozen!=0);}
int melody_undo(melody_engine *e){
    if(!e || !e->undo_valid)return -1;
    e->phrase=e->previous;e->config=e->previous_config;e->undo_valid=0;e->repetitions=0;return 0;
}
int melody_transpose(const melody_phrase *src,int semitones,melody_phrase *dst){
    if(!dst || !melody_phrase_valid(src) || semitones < -127 || semitones>127)return -1;
    melody_phrase p=*src;
    for(unsigned i=0;i<p.count;i++){
        int note=(int)p.event[i].note+semitones;if(note<0 || note>127)return -1;
        p.event[i].note=(uint8_t)note;
    }
    *dst=p;return 0;
}
int melody_root(melody_engine *e,unsigned root){
    if(!e || root>127)return -1;
    melody_config c=e->config;melody_phrase p,previous;uint8_t pool[MELODY_POOL];
    int delta=(int)root-c.root;c.root=(uint8_t)root;
    if(c.source==MELODY_ARP)for(unsigned i=0;i<c.arp_count;i++){
        int note=c.arp[i]+delta;if(note<0 || note>127)return -1;c.arp[i]=(uint8_t)note;
    }
    if(melody_pool(&c,pool)<0 || melody_transpose(&e->phrase,delta,&p) ||
       (e->undo_valid && melody_transpose(&e->previous,delta,&previous)))return -1;
    if(c.ceiling){
        for(unsigned i=0;i<p.count;i++)if(p.event[i].note>c.ceiling)return -1;
        if(e->undo_valid)for(unsigned i=0;i<previous.count;i++)if(previous.event[i].note>c.ceiling)return -1;
    }
    e->config=c;e->phrase=p;if(e->undo_valid){e->previous=previous;e->previous_config.root=(uint8_t)root;
        if(c.source==MELODY_ARP)for(unsigned i=0;i<c.arp_count;i++)e->previous_config.arp[i]=c.arp[i];}return 0;
}

/* Nested attack sets ensure turning NOTES up/down preserves existing pitches.
 * A fixed hash per grid position makes MOTION reversible on an unchanged NEW. */
static unsigned priority(unsigned step){
    unsigned v=0;for(unsigned i=0;i<4;i++){v=(v<<1)|(step&1u);step>>=1;}return v;
}
int melody_edit(melody_engine *e,unsigned notes,unsigned motion,unsigned range){
    if(!e || notes>16 || motion>127 || range<1 || range>MELODY_OCTAVES)return -1;
    melody_config c=e->config;c.motion=(uint8_t)motion;c.range=(uint8_t)range;
    c.density=(uint8_t)((notes*127u+8)/16);
    uint8_t pool[MELODY_POOL],old_pool[MELODY_POOL];
    int n=melody_pool(&c,pool),old_n=melody_pool(&e->config,old_pool);
    if(n<0 || old_n<0)return -1;
    melody_phrase p={0};p.length=16;
    unsigned previous=0;
    for(unsigned step=0;step<16;step++){
        uint32_t rng=e->new_state^(0x9e3779b9u*(step+1u));
        unsigned radius=1+(unsigned)(n-1)*motion/127u;
        int degree=(int)previous+(int)(next(&rng)%(2*radius+1))-(int)radius;
        if(degree<0)degree=-degree;
        if(degree>=n)degree=2*(n-1)-degree;
        if(degree<0)degree=0;
        if(!step)degree=0;
        previous=(unsigned)degree;
        if(priority(step)>=notes)continue;
        melody_event v={(uint8_t)step,1,pool[degree],(uint8_t)(step%4?88:104),(int16_t)degree,0,0};
        if(motion==e->config.motion){
            for(unsigned i=0;i<e->phrase.count;i++)if(e->phrase.event[i].step==step){
                v=e->phrase.event[i];
                unsigned d=(unsigned)v.degree;
                if(range!=e->config.range)d=old_n>1?(d*(unsigned)(n-1)+(unsigned)(old_n-1)/2)/(unsigned)(old_n-1):0;
                v.degree=(int16_t)d;v.note=pool[d];v.span=1;break;
            }
        }
        p.event[p.count++]=v;
    }
    if(!melody_phrase_valid(&p))return -1;
    e->previous=e->phrase;e->previous_config=e->config;e->undo_valid=1;
    e->config=c;e->phrase=p;return 0;
}
int melody_vary(melody_engine *e){
    if(!e || e->phrase.count<2)return 0;
    uint8_t pool[MELODY_POOL];int n=melody_pool(&e->config,pool);if(n<0)return -1;
    if(n<2)return 0;
    melody_phrase p=e->phrase;uint32_t rng=e->mutation_state;
    unsigned used=0,budget=p.count>2?2:1;
    for(unsigned k=0;k<budget;k++){
        unsigned candidates[16],count=0;
        for(unsigned i=1;i<p.count;i++)if(!(used&(1u<<i)))candidates[count++]=i;
        unsigned at=candidates[next(&rng)%count];used|=1u<<at;
        unsigned d=((unsigned)p.event[at].degree+1+next(&rng)%(unsigned)(n-1))%(unsigned)n;
        p.event[at].degree=(int16_t)d;p.event[at].note=pool[d];
    }
    e->previous=e->phrase;e->previous_config=e->config;e->undo_valid=1;
    e->phrase=p;e->mutation_state=rng;return (int)budget;
}
int melody_rhythm(melody_engine *e,unsigned amount,int vary){
    if(!e || amount>127 || !melody_phrase_valid(&e->phrase))return -1;
    uint8_t pool[MELODY_POOL];int n=melody_pool(&e->config,pool);if(n<0)return -1;
    uint32_t state=e->mutation_state;
    uint32_t rng=(vary?next(&state):e->new_state)^0x7f4a7c15u^(amount*0x9e3779b9u);
    unsigned count=amount==127?16:amount?1+(amount-1)*15/126:0;
    uint8_t positions[16];unsigned mask=0;
    /* Weighted draws keep the established variety while favouring quarters
     * and eighths over isolated sixteenth placements. */
    for(unsigned i=0;i<count;i++){
        unsigned total=0;
        for(unsigned step=0;step<16;step++)if(!(mask&(1u<<step)))total+=step%4?step%2?1u:3u:5u;
        unsigned pick=next(&rng)%total;
        for(unsigned step=0;step<16;step++)if(!(mask&(1u<<step))){
            unsigned weight=step%4?step%2?1u:3u:5u;
            if(pick<weight){mask|=1u<<step;break;}pick-=weight;
        }
    }
    /* A repeated intermediate mask always moves. Rotating a nonconstant
     * 16-bit mask one place cannot preserve it. Both endpoints are fixed. */
    unsigned oldmask=0;
    for(unsigned i=0;i<e->phrase.count;i++)oldmask|=1u<<e->phrase.event[i].step;
    if(count && count<16 && mask==oldmask)mask=((mask<<1)|(mask>>15))&65535u;
    unsigned at=0;for(unsigned i=0;i<16;i++)if(mask&(1u<<i))positions[at++]=(uint8_t)i;
    melody_phrase p={0};p.length=16;p.count=(uint8_t)count;
    for(unsigned i=0;i<count;i++){
        unsigned degree=e->phrase.count?(unsigned)e->phrase.event[i%e->phrase.count].degree:0;
        if(degree>=(unsigned)n)degree=(unsigned)n-1;
        unsigned gap=(i+1<count?positions[i+1]:16)-positions[i];
        unsigned duration=span(gap,64+8*(amount%8),&rng);
        p.event[i]=(melody_event){positions[i],(uint8_t)duration,pool[degree],
            (uint8_t)(positions[i]%4?88:104),(int16_t)degree,0,0};
    }
    if(!melody_phrase_valid(&p))return -1;
    e->previous=e->phrase;e->previous_config=e->config;e->undo_valid=1;
    e->config.rhythm=(uint8_t)amount;e->phrase=p;
    if(vary)e->mutation_state=state;
    return 0;
}
static unsigned colour(unsigned pc){
    return pc==1 || pc==6 || pc==11?3:pc==2 || pc==5 || pc==10?2:1;
}
static unsigned structural_mask(const melody_config *c,const uint8_t *pool,unsigned n){
    unsigned classes=0;
    for(unsigned i=0;i<(unsigned)n;i++)classes|=1u<<((pool[i]+120u-c->root)%12);
    unsigned root_pc=(pool[0]+120u-c->root)%12;
    unsigned third=classes&(1u<<4)?4:classes&(1u<<3)?3:classes&(1u<<2)?2:classes&(1u<<5)?5:root_pc;
    unsigned fifth=classes&(1u<<7)?7:third==3 && (classes&(1u<<6))?6:classes&(1u<<8)?8:classes&(1u<<6)?6:root_pc;
    return (1u<<root_pc)|(1u<<third)|(1u<<fifth);
}
int melody_anchor_pool(const melody_config *c,uint8_t degrees[MELODY_POOL]){
    uint8_t pool[MELODY_POOL];
    int n=melody_pool(c,pool);
    return melody_anchor_degrees(c,pool,n,degrees);
}
int melody_anchor_degrees(const melody_config *c,const uint8_t *pool,int n,uint8_t *degrees){
    if(!degrees || n<1)return -1;
    unsigned mask=c->source==MELODY_ARP?4095u:structural_mask(c,pool,(unsigned)n),count=0;
    for(unsigned i=0;i<(unsigned)n;i++)if(mask&(1u<<((pool[i]+120u-c->root)%12)))degrees[count++]=(uint8_t)i;
    return (int)count;
}
static int apply_tension(melody_engine *e,unsigned profile,int vary,int keep_contour){
    if(!e || profile>MELODY_TENSION_HARD || !melody_phrase_valid(&e->phrase))return -1;
    melody_config c=e->config;c.tension=(uint8_t)profile;
    uint8_t pool[MELODY_POOL];int n=melody_pool(&c,pool);if(n<0)return -1;
    uint32_t state=e->mutation_state;
    uint32_t rng=(vary?next(&state):e->new_state)^0x85ebca6bu;
    unsigned structural=keep_contour && c.source==MELODY_ARP?4095u:structural_mask(&c,pool,(unsigned)n);
    uint8_t consonant[MELODY_POOL];
    for(unsigned i=0;i<(unsigned)n;i++)consonant[i]=(structural>>((pool[i]+120u-c.root)%12))&1u;
    melody_phrase p=e->phrase;unsigned previous=0;
    /* Common deterministic stable contour for all four profiles, so changing
     * D adds/removes colour rather than reseeding the whole melody. */
    for(unsigned i=0;i<p.count;i++){
        unsigned radius=1+(unsigned)(n-1)*c.motion/127u;
        int target=(int)previous+(int)(next(&rng)%(2*radius+1))-(int)radius;
        if(target<0)target=-target;
        if(target>=n)target=2*(n-1)-target;
        if(target<0)target=0;
        if(keep_contour){
            target=0;unsigned nearest=~0u;
            for(unsigned j=0;j<(unsigned)n;j++){unsigned d=distance(pool[j],p.event[i].note);if(d<nearest){nearest=d;target=(int)j;}}
        }
        unsigned degree=0,best=~0u;
        for(unsigned j=0;j<(unsigned)n;j++)if(consonant[j]){
            unsigned d=distance(j,(unsigned)target);
            if(d<best){best=d;degree=j;}
        }
        if(!i && !keep_contour)degree=0;
        p.event[i].degree=(int16_t)degree;p.event[i].note=pool[degree];previous=degree;
    }
    /* Alternating eligible events reserve the next attack for a resolution.
     * Prefer a parity that can put HARD tension on an accented grid step. */
    unsigned parity=1,best_accent=0;
    for(unsigned odd=0;odd<2;odd++){
        unsigned accents=0;
        for(unsigned i=1;i+1<p.count;i++)if((i&1u)==odd && !(p.event[i].step%4))++accents;
        if(accents>best_accent){best_accent=accents;parity=odd;}
    }
    if(keep_contour && profile>MELODY_TENSION_OFF && profile<MELODY_TENSION_HARD){
        unsigned most_weak=0;
        for(unsigned odd=0;odd<2;odd++){
            unsigned weak_slots=0;
            for(unsigned i=1;i+1<p.count;i++)if((i&1u)==odd && p.event[i].step%4)++weak_slots;
            if(weak_slots>most_weak){most_weak=weak_slots;parity=odd;}
        }
    }
    unsigned order[16],slots=0,weak=0;int rank[16];
    for(unsigned pass=0;pass<2;pass++)for(unsigned i=1;i+1<p.count;i++)if((i&1u)==parity){
        unsigned accented=!(p.event[i].step%4);
        if(accented!=pass)continue;
        /* Only tones that can resolve by 1 or 2 semitones are eligible. */
        unsigned eligible=0;
        for(unsigned j=0;j<(unsigned)n;j++)if(!consonant[j] && distance(pool[j],p.event[i+1].note)<=2)eligible=1;
        if(!eligible)continue;
        int priority=(int)(next(&rng)&65535u);
        unsigned at=slots++;
        while(at && rank[at-1]>priority && (p.event[order[at-1]].step%4!=0)==!accented){
            order[at]=order[at-1];rank[at]=rank[at-1];--at;
        }
        order[at]=i;rank[at]=priority;if(!accented)++weak;
    }
    unsigned soft=p.count>8?2:1;if(soft>weak)soft=weak;
    unsigned mid=(p.count+2u)/4;if(mid<=soft)mid=soft+1;if(mid>slots)mid=slots;
    unsigned budget=profile==MELODY_TENSION_OFF?0:profile==MELODY_TENSION_SOFT?soft:profile==MELODY_TENSION_MID?mid:slots;
    for(unsigned k=0;k<budget;k++){
        unsigned at=order[k],degree=0;int best=-100000;
        for(unsigned j=0;j<(unsigned)n;j++)if(!consonant[j]){
            unsigned d=distance(pool[j],p.event[at+1].note);if(d>2)continue;
            unsigned pc=(pool[j]+120u-c.root)%12,tension=colour(pc);
            int between=(pool[j]>=p.event[at-1].note && pool[j]<=p.event[at+1].note) ||
                (pool[j]<=p.event[at-1].note && pool[j]>=p.event[at+1].note);
            int score=1000-(int)d*30+between*20;
            if(profile==MELODY_TENSION_SOFT)score-=(int)tension*80;
            else if(profile==MELODY_TENSION_HARD)score+=(int)tension*200;
            else if(pc==2 || pc==5 || pc==9 || pc==10 || pc==11)score+=60;
            if(score>best){best=score;degree=j;}
        }
        p.event[at].degree=(int16_t)degree;p.event[at].note=pool[degree];
    }
    if(!melody_phrase_valid(&p))return -1;
    e->previous=e->phrase;e->previous_config=e->config;e->undo_valid=1;
    e->phrase=p;e->config=c;if(vary)e->mutation_state=state;
    return 0;
}
int melody_tension(melody_engine *e,unsigned profile,int vary){return apply_tension(e,profile,vary,0);}
int melody_tension_contour(melody_engine *e,unsigned profile,int vary){return apply_tension(e,profile,vary,1);}
int melody_step_edit(melody_phrase *phrase,unsigned step,unsigned parameter,int delta){
    if(!melody_phrase_valid(phrase) || step>=16 || parameter>3 || delta< -127 || delta>127)return -1;
    melody_phrase p=*phrase;unsigned at=0;
    while(at<p.count && p.event[at].step<step)++at;
    unsigned exists=at<p.count && p.event[at].step==step;
    if(parameter==MELODY_EDIT_ACTIVE){
        if(delta>0 && !exists){
            if(p.count>=16)return -1;
            if(at && p.event[at-1].step+p.event[at-1].span>step)
                p.event[at-1].span=(uint8_t)(step-p.event[at-1].step);
            for(unsigned i=p.count;i>at;i--)p.event[i]=p.event[i-1];
            unsigned note=at?p.event[at-1].note:60;
            p.event[at]=(melody_event){(uint8_t)step,1,(uint8_t)note,100,0,0,0};++p.count;
        }else if(delta<0 && exists){
            for(unsigned i=at;i+1<p.count;i++)p.event[i]=p.event[i+1];
            --p.count;p.event[p.count]=(melody_event){0};
        }
    }else if(exists){
        melody_event *v=&p.event[at];int value;
        if(parameter==MELODY_EDIT_NOTE){
            value=(int)v->note+delta;if(value<36)value=36;if(value>84)value=84;v->note=(uint8_t)value;
        }else if(parameter==MELODY_EDIT_SPAN){
            unsigned gap=(at+1<p.count?p.event[at+1].step:16)-step;
            value=(int)v->span+delta;if(value<1)value=1;if(value>(int)gap)value=(int)gap;v->span=(uint8_t)value;
        }else{
            value=(int)v->velocity+delta;if(value<1)value=1;if(value>127)value=127;v->velocity=(uint8_t)value;
        }
    }
    if(!melody_phrase_valid(&p))return -1;
    *phrase=p;return 0;
}
