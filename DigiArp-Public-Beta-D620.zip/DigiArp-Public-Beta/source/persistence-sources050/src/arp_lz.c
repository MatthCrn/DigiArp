/* SPDX-License-Identifier: MIT */
/* Task-only bounded 1KiB-window LZSS. No pointers or ABI-dependent fields
 * on disk. Caller owns input/output/dictionary; all overflow paths refuse. */
#include "arp_lz.h"
static unsigned hash(const uint8_t *p){return (251u*p[0]+31u*p[1]+p[2])&1023u;}
int arp_lz_pack(const uint8_t *in,unsigned n,uint8_t *out,unsigned cap,uint32_t dict[1024]){
 if(!in || !out || !dict || !n)return -1;
 for(unsigned i=0;i<1024;i++)dict[i]=0xffffffffu;
 unsigned at=0,used=0;
 while(at<n){
  if(used>=cap)return -1;
  unsigned flag_at=used++;out[flag_at]=0;
  for(unsigned bit=0;bit<8 && at<n;bit++){
   unsigned length=0,back=0;
   if(n-at>=3){unsigned h=hash(in+at),previous=dict[h];
    if(previous<at && at-previous<=1024){while(length<66 && length<n-at && in[previous+length]==in[at+length])++length;back=at-previous;}
   }
   if(length>=3){
    if(cap-used<2)return -1;
    unsigned token=((back-1)<<6)|(length-3);out[flag_at]|=(uint8_t)(1u<<bit);out[used++]=(uint8_t)(token>>8);out[used++]=(uint8_t)token;
   }else{length=1;if(used>=cap)return -1;out[used++]=in[at];}
   for(unsigned i=0;i<length;i++)if(n-(at+i)>=3)dict[hash(in+at+i)]=at+i;
   at+=length;
  }
 }
 return (int)used;
}
int arp_lz_unpack(const uint8_t *in,unsigned n,uint8_t *out,unsigned want){
 if(!in || !out || !n || !want)return -1;
 unsigned at=0,used=0;
 while(used<want){
  if(at>=n)return -1;
  unsigned flags=in[at++];
  for(unsigned bit=0;bit<8 && used<want;bit++){
   if(flags&(1u<<bit)){
    if(n-at<2)return -1;
    unsigned token=256u*in[at]+in[at+1];at+=2;
    unsigned back=1+(token>>6),length=3+(token&63u);
    if(back>used || length>want-used)return -1;
    for(unsigned j=0;j<length;j++){out[used]=out[used-back];++used;}
   }else{if(at>=n)return -1;out[used++]=in[at++];}
  }
 }
 return at==n?(int)used:-1;
}
