/* SPDX-License-Identifier: MIT */
#include "melody_player.h"
static int due(uint32_t now,uint32_t date){return now-date<0x80000000u;}
static int earlier(uint32_t a,uint32_t b){return a-b>0x7fffffffu;}
static int send(melody_player *p,unsigned kind,unsigned note,unsigned velocity,uint32_t tick){
    melody_note e={tick,(uint8_t)kind,(uint8_t)note,(uint8_t)velocity,0};
    if(p->emit(p->context,&e)){p->running=0;return -1;}return 0;
}
int melody_player_stop(melody_player *p,uint32_t tick){
    if(!p)return -1;
    p->running=0;p->queued=0;
    if(p->sounding){if(send(p,MELODY_OFF,p->note,0,tick))return -1;p->sounding=0;}
    return 0;
}
static int at_step(const melody_phrase *p,unsigned step){
    for(unsigned i=0;i<p->count;i++)if(p->event[i].step==step)return (int)i;
    return -1;
}
static uint32_t probability_seed(uint32_t seed){return seed^0x85ebca6bu;}
static int accept(unsigned probability,uint32_t *state){
    if(probability>=100)return 1;
    uint32_t x=*state?*state:0x85ebca6bu;
    x^=x<<13;x^=x>>17;x^=x<<5;*state=x;return x%100u<probability;
}
static uint32_t gate_length(unsigned span,uint32_t step){
    return span>0x7fffffffu/step?0x7fffffffu:step*span;
}
/* Prepared forward phrases are validated, ordered and non-overlapping.
 * The first visit cannot interrupt another attack within its span. */
int melody_first_forward(const melody_phrase *phrase,uint32_t step,unsigned seed,
                         unsigned probability,unsigned rise,unsigned ceiling,melody_note *note){
    uint32_t state=probability_seed(seed);
    if(!phrase->count || phrase->event[0].step || !accept(probability,&state))return 0;
    const melody_event *first=&phrase->event[0];
    *note=(melody_note){gate_length(first->span,step),MELODY_ON,
          melody_rise_note(first->note,0,rise,seed,ceiling),first->velocity,0};
    return 1;
}
int melody_player_advance(melody_player *p,uint32_t tick){
    if(!p || !p->emit)return -1;
    if(!p->running)return 0;
    uint32_t elapsed=tick-p->now;
    unsigned visit=p->visit<p->length?p->visit:p->length;
    uint32_t until_visit=p->loop_start+p->step_ticks*visit-p->now;
    if(elapsed<0x80000000u && until_visit<0x80000000u && elapsed<until_visit &&
       (!p->sounding || (p->off_at-p->now<0x80000000u && elapsed<p->off_at-p->now))){
        p->now=tick;return 0;
    }
    uint32_t period=p->step_ticks>0x7fffffffu/p->length?0x7fffffffu:p->step_ticks*p->length;
    if(elapsed>=0x80000000u || elapsed>period){(void)melody_player_stop(p,tick);return -2;}
    for(unsigned work=0;work<64;work++){
        uint32_t at=p->loop_start+p->step_ticks*p->length;unsigned action=2;
        if(p->visit<p->length){at=p->loop_start+p->step_ticks*p->visit;action=1;}
        if(p->sounding && (p->off_at==at || earlier(p->off_at,at))){at=p->off_at;action=0;}
        if(!due(tick,at)){p->now=tick;return 0;}
        if(action==0){
            if(send(p,MELODY_OFF,p->note,0,at))return -1;
            p->sounding=0;
        }else if(action==1){
            p->position=p->path[p->visit];int index=at_step(&p->phrase,p->position);
            if(index>=0 && accept(p->probability,&p->probability_state)){
                const melody_event *v=&p->phrase.event[index];
                unsigned span=v->span;
                /* A monophonic head can interrupt a long note by visiting
                 * another attack early; the stored duration stays untouched. */
                for(unsigned j=1;p->mode!=MELODY_FWD && j<span && p->visit+j<p->length;j++)if(at_step(&p->phrase,p->path[p->visit+j])>=0){span=j;break;}
                if(p->sounding){
                    if(send(p,MELODY_OFF,p->note,0,at))return -1;
                    p->sounding=0;
                }
                p->index=(uint8_t)index;p->note_span=(uint8_t)span;p->gate_ticks=gate_length(span,p->step_ticks);
                unsigned played=melody_rise_note(v->note,p->position,p->rise,p->seed,p->rise_ceiling);
                p->base_note=v->note;
                if(send(p,MELODY_ON,played,v->velocity,at))return -1;
                p->note=(uint8_t)played;p->sounding=1;p->off_at=at+p->gate_ticks;
            }
            ++p->visit;
        }else{
            p->loops++;p->loop_start=at;p->visit=0;
            if(p->queued){p->phrase=p->pending;p->queued=0;}
            if(p->mode_queued){p->mode=p->pending_mode;p->length=p->pending_length;p->step_ticks=p->pending_step_ticks;p->mode_queued=0;}
            if(melody_head_path(&p->phrase,p->mode,p->length,&p->head,p->seed,p->path)){(void)melody_player_stop(p,tick);return -1;}
        }
    }
    (void)melody_player_stop(p,tick);return -2;
}
int melody_player_start_config_rise(melody_player *p,const melody_phrase *phrase,uint32_t tick,uint32_t step_ticks,unsigned mode,unsigned length,uint32_t seed,unsigned probability,unsigned rise,unsigned ceiling,melody_emit emit,void *ctx){
    if(!p || !melody_phrase_valid(phrase) || !emit || !step_ticks || mode>=MELODY_ORDERS || probability>100 || rise>127 || ceiling>127 || !length || length>16 || step_ticks>0x7fffffffu)return -1;
    if(p->running || p->sounding)return -1;
    melody_player next={0};next.phrase=*phrase;next.now=next.loop_start=tick;
    next.step_ticks=step_ticks;next.emit=emit;next.context=ctx;next.running=1;next.mode=(uint8_t)mode;next.length=(uint8_t)length;next.seed=seed;next.probability=(uint8_t)probability;next.probability_state=probability_seed(seed);next.rise=(uint8_t)rise;next.rise_ceiling=(uint8_t)ceiling;
    if(melody_head_path(phrase,mode,length,&next.head,seed,next.path))return -1;
    *p=next;return melody_player_advance(p,tick);
}
int melody_player_start_config(melody_player *p,const melody_phrase *phrase,uint32_t tick,uint32_t step_ticks,unsigned mode,unsigned length,uint32_t seed,unsigned probability,melody_emit emit,void *ctx){
    return melody_player_start_config_rise(p,phrase,tick,step_ticks,mode,length,seed,probability,0,127,emit,ctx);
}
int melody_player_start_mode(melody_player *p,const melody_phrase *phrase,uint32_t tick,uint32_t step_ticks,unsigned mode,unsigned length,uint32_t seed,melody_emit emit,void *ctx){
    return melody_player_start_config(p,phrase,tick,step_ticks,mode,length,seed,100,emit,ctx);
}
int melody_player_start(melody_player *p,const melody_phrase *phrase,uint32_t tick,uint32_t step_ticks,melody_emit emit,void *ctx){
    return melody_player_start_mode(p,phrase,tick,step_ticks,MELODY_FWD,16,8107,emit,ctx);
}
int melody_player_queue(melody_player *p,const melody_phrase *phrase){
    if(!p || !p->running || !melody_phrase_valid(phrase))return -1;
    p->pending=*phrase;p->queued=1;return 0;
}
int melody_player_rewind(melody_player *p,uint32_t tick){
    if(!p || !p->running || tick-p->now>=0x80000000u)return -1;
    p->now=p->loop_start=tick;p->visit=0;p->loops++;
    if(p->queued){p->phrase=p->pending;p->queued=0;}
    if(p->mode_queued){p->mode=p->pending_mode;p->length=p->pending_length;p->step_ticks=p->pending_step_ticks;p->mode_queued=0;}
    if(melody_head_path(&p->phrase,p->mode,p->length,&p->head,p->seed,p->path))return -1;
    return melody_player_advance(p,tick);
}
int melody_player_queue_mode(melody_player *p,const melody_phrase *phrase,uint32_t step_ticks,unsigned mode,unsigned length){
    if(!p || !p->running || !melody_phrase_valid(phrase) || !step_ticks || step_ticks>0x7fffffffu || mode>=MELODY_ORDERS || !length || length>16)return -1;
    p->pending=*phrase;p->queued=1;p->pending_mode=(uint8_t)mode;p->pending_length=(uint8_t)length;p->pending_step_ticks=step_ticks;p->mode_queued=1;return 0;
}
int melody_player_transpose(melody_player *p,int semitones){
    if(!p || !p->running)return -1;
    melody_phrase phrase,pending;
    if(melody_transpose(&p->phrase,semitones,&phrase) ||
       (p->queued && melody_transpose(&p->pending,semitones,&pending)))return -1;
    p->phrase=phrase;if(p->queued)p->pending=pending;return 0;
}

unsigned melody_player_position(const melody_player *p){return p && p->running?p->position:16u;}
uint32_t melody_player_gate(const melody_player *p){return p?p->gate_ticks:0u;}
