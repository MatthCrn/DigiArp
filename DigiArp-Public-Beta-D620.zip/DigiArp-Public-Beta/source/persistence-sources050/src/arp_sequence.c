/* SPDX-License-Identifier: MIT */
#include "arp_sequence.h"
#include "arp_scale.h"
#include <string.h>
static uint32_t random_next(arp_sequence *s){
    uint32_t x=s->random_state;x^=x<<13;x^=x>>17;x^=x<<5;
    s->random_state=x;return x;
}
static void pick(arp_sequence *s){
    unsigned total=s->count*s->config.range,k;
    if(s->config.mode==ARP_SEQ_SHUFFLE){
        if(s->bag_position==s->bag_count){
            for(unsigned i=0;i<total;i++)s->bag[i]=(uint8_t)i;
            for(unsigned i=total-1;i>0;i--){
                unsigned j=random_next(s)%(i+1);uint8_t t=s->bag[i];s->bag[i]=s->bag[j];s->bag[j]=t;
            }
            s->bag_position=0;s->bag_count=(uint8_t)total;
        }
        k=s->bag[s->bag_position++];
    }else k=random_next(s)%total;
    s->index=(uint8_t)(k%s->count);s->octave=(uint8_t)(k/s->count);
}
int arp_sequence_init(arp_sequence *s,const arp_sequence_config *cfg,
                      const uint8_t *notes,unsigned count){
    if(!s || !cfg || !notes || !count || count>ARP_SEQUENCE_NOTES ||
       cfg->mode<ARP_SEQ_TRUE || cfg->mode>ARP_SEQ_SHUFFLE ||
       cfg->probability_on>1 || (cfg->probability_on && cfg->probability>100) ||
       cfg->key>12 || (cfg->key && cfg->scale>=23) ||
       !cfg->range || cfg->range>8 || !cfg->length || cfg->length>16)return -1;
    for(unsigned i=0;i<16;i++)if(cfg->offset[i]<-64 || cfg->offset[i]>63 || cfg->span[i]>16 || cfg->velocity[i]>127)return -1;
    for(unsigned i=0;i<count;i++){
        if(notes[i]>127)return -1;
        for(unsigned j=0;j<i;j++)if(notes[i]==notes[j])return -1;
    }
    arp_sequence next;
    memset(&next,0,sizeof next);next.config=*cfg;next.count=(uint8_t)count;
    memcpy(next.notes,notes,count);
    if(cfg->mode!=ARP_SEQ_TRUE){
        for(unsigned i=1;i<count;i++){
            uint8_t note=next.notes[i];unsigned j=i;
            while(j && next.notes[j-1]>note){next.notes[j]=next.notes[j-1];--j;}
            next.notes[j]=note;
        }
    }
    if(cfg->mode==ARP_SEQ_DOWN)next.index=(uint8_t)(count-1);
    next.random_state=0x6d2b79f5u;
    for(unsigned i=0;i<count;i++)next.random_state=next.random_state*33u+next.notes[i];
    if(!next.random_state)next.random_state=1;
    next.probability_state=cfg->probability_seed?cfg->probability_seed:next.random_state^0xa511e9b3u;
    if(!next.probability_state)next.probability_state=1;
    if(cfg->mode>=ARP_SEQ_RANDOM)pick(&next);
    *s=next;return 0;
}
static void octave(arp_sequence *s){
    if(++s->octave==s->config.range)s->octave=0;
}
int arp_sequence_next(arp_sequence *s,arp_sequence_result *result){
    if(!s || !result || !s->count)return -1;
    arp_sequence_result r;
    r.position=s->position;r.octave=s->octave;
    r.pitch=(int16_t)((int)s->notes[s->index]+12*s->octave+s->config.offset[s->position]);
    if(s->config.key)r.pitch=(int16_t)arp_scale_shift((int)s->notes[s->index]+12*s->octave,s->config.offset[s->position],s->config.key-1,s->config.scale);
    r.kind=!(s->config.active&(1u<<s->position))?ARP_SEQ_REST:
        r.pitch<0 || r.pitch>127?ARP_SEQ_OUT_OF_RANGE:ARP_SEQ_NOTE;
    if(++s->position==s->config.length)s->position=0;
    /* Stock 1.44: skipped motif positions do not consume a chord note. */
    if(r.kind==ARP_SEQ_REST){*result=r;return 0;}
    if(s->config.mode>=ARP_SEQ_RANDOM){pick(s);}
    else if(s->config.mode==ARP_SEQ_DOWN){
        if(s->index)--s->index;else{s->index=(uint8_t)(s->count-1);octave(s);}
    }else if(s->config.mode==ARP_SEQ_CYCL && s->count>1){
        if(s->descending){
            if(s->index)--s->index;
            else{s->descending=0;s->index=1;octave(s);}
        }else{
            if(s->index+1u<s->count)++s->index;
            else{s->descending=1;--s->index;}
        }
    }else{
        if(++s->index==s->count){s->index=0;octave(s);}
    }
    /* Gate only after musical traversal advances: a rejected candidate is
     * timed silence, not a repeat of the same note. Keep independent RNG so
     * changing probability never changes RANDOM/SHUFFLE pitch choices. */
    if(r.kind==ARP_SEQ_NOTE && s->config.probability_on){
        uint32_t x=s->probability_state;x^=x<<13;x^=x>>17;x^=x<<5;s->probability_state=x;
        if(x%100u>=s->config.probability)r.kind=ARP_SEQ_REST;
    }
    *result=r;return 0;
}
