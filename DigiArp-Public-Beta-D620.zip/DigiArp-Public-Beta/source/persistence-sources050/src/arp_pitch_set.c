/* SPDX-License-Identifier: MIT */
#include "arp_pitch_set.h"
typedef struct {const char *name;uint8_t count,notes[12];} pitch_set;
static const pitch_set sets[ARP_PITCH_SETS]={
 {"MAJOR",7,{0,2,4,5,7,9,11}}, {"NAT MIN",7,{0,2,3,5,7,8,10}},
 {"HARM MIN",7,{0,2,3,5,7,8,11}}, {"MEL MIN",7,{0,2,3,5,7,9,11}},
 {"DORIAN",7,{0,2,3,5,7,9,10}}, {"PHRYG",7,{0,1,3,5,7,8,10}},
 {"LYDIAN",7,{0,2,4,6,7,9,11}}, {"MIXOLYD",7,{0,2,4,5,7,9,10}},
 {"LOCRIAN",7,{0,1,3,5,6,8,10}}, {"MAJ PENT",5,{0,2,4,7,9}},
 {"MIN PENT",5,{0,3,5,7,10}}, {"BLUES",6,{0,3,5,6,7,10}},
 {"WHOLE",6,{0,2,4,6,8,10}}, {"CHROM",12,{0,1,2,3,4,5,6,7,8,9,10,11}},
 {"MAJ TRI",3,{0,4,7}}, {"MIN TRI",3,{0,3,7}}, {"DOM 7",4,{0,4,7,10}},
 {"MIN 7",4,{0,3,7,10}}, {"MAJ 7",4,{0,4,7,11}},
 {"SUS 2",3,{0,2,7}}, {"SUS 4",3,{0,5,7}},
 {"DIM TRI",3,{0,3,6}}, {"AUG TRI",3,{0,4,8}}
};
int arp_pitch_set(unsigned set,unsigned count,int8_t out[16]){
 if(set>=ARP_PITCH_SETS || !count || count>16 || !out)return -1;
 const pitch_set *s=&sets[set];
 for(unsigned i=0;i<count;i++)out[i]=(int8_t)(12*(i/s->count)+s->notes[i%s->count]);
 return (int)count;
}
const char *arp_pitch_set_name(unsigned set){return set<ARP_PITCH_SETS?sets[set].name:"INVALID";}
