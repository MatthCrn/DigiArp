/* SPDX-License-Identifier: MIT */
#include "arp_keyboard.h"
int arp_keyboard_pitch(unsigned key,unsigned octave){
 static const int8_t offsets[16]={-1,1,3,-1,6,8,10,-1,0,2,4,5,7,9,11,12};
 if(!key || key>16 || octave>10 || offsets[key-1]<0)return -1;
 unsigned pitch=12*octave+(unsigned)offsets[key-1];return pitch<=127?(int)pitch:-1;
}
static int valid(const arp_manual_notes *n){
 if(!n || n->count>16 || n->octave>10)return 0;
 for(unsigned i=0;i<n->count;i++){
  if(n->notes[i]>127)return 0;
  for(unsigned j=0;j<i;j++)if(n->notes[i]==n->notes[j])return 0;
 }
 return 1;
}
int arp_manual_toggle(arp_manual_notes *n,unsigned pitch){
 if(pitch>127 || !valid(n))return 0;
 unsigned i=0;while(i<n->count && n->notes[i]!=pitch)++i;
 if(i<n->count){for(unsigned j=i;j+1<n->count;j++)n->notes[j]=n->notes[j+1];--n->count;return 1;}
 if(n->count==16)return -1;
 n->notes[n->count++]=(uint8_t)pitch;return 1;
}
int arp_manual_copy(const arp_manual_notes *n,uint8_t out[16]){
 if(!out || !valid(n))return -1;
 for(unsigned i=0;i<n->count;i++)out[i]=n->notes[i];
 return n->count;
}
