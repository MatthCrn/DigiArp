/* SPDX-License-Identifier: MIT */
#ifndef DIGIARP_SCALE_H
#define DIGIARP_SCALE_H
#include <stdint.h>
/* Same 23 pitch-class sets and ordering as arp_pitch_set.c. */
static inline unsigned arp_scale_mask(unsigned set){
 static const uint16_t masks[23]={0xab5,0x5ad,0x9ad,0xaad,0x6ad,0x5ab,0xad5,0x6b5,0x56b,0x295,0x4a9,0x4e9,0x555,0xfff,0x91,0x89,0x491,0x489,0x891,0x85,0xa1,0x49,0x111};
 return set<23?masks[set]:0;
}
static inline int arp_scale_contains(int note,unsigned key,unsigned set){
 int pc=(note-(int)key)%12;if(pc<0)pc+=12;
 return (arp_scale_mask(set)>>pc)&1;
}
/* Closest legal MIDI pitch, lower on ties; bounded search. */
static inline int arp_scale_snap(int note,unsigned key,unsigned set){
 for(int d=0;d<12;d++){
  if(note-d>=0 && note-d<=127 && arp_scale_contains(note-d,key,set))return note-d;
  if(note+d>=0 && note+d<=127 && arp_scale_contains(note+d,key,set))return note+d;
 }
 return -1;
}
/* Signed scale degrees, extrapolated outside MIDI range for REST handling. */
static inline int arp_scale_shift(int note,int degrees,unsigned key,unsigned set){
 int relative=note-(int)key,oct=relative/12,pc=relative%12;
 if(pc<0){pc+=12;--oct;}
 unsigned mask=arp_scale_mask(set),size=0,rank=0;
 for(int i=0;i<12;i++)if(mask&(1u<<i)){if(i<pc)++rank;++size;}
 if(!size)return -32768;
 int target=(int)rank+degrees,q=target/(int)size,rem=target%(int)size;
 if(rem<0){rem+=(int)size;--q;}
 for(int i=0;i<12;i++)if(mask&(1u<<i)){if(!rem)return (int)key+12*(oct+q)+i;--rem;}
 return -32768;
}
static inline int arp_scale_pool(unsigned key,unsigned set,int root,unsigned count,uint8_t out[16]){
 if(key>11 || set>=23 || root<0 || root>127 || !count || count>16 || !out)return -1;
 int start=arp_scale_snap(root,key,set);if(start<0)return -1;
 unsigned used=0;
 for(unsigned i=0;i<count;i++){int note=arp_scale_shift(start,(int)i,key,set);if(note>127)break;out[used++]=(uint8_t)note;}
 return (int)used;
}
#endif
