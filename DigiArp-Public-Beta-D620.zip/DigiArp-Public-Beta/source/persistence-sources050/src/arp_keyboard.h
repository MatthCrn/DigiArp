/* SPDX-License-Identifier: MIT */
#ifndef DIGIARP_KEYBOARD_H
#define DIGIARP_KEYBOARD_H
#include <stdint.h>
#define ARP_SOURCE_ABSOLUTE 4u
#define ARP_SOURCE_FIXED 5u
typedef struct {uint8_t count,notes[16],octave;} __attribute__((aligned(4))) arp_manual_notes;
/* Physical TRIG number 1..16. 9=C,10=D,...16=next C; black keys 2/3/5/6/7.
 * octave is the MIDI C bank 0..10 (base=12*octave). -1 means no valid note. */
int arp_keyboard_pitch(unsigned key,unsigned octave);
/* Toggle a unique absolute MIDI note, entry order preserved. Empty allowed.
 * 1 changed, 0 invalid input/state, -1 full; rejection leaves state intact. */
int arp_manual_toggle(arp_manual_notes *notes,unsigned pitch);
/* Validate then copy absolute pitches. 0 is a valid empty, silent source. */
int arp_manual_copy(const arp_manual_notes *notes,uint8_t out[16]);
#endif
