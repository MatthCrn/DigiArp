/* SPDX-License-Identifier: MIT */
#ifndef DIGIARP_PROBABILITY_H
#define DIGIARP_PROBABILITY_H
#include <stdint.h>
/* First-use decorrelation only. The live stream then continues across
 * source trigs, STOP, mute and pattern changes; this is a PRNG, not a TRNG. */
static inline uint32_t arp_probability_seed(uint32_t date,unsigned track){
 uint32_t x=date^(0x9e3779b9u*(track+1u));
 x^=x>>16;x*=0x85ebca6bu;x^=x>>13;x*=0xc2b2ae35u;x^=x>>16;
 return x?x:1u;
}
#endif
