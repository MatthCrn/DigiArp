/* SPDX-License-Identifier: MIT */
#ifndef DIGIARP_PLAYER_H
#define DIGIARP_PLAYER_H
#include "arp_sequence.h"
/* Caller-chosen musical tick unit (firmware 0.10 uses 1920/quarter). Every call is bounded, at most 8 elapsed ticks.
 * The caller supplies musical time, including tempo changes. uint32 wraps.
 * No audio/firmware access, allocations, shared state, or native pointers. */
#define ARP_PLAYER_MAX_ADVANCE 8u
typedef enum { ARP_PLAYER_OFF, ARP_PLAYER_ON } arp_player_kind;
typedef struct { uint32_t tick; arp_player_kind kind; uint8_t note,velocity,position; } arp_player_event;
/* Return zero only when the whole event has been accepted. Never re-enter. */
typedef int (*arp_player_emit)(void *context,const arp_player_event *event);
typedef struct {
    arp_sequence_config sequence;
    uint32_t period_ticks,note_ticks,source_ticks; /* source 0 = until stop */
    uint8_t velocity;
} arp_player_config;
typedef struct {
    arp_sequence sequence;
    uint8_t source_notes[ARP_SEQUENCE_NOTES];
    arp_player_emit emit;void *context;
    uint32_t tick,next_tick,off_tick,end_tick,period_ticks,note_ticks;
    uint8_t velocity,note,position,running,sounding,finite;
} arp_player;
/* Caller zero-initializes the object before its first start.
 * Invalid input leaves the object unchanged. Start emits the first position
 * immediately if active/in range. On output failure the engine stops; caller
 * remains responsible for emergency release in its native voice backend. */
int arp_player_start(arp_player *p,const arp_player_config *cfg,
                     const uint8_t *notes,unsigned count,uint32_t tick,
                     arp_player_emit emit,void *context);
/* Edit the running motif/timing without extending its source window or
 * shortening an already sounding note. The next scheduled slot keeps its
 * date; subsequent slots use the new period. Original input order is retained
 * for TRUE. Changing mode restarts the chord traversal, not the motif clock. */
int arp_player_edit(arp_player *p,const arp_sequence_config *sequence,
                    uint32_t period_ticks,uint32_t note_ticks);
int arp_player_advance(arp_player *p,uint32_t tick);
int arp_player_stop(arp_player *p,uint32_t tick);
int arp_player_rewind(arp_player *p,uint32_t tick);
#endif
