/* SPDX-License-Identifier: MIT */
#ifndef DIGIARP_ENGINE_H
#define DIGIARP_ENGINE_H
#include "arp_notes.h"
#include <stdbool.h>
typedef enum { ARP_UP, ARP_DOWN, ARP_RANDOM, ARP_UP_DOWN, ARP_DOWN_UP } arp_mode;
typedef enum { ARP_OFF, ARP_ON } arp_event_kind;
typedef struct { uint64_t tick; arp_event_kind kind; uint8_t note, velocity; } arp_event;
/* Synchronous bounded sink, must consume every event, never reenter the engine. */
typedef void (*arp_emit)(void *ctx, const arp_event *ev);
typedef struct {
    arp_mode mode;
    uint32_t period_ticks, seed;
    uint8_t gate_percent, octaves, velocity;
} arp_config;
typedef struct {
    arp_config config;
    uint8_t notes[ARP_MAX_NOTES], count, active_note;
    uint32_t cursor, rng, phase, gate_ticks;
    uint64_t last_tick;
    bool running, sounding;
    arp_emit emit;
    void *ctx;
} arp_engine;
/* init once on uninitialized storage. Invalid calls leave configured engine intact.
 * configure requires stopped and no loaded notes; set_notes requires stopped.
 * Reinitialize to configure after notes were loaded. Single-owner, no thread safety. */
int arp_init(arp_engine *a, arp_emit emit, void *ctx);
int arp_configure(arp_engine *a, const arp_config *cfg);
int arp_set_notes(arp_engine *a, const uint8_t *notes, size_t count);
int arp_start(arp_engine *a, uint64_t tick);
/* Exactly one call per tick after start; duplicate is idempotent, backward fails;
 * a gap stops with a Note Off and returns -1, never bursts stale Note Ons. */
int arp_tick(arp_engine *a, uint64_t tick);
int arp_stop(arp_engine *a, uint64_t tick);
#endif
