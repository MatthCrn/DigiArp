/* SPDX-License-Identifier: MIT */
#include "arp_player.h"
static int send(arp_player *p,arp_player_kind kind,uint32_t tick){
    unsigned velocity=p->sequence.config.velocity[p->position];
    arp_player_event e={tick,kind,p->note,(uint8_t)(velocity?velocity:p->velocity),p->position};
    if(p->emit(p->context,&e)){p->running=0;return -2;}
    p->sounding=(uint8_t)(kind==ARP_PLAYER_ON);return 0;
}
int arp_player_stop(arp_player *p,uint32_t tick){
    if(!p || !p->emit)return -1;
    p->running=0;
    return p->sounding?send(p,ARP_PLAYER_OFF,tick):0;
}
static int position(arp_player *p,uint32_t tick){
    arp_sequence_result r;
    if(arp_sequence_next(&p->sequence,&r)){p->running=0;return -1;}
    p->next_tick=tick+p->period_ticks;
    if(r.kind!=ARP_SEQ_NOTE)return 0;
    /* A new monophonic attack replaces the previous note. Its earlier OFF
     * must never terminate this replacement, even for repeated pitches. */
    if(p->sounding && send(p,ARP_PLAYER_OFF,tick))return -2;
    p->note=(uint8_t)r.pitch;p->position=r.position;
    if(send(p,ARP_PLAYER_ON,tick))return -2;
    unsigned span=p->sequence.config.span[p->position];
    p->off_tick=tick+(span?span*p->period_ticks:p->note_ticks);return 0;
}
int arp_player_start(arp_player *p,const arp_player_config *cfg,
                     const uint8_t *notes,unsigned count,uint32_t tick,
                     arp_player_emit emit,void *context){
    if(!p || !cfg || !emit || !cfg->period_ticks || cfg->period_ticks>0x7fffffffu ||
       !cfg->note_ticks || cfg->note_ticks>0x7fffffffu || cfg->source_ticks>0x7fffffffu ||
       !cfg->velocity || cfg->velocity>127 || p->running || p->sounding)return -1;
    for(unsigned i=0;i<16;i++)if(cfg->sequence.span[i] && cfg->period_ticks>0x7fffffffu/cfg->sequence.span[i])return -1;
    arp_player next={0};
    if(arp_sequence_init(&next.sequence,&cfg->sequence,notes,count))return -1;
    for(unsigned i=0;i<count;i++)next.source_notes[i]=notes[i];
    next.emit=emit;next.context=context;next.tick=tick;next.period_ticks=cfg->period_ticks;
    next.note_ticks=cfg->note_ticks;next.end_tick=tick+cfg->source_ticks;
    next.finite=(uint8_t)(cfg->source_ticks!=0);next.velocity=cfg->velocity;next.running=1;
    *p=next;return position(p,tick);
}
int arp_player_advance(arp_player *p,uint32_t tick){
    if(!p || !p->emit)return -1;
    if(!p->running)return 0;
    uint32_t elapsed=tick-p->tick;
    /* A backwards/discontinuous clock stops rather than replay a backlog. */
    if(elapsed>ARP_PLAYER_MAX_ADVANCE){int r=arp_player_stop(p,tick);return r?r:-3;}
    while(elapsed--){
        ++p->tick;
        /* Source end wins ties: no new note at the exclusive boundary. */
        if(p->finite && p->tick==p->end_tick)return arp_player_stop(p,p->tick);
        if(p->sounding && p->tick==p->off_tick && send(p,ARP_PLAYER_OFF,p->tick))return -2;
        if(p->tick==p->next_tick && position(p,p->tick))return -2;
    }
    return 0;
}

int arp_player_rewind(arp_player *p,uint32_t tick){
    if(!p || !p->running || tick-p->tick>=0x80000000u)return -1;
    arp_sequence next;
    if(arp_sequence_init(&next,&p->sequence.config,p->source_notes,p->sequence.count))return -1;
    next.probability_state=p->sequence.probability_state;p->sequence=next;p->tick=tick;
    if(p->finite && tick-p->end_tick<0x80000000u)return arp_player_stop(p,tick);
    /* The boundary may itself be the held note's release date. A first-slot
     * REST must still consume that OFF, otherwise the next service sees a
     * zero deadline and cancels the reader. Longer held gates stay intact. */
    if(p->sounding && tick-p->off_tick<0x80000000u && send(p,ARP_PLAYER_OFF,tick))return -2;
    return position(p,tick);
}
int arp_player_edit(arp_player *p,const arp_sequence_config *cfg,uint32_t period,uint32_t note){
    if(!p || !p->running || !cfg || !period || period>0x7fffffffu || !note || note>0x7fffffffu)return -1;
    for(unsigned i=0;i<16;i++)if(cfg->span[i] && period>0x7fffffffu/cfg->span[i])return -1;
    arp_sequence check;
    if(arp_sequence_init(&check,cfg,p->source_notes,p->sequence.count))return -1;
    /* All bounds are checked before publishing. Preserve traversal phase. */
    if(cfg->mode!=p->sequence.config.mode ||
       (cfg->mode>=ARP_SEQ_RANDOM && cfg->range!=p->sequence.config.range)){
        check.probability_state=p->sequence.probability_state;
        check.position=p->sequence.position;p->sequence=check;
    }
    p->sequence.config=*cfg;
    if(p->sequence.position>=cfg->length)p->sequence.position=0;
    if(p->sequence.octave>=cfg->range)p->sequence.octave=0;
    p->period_ticks=period;p->note_ticks=note;return 0;
}
