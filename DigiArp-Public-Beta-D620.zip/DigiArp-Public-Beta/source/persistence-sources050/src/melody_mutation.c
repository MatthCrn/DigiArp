/* SPDX-License-Identifier: MIT */
#include "melody_mutation.h"
static uint32_t rnd(uint32_t *s){uint32_t x=*s?*s:0x6d2b79f5u;x^=x<<13;x^=x>>17;x^=x<<5;*s=x;return x;}
static void repair(melody_phrase *p){
    for(unsigned i=1;i<p->count;i++)for(unsigned j=i;j && p->event[j].step<p->event[j-1].step;j--){melody_event v=p->event[j];p->event[j]=p->event[j-1];p->event[j-1]=v;}
    for(unsigned i=0;i<p->count;i++){
        unsigned gap=(i+1<p->count?p->event[i+1].step:16)-p->event[i].step;
        if(!p->event[i].span)p->event[i].span=1;
        if(p->event[i].span>gap)p->event[i].span=(uint8_t)gap;
    }
}
static int clamp(int n,int low,int high){return n<low?low:n>high?high:n;}
static int move(melody_phrase *p,unsigned at,uint32_t *rng,unsigned wide,int anchored){
    if(anchored && !(p->event[at].step%4))return 0;
    unsigned used=0,choices[32],count=0;
    for(unsigned i=0;i<p->count;i++)used|=1u<<p->event[i].step;
    for(unsigned i=0;i<16;i++)if(!(used&(1u<<i)) && (!anchored || i%4)){
        unsigned d=i>p->event[at].step?i-p->event[at].step:p->event[at].step-i;
        if(wide || d<=2){choices[count++]=i;if(!(i%2))choices[count++]=i;}
    }
    if(!count)return 0;
    p->event[at].step=(uint8_t)choices[rnd(rng)%count];repair(p);return 1;
}
/* ARP: accents first, then a neighbouring echo / exchanged two-note cell.
 * Upper depths rotate or change the whole figure; all notes remain chord tones. */
static int arp_variation(melody_engine *e,unsigned amount){
    uint8_t pool[MELODY_POOL],anchors[MELODY_POOL];
    int n=melody_pool(&e->config,pool),a=melody_anchor_degrees(&e->config,pool,n,anchors);
    if(n<0 || a<1)return -1;
    unsigned level=amount<=12?0:amount<=28?1:amount<=48?2:amount<=72?3:amount<=100?4:5;
    static const uint8_t budgets[6]={1,2,3,5,8,12};
    melody_phrase p=e->phrase;uint32_t rng=e->mutation_state;
    unsigned reach=melody_arp_reach((unsigned)a,e->config.motion);
    if(level==1 && p.count>1){
        unsigned choices[16],count=0;
        /* Echo a repeated note only: never erase a chord voice after many bars. */
        for(unsigned i=0;i<p.count;i++){
            unsigned same=0;for(unsigned j=0;j<p.count;j++)same+=p.event[i].note==p.event[j].note;
            if(same>1)choices[count++]=i;
        }
        if(count){
            unsigned at=choices[rnd(&rng)%count],from=(at+1u)%p.count;
            for(unsigned j=0;j<p.count && p.event[from].note==p.event[at].note;j++)from=(from+1u)%p.count;
            p.event[at].note=p.event[from].note;p.event[at].degree=p.event[from].degree;
        }
    }else if(level==2 && p.count>1){
        unsigned at=rnd(&rng)%p.count,other=(at+1u)%p.count;
        for(unsigned j=0;j<p.count && p.event[at].note==p.event[other].note;j++){at=(at+1u)%p.count;other=(at+1u)%p.count;}
        uint8_t note=p.event[at].note;int16_t degree=p.event[at].degree;
        p.event[at].note=p.event[other].note;p.event[at].degree=p.event[other].degree;
        p.event[other].note=note;p.event[other].degree=degree;
    }else if(level>=3){
        unsigned base=e->config.motion/8u;
        unsigned mode=level==5?rnd(&rng)%MELODY_ARP_FIGURES:level==4?(base+14u+rnd(&rng)%5u)%MELODY_ARP_FIGURES:base;
        unsigned period=melody_arp_period(reach,mode),phase=rnd(&rng)%period;
        /* Avoid an inaudible repeated contour when the current chord allows it. */
        for(unsigned attempt=0;attempt<period;attempt++,phase=(phase+1u)%period){
            unsigned changed=0;
            for(unsigned i=0;i<p.count;i++){
                unsigned d=anchors[melody_arp_index(i,reach,mode,phase)];
                changed|=e->phrase.event[i].note!=pool[d];
                p.event[i].degree=(int16_t)d;p.event[i].note=pool[d];
            }
            if(changed)break;
        }
    }
    unsigned used=0,budget=budgets[level];if(budget>p.count)budget=p.count;
    for(unsigned k=0;k<budget;k++){
        unsigned choices[16],count=0;
        for(unsigned j=0;j<p.count;j++)if(!(used&(1u<<j)))choices[count++]=j;
        unsigned at=choices[rnd(&rng)%count];used|=1u<<at;
        unsigned old_span=p.event[at].span,old_velocity=p.event[at].velocity;
        if(level>=2 && (rnd(&rng)&1u)){
            unsigned gap=(at+1<p.count?p.event[at+1].step:16)-p.event[at].step;
            unsigned span=1u<<(rnd(&rng)%(level>=4?3u:2u));if(span>gap)span=gap;
            p.event[at].span=(uint8_t)span;
        }else{
            int radius=3+5*(int)level,shift=1+(int)(rnd(&rng)%(unsigned)radius);if(rnd(&rng)&1u)shift=-shift;
            p.event[at].velocity=(uint8_t)clamp((int)p.event[at].velocity+shift,1,127);
        }
        if(p.event[at].span==old_span && p.event[at].velocity==old_velocity)
            p.event[at].velocity=(uint8_t)(old_velocity>=124?old_velocity-2:old_velocity+2);
    }
    if(!melody_phrase_valid(&p))return -1;
    e->previous=e->phrase;e->previous_config=e->config;e->undo_valid=1;e->phrase=p;e->mutation_state=rng;return 0;
}
int melody_variation(melody_engine *e,unsigned preset,unsigned amount){
    if(!e || preset>=MELODY_PRESETS || amount>127 || !melody_phrase_valid(&e->phrase))return -1;
    if(!amount || !e->phrase.count)return 0;
    if(preset==MELODY_PRESET_ARP)return arp_variation(e,amount);
    uint32_t rng=e->mutation_state;
    uint8_t pool[MELODY_POOL],anchors[MELODY_POOL];int n=melody_pool(&e->config,pool),a=melody_anchor_degrees(&e->config,pool,n,anchors);
    if(n<0 || a<1)return -1;
    /* Six live depths. A small depth always touches one event, without a
     * chance of skipping the entire bar. Pitch remains in the selected pool. */
    unsigned level=amount<=12?0:amount<=28?1:amount<=48?2:amount<=72?3:amount<=100?4:5;
    static const uint8_t budgets[6]={1,2,3,5,8,12};
    melody_phrase p=e->phrase;unsigned budget=budgets[level],used=0;
    if(budget>p.count)budget=p.count;
    for(unsigned k=0;k<budget;k++){
        unsigned choices[16],count=0;
        for(unsigned j=0;j<p.count;j++)if(!(used&(1u<<p.event[j].step)))choices[count++]=j;
        unsigned at=choices[rnd(&rng)%count],kind=rnd(&rng)%(level<2?2u:4u);
        melody_event before=p.event[at];
        if(!level)kind=(rnd(&rng)&1u)?0:3;
        if(preset==MELODY_PRESET_ROLL){
            unsigned draw=rnd(&rng)%8u;
            kind=!level?3:level==1?(draw<4?2u:3u):draw==0?0u:draw<4?1u:draw<6?2u:3u;
        }
        if(level==1 && kind==1)kind=3;
        if(kind==0){
            unsigned degree=(unsigned)p.event[at].degree;
            unsigned reach=1+(((unsigned)n-1u)*e->config.motion+126u)/127u;
            if(preset==MELODY_PRESET_ROLL){
                /* Retune or relocate an existing colour, never accumulate more.
                 * Accents, gates and syncopation dominate ROLL's evolution. */
                if(p.event[at].step%8 && e->config.motion>=8 && n>1){
                    if(p.event[at].note==pool[0]){
                        unsigned choices_colour[16],colours=0;
                        for(unsigned j=0;j<p.count;j++)if(p.event[j].note!=pool[0] && p.event[j].step%8)choices_colour[colours++]=j;
                        if(colours){unsigned from=choices_colour[rnd(&rng)%colours];p.event[from].note=pool[0];p.event[from].degree=0;}
                        degree=colours?melody_roll_degree(&e->config,anchors,(unsigned)a,(unsigned)n,rnd(&rng)):0;
                    }else degree=melody_roll_degree(&e->config,anchors,(unsigned)a,(unsigned)n,rnd(&rng));
                }else degree=0;
            }else if(level<2){
                /* One neighbouring scale degree at most; preserve the downbeat. */
                if(at && reach>1 && degree<reach){
                    degree=degree && (degree+1>=reach || (rnd(&rng)&1u))?degree-1:degree+1;
                }
            }else if(at || level==5){
                unsigned limit=1+(((unsigned)a-1u)*e->config.motion+126u)/127u;
                if(((preset==MELODY_PRESET_BASS || preset==MELODY_PRESET_ROLL) && level<5) || !(p.event[at].step%4))
                    degree=anchors[rnd(&rng)%limit];
                else degree=rnd(&rng)%reach;
            }
            p.event[at].note=pool[degree];p.event[at].degree=(int16_t)degree;
        }else if(kind==1){
            unsigned old_steps=0;for(unsigned j=0;j<p.count;j++)old_steps|=1u<<p.event[j].step;
            (void)move(&p,at,&rng,level>=4,1);
            /* move() sorts events; recover the moved voice by the unique slot. */
            for(unsigned j=0;j<p.count;j++)if(!(old_steps&(1u<<p.event[j].step)) && !(used&(1u<<p.event[j].step))){at=j;break;}
        }else if(kind==2){
            unsigned gap=(at+1<p.count?p.event[at+1].step:16)-p.event[at].step;
            unsigned span=1u<<(rnd(&rng)%(level>=4?3u:2u));if(span>gap)span=gap;
            p.event[at].span=(uint8_t)span;
        }else{
            int radius=level==0?3:level==1?6:4+(int)level*5;
            int shift=1+(int)(rnd(&rng)%(unsigned)radius);if(rnd(&rng)&1u)shift=-shift;
            p.event[at].velocity=(uint8_t)clamp((int)p.event[at].velocity+shift,level<2?1:40,127);
        }
        if(p.event[at].step==before.step && p.event[at].note==before.note &&
           p.event[at].span==before.span && p.event[at].velocity==before.velocity)
            p.event[at].velocity=(uint8_t)(before.velocity>=124?before.velocity-2:before.velocity+2);
        used|=1u<<p.event[at].step;
    }
    repair(&p);if(!melody_phrase_valid(&p))return -1;
    e->previous=e->phrase;e->previous_config=e->config;e->undo_valid=1;e->phrase=p;e->mutation_state=rng;return 0;
}

int melody_chaos(melody_engine *e,unsigned amount,int vary){
    if(!e || amount>127 || !melody_phrase_valid(&e->phrase))return -1;
    if(!amount || !e->phrase.count)return 0;
    uint32_t state=e->mutation_state,rng=(vary?rnd(&state):e->new_state)^0xc2b2ae35u^(amount*0x9e3779b9u);
    melody_phrase p=e->phrase;unsigned budget=1+9u*amount/127u;
    for(unsigned k=0;k<budget;k++){
        unsigned kind=rnd(&rng)%(amount>80?6u:4u);
        if(!p.count)kind=5;
        unsigned at=p.count?rnd(&rng)%p.count:0;
        if(kind==0){
            int radius=1+(int)(amount*23u/127u);
            int note=(int)p.event[at].note+(int)(rnd(&rng)%(unsigned)(2*radius+1))-radius;
            p.event[at].note=(uint8_t)clamp(note,36,84);
        }else if(kind==1){(void)move(&p,at,&rng,amount>=48,amount<48);}
        else if(kind==2){
            unsigned gap=(at+1<p.count?p.event[at+1].step:16)-p.event[at].step;
            unsigned span=1u<<(rnd(&rng)%(amount>80?5u:3u));if(span>gap)span=gap;p.event[at].span=(uint8_t)span;
        }else if(kind==3){
            int radius=2+(int)(amount*80u/127u);
            p.event[at].velocity=(uint8_t)clamp((int)p.event[at].velocity+(int)(rnd(&rng)%(unsigned)(2*radius+1))-radius,1,127);
        }else if(kind==4){
            for(unsigned i=at;i+1<p.count;i++)p.event[i]=p.event[i+1];
            --p.count;p.event[p.count]=(melody_event){0};
        }else if(p.count<16){
            unsigned used=0;for(unsigned i=0;i<p.count;i++)used|=1u<<p.event[i].step;
            unsigned step=rnd(&rng)%16;for(unsigned i=0;i<16 && (used&(1u<<step));i++)step=(step+1)%16;
            if(!(used&(1u<<step)))p.event[p.count++]=(melody_event){(uint8_t)step,1,(uint8_t)(36+rnd(&rng)%49),(uint8_t)(40+rnd(&rng)%88),0,0,0};
        }
        repair(&p);
    }
    if(!melody_phrase_valid(&p))return -1;
    e->previous=e->phrase;e->previous_config=e->config;e->undo_valid=1;e->phrase=p;if(vary)e->mutation_state=state;return 0;
}
