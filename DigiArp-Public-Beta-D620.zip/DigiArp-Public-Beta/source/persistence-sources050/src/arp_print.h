/* SPDX-License-Identifier: MIT */
#ifndef ARP_PRINT_H
#define ARP_PRINT_H
#include <stdint.h>
#define ARP_PRINT_STEPS 64u
#define ARP_PRINT_TRACK_BYTES 911u
/* Capture dates are the native musical clock, not wall time. */
enum arp_print_phase {ARP_PRINT_IDLE,ARP_PRINT_ARMED,ARP_PRINT_RECORDING,ARP_PRINT_READY,ARP_PRINT_ERROR,ARP_PRINT_DONE,ARP_PRINT_PENDING,ARP_PRINT_PREPARED,ARP_PRINT_QUEUED};
enum arp_print_error {ARP_PRINT_OK,ARP_PRINT_GEOMETRY,ARP_PRINT_GRID,ARP_PRINT_COLLISION,ARP_PRINT_NOTE,ARP_PRINT_CONTEXT,ARP_PRINT_STOPPED,ARP_PRINT_EMPTY,ARP_PRINT_DURATION};
typedef struct {uint32_t duration;uint8_t active,note,velocity,pad;} arp_print_step;
typedef struct {
 uint32_t phase,error,context,step_units,steps,start,count;
 arp_print_step step[ARP_PRINT_STEPS];
 uint32_t clock_started; /* poll distinguishes future start from long (>2^31) windows */
} arp_print;
int arp_print_arm(arp_print *,uint32_t context,unsigned steps,uint32_t step_units);
void arp_print_begin(arp_print *,uint32_t date);
void arp_print_attack(arp_print *,uint32_t date,unsigned note,unsigned velocity,uint32_t duration);
void arp_print_poll(arp_print *,uint32_t date,int running,uint32_t context);
void arp_print_silence(arp_print *,uint32_t date);
/* OS1.54 audio-track container adapter; source/output may alias. Native
 * lock pool, other tracks and track geometry are never touched. len_table
 * is the firmware's 129-entry duration table, read from its own image. */
int arp_print_build(const arp_print *,const uint8_t source[ARP_PRINT_TRACK_BYTES],uint8_t output[ARP_PRINT_TRACK_BYTES],const uint32_t len_table[129]);
#endif
