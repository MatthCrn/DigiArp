/* SPDX-License-Identifier: MIT */
#include "project_record.h"
static void zero(uint8_t *p,unsigned n){for(unsigned i=0;i<n;i++)p[i]=0;}
static uint32_t get(const uint8_t *p){return (uint32_t)p[0]<<24 | (uint32_t)p[1]<<16 | (uint32_t)p[2]<<8 | p[3];}
static void put(uint8_t *p,uint32_t v){p[0]=(uint8_t)(v>>24);p[1]=(uint8_t)(v>>16);p[2]=(uint8_t)(v>>8);p[3]=(uint8_t)v;}
static const uint32_t crc_table[256]={
0x00000000u,0x77073096u,0xee0e612cu,0x990951bau,0x076dc419u,0x706af48fu,0xe963a535u,0x9e6495a3u,
0x0edb8832u,0x79dcb8a4u,0xe0d5e91eu,0x97d2d988u,0x09b64c2bu,0x7eb17cbdu,0xe7b82d07u,0x90bf1d91u,
0x1db71064u,0x6ab020f2u,0xf3b97148u,0x84be41deu,0x1adad47du,0x6ddde4ebu,0xf4d4b551u,0x83d385c7u,
0x136c9856u,0x646ba8c0u,0xfd62f97au,0x8a65c9ecu,0x14015c4fu,0x63066cd9u,0xfa0f3d63u,0x8d080df5u,
0x3b6e20c8u,0x4c69105eu,0xd56041e4u,0xa2677172u,0x3c03e4d1u,0x4b04d447u,0xd20d85fdu,0xa50ab56bu,
0x35b5a8fau,0x42b2986cu,0xdbbbc9d6u,0xacbcf940u,0x32d86ce3u,0x45df5c75u,0xdcd60dcfu,0xabd13d59u,
0x26d930acu,0x51de003au,0xc8d75180u,0xbfd06116u,0x21b4f4b5u,0x56b3c423u,0xcfba9599u,0xb8bda50fu,
0x2802b89eu,0x5f058808u,0xc60cd9b2u,0xb10be924u,0x2f6f7c87u,0x58684c11u,0xc1611dabu,0xb6662d3du,
0x76dc4190u,0x01db7106u,0x98d220bcu,0xefd5102au,0x71b18589u,0x06b6b51fu,0x9fbfe4a5u,0xe8b8d433u,
0x7807c9a2u,0x0f00f934u,0x9609a88eu,0xe10e9818u,0x7f6a0dbbu,0x086d3d2du,0x91646c97u,0xe6635c01u,
0x6b6b51f4u,0x1c6c6162u,0x856530d8u,0xf262004eu,0x6c0695edu,0x1b01a57bu,0x8208f4c1u,0xf50fc457u,
0x65b0d9c6u,0x12b7e950u,0x8bbeb8eau,0xfcb9887cu,0x62dd1ddfu,0x15da2d49u,0x8cd37cf3u,0xfbd44c65u,
0x4db26158u,0x3ab551ceu,0xa3bc0074u,0xd4bb30e2u,0x4adfa541u,0x3dd895d7u,0xa4d1c46du,0xd3d6f4fbu,
0x4369e96au,0x346ed9fcu,0xad678846u,0xda60b8d0u,0x44042d73u,0x33031de5u,0xaa0a4c5fu,0xdd0d7cc9u,
0x5005713cu,0x270241aau,0xbe0b1010u,0xc90c2086u,0x5768b525u,0x206f85b3u,0xb966d409u,0xce61e49fu,
0x5edef90eu,0x29d9c998u,0xb0d09822u,0xc7d7a8b4u,0x59b33d17u,0x2eb40d81u,0xb7bd5c3bu,0xc0ba6cadu,
0xedb88320u,0x9abfb3b6u,0x03b6e20cu,0x74b1d29au,0xead54739u,0x9dd277afu,0x04db2615u,0x73dc1683u,
0xe3630b12u,0x94643b84u,0x0d6d6a3eu,0x7a6a5aa8u,0xe40ecf0bu,0x9309ff9du,0x0a00ae27u,0x7d079eb1u,
0xf00f9344u,0x8708a3d2u,0x1e01f268u,0x6906c2feu,0xf762575du,0x806567cbu,0x196c3671u,0x6e6b06e7u,
0xfed41b76u,0x89d32be0u,0x10da7a5au,0x67dd4accu,0xf9b9df6fu,0x8ebeeff9u,0x17b7be43u,0x60b08ed5u,
0xd6d6a3e8u,0xa1d1937eu,0x38d8c2c4u,0x4fdff252u,0xd1bb67f1u,0xa6bc5767u,0x3fb506ddu,0x48b2364bu,
0xd80d2bdau,0xaf0a1b4cu,0x36034af6u,0x41047a60u,0xdf60efc3u,0xa867df55u,0x316e8eefu,0x4669be79u,
0xcb61b38cu,0xbc66831au,0x256fd2a0u,0x5268e236u,0xcc0c7795u,0xbb0b4703u,0x220216b9u,0x5505262fu,
0xc5ba3bbeu,0xb2bd0b28u,0x2bb45a92u,0x5cb36a04u,0xc2d7ffa7u,0xb5d0cf31u,0x2cd99e8bu,0x5bdeae1du,
0x9b64c2b0u,0xec63f226u,0x756aa39cu,0x026d930au,0x9c0906a9u,0xeb0e363fu,0x72076785u,0x05005713u,
0x95bf4a82u,0xe2b87a14u,0x7bb12baeu,0x0cb61b38u,0x92d28e9bu,0xe5d5be0du,0x7cdcefb7u,0x0bdbdf21u,
0x86d3d2d4u,0xf1d4e242u,0x68ddb3f8u,0x1fda836eu,0x81be16cdu,0xf6b9265bu,0x6fb077e1u,0x18b74777u,
0x88085ae6u,0xff0f6a70u,0x66063bcau,0x11010b5cu,0x8f659effu,0xf862ae69u,0x616bffd3u,0x166ccf45u,
0xa00ae278u,0xd70dd2eeu,0x4e048354u,0x3903b3c2u,0xa7672661u,0xd06016f7u,0x4969474du,0x3e6e77dbu,
0xaed16a4au,0xd9d65adcu,0x40df0b66u,0x37d83bf0u,0xa9bcae53u,0xdebb9ec5u,0x47b2cf7fu,0x30b5ffe9u,
0xbdbdf21cu,0xcabac28au,0x53b39330u,0x24b4a3a6u,0xbad03605u,0xcdd70693u,0x54de5729u,0x23d967bfu,
0xb3667a2eu,0xc4614ab8u,0x5d681b02u,0x2a6f2b94u,0xb40bbe37u,0xc30c8ea1u,0x5a05df1bu,0x2d02ef8du
};
static uint32_t crc_step(uint32_t crc,const uint8_t *p,unsigned n){
 for(unsigned i=0;i<n;i++)crc=(crc>>8)^crc_table[(crc^p[i])&255u];
 return crc;
}
uint32_t pd_crc(const void *p,unsigned n){return ~crc_step(0xffffffffu,p,n);}
typedef struct {uint32_t project,native_crc,generation,length,crc;unsigned valid;} header;
static int read_header(const pd_io *io,unsigned slot,header *h){
 uint8_t b[PD_HEADER];*h=(header){0};
 if(io->read(io->context,PD_BANK_START+slot*PD_BANK_STRIDE,b,PD_HEADER))return PD_IO;
 if(get(b)!=0x454c5058u)return PD_MISSING; /* ELPX */
 if(get(b+4)!=1)return PD_INCOMPATIBLE;
 if(get(b+8)!=PD_HEADER || get(b+36)!=pd_crc(b,36))return PD_CORRUPT;
 h->project=get(b+12);h->native_crc=get(b+16);h->generation=get(b+20);h->length=get(b+24);h->crc=get(b+28);
 if(!h->generation || !h->length || h->length>PD_MAX_PAYLOAD || get(b+32)!=0)return PD_CORRUPT;
 for(unsigned i=40;i<PD_HEADER;i++)if(b[i])return PD_CORRUPT;
 h->valid=1;return PD_OK;
}
static int check(const pd_io *io,unsigned bank,const header *h,void *staging){
 uint8_t buf[PD_HEADER];uint32_t crc=0xffffffffu;
 for(unsigned at=0;at<h->length;at+=PD_HEADER){
  unsigned n=h->length-at;if(n>PD_HEADER)n=PD_HEADER;
  if(io->read(io->context,PD_BANK_START+bank*PD_BANK_STRIDE+PD_HEADER+at,buf,PD_HEADER))return PD_IO;
  crc=crc_step(crc,buf,n);
  if(staging)for(unsigned i=0;i<n;i++)((uint8_t *)staging)[at+i]=buf[i];
 }
 return ~crc==h->crc?PD_OK:PD_CORRUPT;
}
static int newest(const header h[2]){
 if(h[0].valid && h[1].valid){
  uint32_t d=h[1].generation-h[0].generation;
  if(d==0x80000000u || (!d && (h[0].crc!=h[1].crc || h[0].native_crc!=h[1].native_crc || h[0].length!=h[1].length)))return PD_CONFLICT;
  return d && d<0x80000000u?1:0;
 }
 return h[0].valid?0:h[1].valid?1:PD_MISSING+2;
}
int pd_load(const pd_io *io,uint32_t project,uint32_t native_crc,void *staging,unsigned capacity,unsigned *length,uint32_t *generation){
 if(!io || !io->read || !staging || !length || !generation)return PD_INVALID;
 header h[2];unsigned corrupt=0;
 for(unsigned k=0;k<2;k++){
  int result=read_header(io,k,&h[k]);if(result==PD_IO || result==PD_INCOMPATIBLE)return result;corrupt|=result==PD_CORRUPT;
  if(h[k].valid && (h[k].project!=project || h[k].native_crc!=native_crc))h[k].valid=0;
  if(h[k].valid){if(h[k].length>capacity)return PD_INVALID;result=check(io,k,&h[k],0);if(result==PD_IO || result==PD_INCOMPATIBLE)return result;if(result){h[k].valid=0;corrupt=1;}}
 }
 int pick=newest(h);if(pick==PD_CONFLICT)return pick;if(pick>1)return corrupt?PD_CORRUPT:PD_MISSING;
 int result=check(io,(unsigned)pick,&h[pick],staging);if(result)return result;
 *length=h[pick].length;*generation=h[pick].generation;return PD_OK;
}
int pd_save_protected_commit(const pd_io *io,uint32_t project,uint32_t native_crc,const void *data,unsigned length,unsigned protected_bank,pd_commit *commit){
 if(!io || !io->read || !io->write || !io->sync || !data || !length || length>PD_MAX_PAYLOAD)return PD_INVALID;
 header h[2];
 for(unsigned k=0;k<2;k++){
  int result=read_header(io,k,&h[k]);if(result==PD_IO || result==PD_INCOMPATIBLE)return result;
  if(h[k].valid && h[k].project!=project)h[k].valid=0;
  if(h[k].valid){result=check(io,k,&h[k],0);if(result==PD_IO || result==PD_INCOMPATIBLE)return result;if(result)h[k].valid=0;}
 }
 int previous=newest(h);if(previous==PD_CONFLICT)return previous;
 unsigned bank=protected_bank<2?(protected_bank^1u):previous<=1?((unsigned)previous^1u):0u;
 uint32_t gen=previous<=1?h[previous].generation+1u:1u;if(!gen)gen=1;
 unsigned base=PD_BANK_START+bank*PD_BANK_STRIDE;uint8_t b[PD_HEADER];zero(b,sizeof b);
 if(io->write(io->context,base,b,sizeof b) || io->sync(io->context))return PD_IO;
 for(unsigned at=0;at<length;at+=PD_HEADER){
  unsigned n=length-at;if(n>PD_HEADER)n=PD_HEADER;zero(b,sizeof b);
  for(unsigned j=0;j<n;j++)b[j]=((const uint8_t *)data)[at+j];
  if(io->write(io->context,base+PD_HEADER+at,b,sizeof b))return PD_IO;
 }
 if(io->sync(io->context))return PD_IO;
 uint32_t payload_crc=pd_crc(data,length);
 zero(b,sizeof b);put(b,0x454c5058u);put(b+4,1);put(b+8,PD_HEADER);put(b+12,project);put(b+16,native_crc);put(b+20,gen);put(b+24,length);put(b+28,payload_crc);put(b+36,pd_crc(b,36));
 if(io->write(io->context,base,b,sizeof b) || io->sync(io->context))return PD_IO;
 header verify;if(read_header(io,bank,&verify)!=PD_OK || verify.project!=project || verify.native_crc!=native_crc || verify.generation!=gen || verify.length!=length || verify.crc!=payload_crc)return PD_IO;
 if(check(io,bank,&verify,0)!=PD_OK)return PD_IO;
 if(commit)*commit=(pd_commit){bank,gen,length,payload_crc};
 return PD_OK;
}

int pd_save_protected(const pd_io *io,uint32_t project,uint32_t native_crc,const void *data,unsigned length,unsigned protected_bank){return pd_save_protected_commit(io,project,native_crc,data,length,protected_bank,0);}
int pd_save(const pd_io *io,uint32_t project,uint32_t native_crc,const void *data,unsigned length){return pd_save_protected(io,project,native_crc,data,length,2);}
int pd_load_bank(const pd_io *io,unsigned bank,uint32_t generation,uint32_t project,uint32_t native_crc,void *staging,unsigned capacity,unsigned *length){
 if(!io || !io->read || bank>1 || !staging || !length)return PD_INVALID;
 header h;int result=read_header(io,bank,&h);if(result)return result;
 if(h.project!=project || h.native_crc!=native_crc || h.generation!=generation)return PD_MISSING;
 if(h.length>capacity)return PD_INVALID;
 result=check(io,bank,&h,staging);if(result)return result;*length=h.length;return PD_OK;
}
/* Name and identity may change on native rename/copy; the native content and
 * ignored metadata gap are separate. The owning UID is checked independently. */
uint32_t pd_native_crc(const void *project){const uint8_t *p=project;uint32_t c=crc_step(0xffffffffu,p,8);return ~crc_step(c,p+512,PD_NATIVE_BYTES-512);}
