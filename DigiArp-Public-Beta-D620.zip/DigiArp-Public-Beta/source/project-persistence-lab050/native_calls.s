| SPDX-License-Identifier: GPL-2.0-or-later
.text
.globl pd_fw_read
pd_fw_read:
 jmp 0x400e36d8
.globl pd_fw_write
pd_fw_write:
 jmp 0x400e47e0

.globl pd_allocate
pd_allocate:
 jmp 0x400d43a8
