/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef DIGIARP_PROJECT_MANAGER_H
#define DIGIARP_PROJECT_MANAGER_H
#include "melody_record.h"
#define DARP_PROJECT_BYTES (256u+128u*16u*ME_RECORD_BYTES+16u*ME_RECORD_BYTES)
int darp_me_snapshot_track(unsigned,me_record *);
int darp_me_snapshot_kit_track(unsigned,const unsigned char *,me_record *);
int darp_me_apply_snapshot_track(unsigned,const me_record *);
void darp_project_tick(void);
void darp_project_stash(unsigned);
void darp_project_stash_task(unsigned);
void darp_project_poll_track(unsigned);
extern volatile uint32_t darp_store_context_serial;
unsigned darp_store_snapshot_ready(unsigned,uint32_t);
void darp_project_apply(unsigned,unsigned char *);
int darp_project_capture(uint32_t,uint8_t *,unsigned);
int darp_project_load(uint32_t,const uint8_t *,unsigned);
void darp_project_reset(uint32_t);
void darp_project_identity_changed(uint32_t,uint32_t);
void darp_project_temp_begin(unsigned,uint32_t);
void darp_project_temp_commit(unsigned);
unsigned darp_project_temp_available(uint32_t);
void darp_project_temp_restore(unsigned,uint32_t);
void darp_store_invalidate(void);
void darp_store_invalidate_pattern(unsigned);
void darp_ram_apply_controls(const arp_snapshot_state *,unsigned char *);
#endif
