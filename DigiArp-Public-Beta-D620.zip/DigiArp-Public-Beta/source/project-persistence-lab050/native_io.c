/* SPDX-License-Identifier: GPL-2.0-or-later */
/* Lab adapter only. Verified stock 1.54 function entries; no installed hooks. */
#include "project_record.h"
typedef struct {uint32_t driver,slot;} native_context;
extern int pd_fw_read(void *,unsigned,unsigned,void *,void *);
extern int pd_fw_write(void *,unsigned,unsigned,const void *,void *,unsigned);
static int range(const native_context *c,unsigned off,unsigned n){return c && c->slot<=128 && !(off%512) && !(n%512) && off>=PD_BANK_START && n && n<=PD_SLOT_BYTES-off && off<PD_SLOT_BYTES;}
unsigned pd_sector(unsigned slot,unsigned offset){return (slot==128?0x7e000u:(64u+slot)*8192u)+offset/512u;}
int pd_native_read(void *context,unsigned off,void *data,unsigned n){
 native_context *c=context;uint32_t progress[3]={0};if(!range(c,off,n))return -1;
 return pd_fw_read((void *)c->driver,pd_sector(c->slot,off),n,data,progress)?-1:0;
}
int pd_native_write(void *context,unsigned off,const void *data,unsigned n){
 native_context *c=context;uint32_t progress[3]={0};if(!range(c,off,n))return -1;
 return pd_fw_write((void *)c->driver,pd_sector(c->slot,off),n,data,progress,0)?-1:0;
}
int pd_native_sync(void *context){(void)context;return 0;}
/* Native I/O is synchronous and save reads every committed byte back.
 * This does not claim power-loss atomicity of the physical eMMC controller. */
