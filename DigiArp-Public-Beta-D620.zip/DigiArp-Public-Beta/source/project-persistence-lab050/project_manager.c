/* SPDX-License-Identifier: GPL-2.0-or-later */
/* Raw snapshots in audio context; encoding, allocation and disk in task context. */
#include "project_manager.h"
#include "../persistence-sources050/firmware/melody_native/lfo.h"
#include "../persistence-sources050/src/arp_lz.h"
#include "digitakt-mk1/core3.h"
#include "../persistence-sources050/firmware/melody_native/pattern_store.h"
#include "../persistence-sources050/firmware/melody_native/core_audio.h"
#include "../persistence-sources050/firmware/melody_native/melody_native.h"
#include "../persistence-sources050/firmware/melody_native/controls.h"
extern void *pd_allocate(unsigned);
extern volatile uint32_t darp_ui_visible;
typedef struct {me_record track[128][16],scratch[16],temp_storage[2][16];uint32_t epoch[128];} project_bank;
static project_bank *bank;
static uint32_t owner,epoch=1,serial;static volatile unsigned loading;
#define capture_rows (bank->scratch)
/* Exact change stamps, not hashes: no missed update from a hash collision.
 * The audio player changes queues/cycles, which are deliberately not persisted. */
typedef struct {
 darp_track_controls controls;darp_rhythm_controls rhythm;arp_manual_notes manual;
 uint32_t revision,enabled,ready,imported,saved;
 int16_t lfo3[8];uint8_t knobs[8],root,octave,key,span[16],velocity[16];int16_t lfo[2];
} live_stamp;
static live_stamp stamps[16];static unsigned stamp_index=128,stamp_valid;
static void make_stamp(unsigned t,unsigned index,live_stamp *p){
 *p=(live_stamp){0};p->controls=darp_controls[t];p->rhythm=darp_rhythm[t];p->manual=darp_manual[t];
 p->revision=darp_me_revision_tracks[t];p->enabled=darp_me_enabled_tracks[t];p->ready=darp_me_ready_tracks[t];p->imported=darp_me_imported_tracks[t];p->saved=darp_me_saved_tracks[t];
 for(unsigned i=0;i<8;i++)p->knobs[i]=darp_me_knobs_tracks[t][i];
 for(unsigned i=0;i<16;i++){p->span[i]=darp_me_span_tracks[t][i];p->velocity[i]=darp_me_velocity_tracks[t][i];}
 if(t<8)for(unsigned i=0;i<8;i++)p->lfo3[i]=darp_lfo3[t][i];
 p->root=darp_fixed_root[t];p->octave=darp_fixed_octave[t];p->key=darp_key[t];
 const unsigned char *kit=(const unsigned char *)(0x4191f018u+index*0x91eu);
 for(unsigned l=0;t<8 && l<2;l++)p->lfo[l]=*(const volatile int16_t *)(kit+0x20+0xa2*t+20+2*(4+8*l));
}
static unsigned same_stamp(const live_stamp *a,const live_stamp *b){
 const uint8_t *x=(const uint8_t *)a,*y=(const uint8_t *)b;
 for(unsigned i=0;i<sizeof *a;i++)if(x[i]!=y[i])return 0;
 return 1;
}
/* The ColdFire ABI gives me_record two-byte alignment. GCC/Clang alias type permits word
 * copies of object representations without strict-aliasing violations. */
typedef uint16_t record_word __attribute__((__may_alias__));
_Static_assert(sizeof(me_record)%2==0,"word-aligned record size");
static void copy_record(me_record *to,const me_record *from){
 record_word *d=(record_word *)to;const record_word *s=(const record_word *)from;
 for(unsigned i=0;i<sizeof *to/2;i++)d[i]=s[i];
}

static me_record *temp,*temp_next;static uint32_t temp_owner,temp_valid,temp_next_owner,temp_next_valid;
volatile int32_t darp_project_error;
static uint32_t get(const uint8_t *b){return (uint32_t)b[0]<<24 | (uint32_t)b[1]<<16 | (uint32_t)b[2]<<8 | b[3];}
static void put(uint8_t *b,uint32_t x){b[0]=(uint8_t)(x>>24);b[1]=(uint8_t)(x>>16);b[2]=(uint8_t)(x>>8);b[3]=(uint8_t)x;}
static int memory(void){
 if(bank)return 0;
 project_bank *p=pd_allocate(sizeof *p);if(!p){darp_project_error=-30;return -1;}
 for(unsigned i=0;i<128;i++)p->epoch[i]=0;
 uint32_t sr=core_audio_irq_save();temp=p->temp_storage[0];temp_next=p->temp_storage[1];bank=p;owner=darp_ram_project_id();core_audio_irq_restore(sr);if(darp_project_error==-30)darp_project_error=0;return 0;
}
void darp_project_reset(uint32_t id){
 uint32_t sr=core_audio_irq_save();owner=id;if(!++epoch){epoch=1;if(bank)for(unsigned i=0;i<128;i++)bank->epoch[i]=0;}
 ++serial;stamp_valid=0;stamp_index=128;temp_valid=0;temp_owner=id;core_audio_irq_restore(sr);darp_store_invalidate();
}
volatile uint32_t darp_project_identity_remaps;
void darp_project_identity_changed(uint32_t old_id,uint32_t new_id){
 uint32_t sr=core_audio_irq_save();
 if(owner==old_id && old_id!=new_id){
  owner=new_id;if(temp_owner==old_id)temp_owner=new_id;
  if(temp_next_owner==old_id)temp_next_owner=new_id;
  stamp_valid=0;stamp_index=128;++serial;++darp_project_identity_remaps;
  /* Raw bank epochs remain valid. Force the next context binding to restore
   * them under the new UID before any task flush can capture live defaults. */
  darp_store_invalidate();
 }
 core_audio_irq_restore(sr);
}
void darp_project_tick(void){
 if(loading)return;
 if(bank){
  if(owner!=darp_ram_project_id())darp_project_reset(darp_ram_project_id());
  return;
 }
 unsigned used=darp_ui_visible;
 for(unsigned t=0;t<16;t++)used|=darp_controls[t].enabled | darp_me_enabled_tracks[t] | darp_me_saved_tracks[t];
 if(!bank && !used)return;
 if(memory())return;
 if(owner!=darp_ram_project_id())darp_project_reset(darp_ram_project_id());
}
static int stash_track(unsigned index,unsigned t,unsigned task){
 live_stamp next;make_stamp(t,index,&next);
 if(stamp_index==index && (stamp_valid&(1u<<t)) && same_stamp(&next,&stamps[t]))return 0;
 uint32_t token=darp_store_context_serial;
 if(task && !darp_store_snapshot_ready(index,token))return -1;
 me_record row;if(darp_me_snapshot_kit_track(t,(const unsigned char *)(0x4191f018u+index*0x91eu),&row))return -1;
 uint32_t sr=core_audio_irq_save();
 if(loading || owner!=darp_ram_project_id() || (task && !darp_store_snapshot_ready(index,token))){core_audio_irq_restore(sr);return -1;}
 if(stamp_index!=index){stamp_index=index;stamp_valid=0;}
 copy_record(&bank->track[index][t],&row);stamps[t]=next;stamp_valid|=1u<<t;++serial;
 core_audio_irq_restore(sr);return 0;
}
static void stash_all(unsigned index,unsigned task){
 if(loading || !bank || index>=128 || owner!=darp_ram_project_id())return;
 uint32_t token=darp_store_context_serial,id=owner,version=epoch;
 for(unsigned t=0;t<16;t++)if(stash_track(index,t,task))return;
 if(bank->epoch[index]==version)return;
 uint32_t sr=core_audio_irq_save();
 if(owner==id && epoch==version && (!task || darp_store_snapshot_ready(index,token)))bank->epoch[index]=version;
 core_audio_irq_restore(sr);
}
/* Audio departure already owns its guard; unchanged tracks are skipped.
 * Regular UI ticks use independent short per-track snapshot/commit guards. */
void darp_project_stash(unsigned index){stash_all(index,0);}
void darp_project_stash_task(unsigned index){stash_all(index,1);}
/* Explicit save, clipboard and pattern departure still flush every track.
 * During steady playback spread the background comparison across UI ticks. */
void darp_project_poll_track(unsigned index){
 static unsigned cursor;
 if(loading || !bank || index>=128 || owner!=darp_ram_project_id())return;
 if(bank->epoch[index]!=epoch || stamp_index!=index || stamp_valid!=0xffffu){
  stash_all(index,1);
  return;
 }
 stash_track(index,cursor,1);
 cursor=(cursor+1u)&15u;
}
void darp_project_apply(unsigned index,unsigned char *kit){
 if(loading || !bank || index>=128 || owner!=darp_ram_project_id() || bank->epoch[index]!=epoch)return;
 arp_snapshot_state s;
 for(unsigned t=0;t<8;t++)s.track[t]=bank->track[index][t].current;
 darp_ram_apply_controls(&s,kit);
 for(unsigned t=0;t<16;t++)if(darp_me_apply_snapshot_track(t,&bank->track[index][t]))darp_project_error=-31;
}
static int capture_raw(uint32_t id,uint8_t *out,unsigned cap){
 if(!out || cap<DARP_PROJECT_BYTES)return -1;
 darp_project_tick();if(!bank)return darp_project_error<0?darp_project_error:0;if(owner!=id)return -1;
 /* Flush after pending UI generation so an uninitialized new ME cannot leak. */
 darp_store_flush();darp_me_tick_all();darp_store_flush();
 uint32_t revision=serial,current_epoch=epoch;
 for(unsigned i=0;i<256;i++)out[i]=0;
 put(out,0x44415233u);put(out+4,2);put(out+8,DARP_PROJECT_BYTES);put(out+12,ME_RECORD_BYTES);put(out+16,128);put(out+20,16);put(out+24,id);put(out+28,temp_valid && temp_owner==id);
 for(unsigned index=0;index<128;index++){
  unsigned valid=bank->epoch[index]==current_epoch;
  if(valid)for(unsigned t=0;t<16;t++){
   uint32_t sr=core_audio_irq_save();copy_record(&capture_rows[t],&bank->track[index][t]);core_audio_irq_restore(sr);
  }
  for(unsigned t=0;t<16;t++){
   uint8_t *dest=out+256+(index*16+t)*ME_RECORD_BYTES;
   if(valid){if(me_record_encode(&capture_rows[t],dest))return -2;}
   else for(unsigned i=0;i<ME_RECORD_BYTES;i++)dest[i]=0;
  }
 }
 for(unsigned t=0;t<16;t++){
  uint8_t *dest=out+256+128*16*ME_RECORD_BYTES+t*ME_RECORD_BYTES;
  if(temp_valid && temp_owner==id){if(me_record_encode(&temp[t],dest))return -2;}
  else for(unsigned i=0;i<ME_RECORD_BYTES;i++)dest[i]=0;
 }
 if(owner!=id || epoch!=current_epoch || serial!=revision)return -3;
 return DARP_PROJECT_BYTES;
}
static int empty(const uint8_t *p){for(unsigned i=0;i<ME_RECORD_BYTES;i++)if(p[i])return 0;return 1;}
static void default_record(me_record *r){
 *r=(me_record){0};
 static const int16_t defaults[8]={28672,1024,16384,0,256,0,0,16384};
 for(unsigned i=0;i<8;i++)r->lfo3[i]=defaults[i];
 arp_snapshot_state s;arp_snapshot_default(&s);r->current=r->original=s.track[0];
 static const uint8_t knobs[8]={76,45,2,1,1,0,0,2};for(unsigned i=0;i<8;i++)r->knobs[i]=knobs[i];
 r->recall_knobs[0]=76;r->recall_knobs[1]=45;r->recall_knobs[2]=2;r->recall_knobs[3]=1;r->source_root=60;r->phrase.length=16;
}
static int load_raw(uint32_t id,const uint8_t *bytes,unsigned n){
 if(!bytes || n<256 || get(bytes)!=0x44415233u || get(bytes+8)!=n || get(bytes+12)!=ME_RECORD_BYTES || get(bytes+16)!=128 || get(bytes+28)>1)return -1;
 unsigned tracks=get(bytes+20),version=get(bytes+4);
 if(!((version==1 && tracks==8) || (version==2 && tracks==16)) || n!=256u+129u*tracks*ME_RECORD_BYTES)return -1;
 for(unsigned i=32;i<256;i++)if(bytes[i])return -1;
 for(unsigned index=0;index<129;index++){
  unsigned count=0;for(unsigned t=0;t<tracks;t++){
   const uint8_t *p=bytes+256+(index*tracks+t)*ME_RECORD_BYTES;me_record r;
   if(!empty(p)){if(me_record_decode(p,ME_RECORD_BYTES,&r))return -1;++count;}
  }
  if(count && count!=tracks)return -1;
  if(index==128 && (!!count!=!!get(bytes+28)))return -1;
 }
 if(memory())return -2;
 uint32_t sr=core_audio_irq_save();loading=1;core_audio_irq_restore(sr);darp_project_reset(id);
 for(unsigned index=0;index<128;index++){
  unsigned present=!empty(bytes+256+index*tracks*ME_RECORD_BYTES);
  if(present){for(unsigned t=0;t<16;t++){
   if(t<tracks){if(me_record_decode(bytes+256+(index*tracks+t)*ME_RECORD_BYTES,ME_RECORD_BYTES,&bank->track[index][t])){loading=0;return -1;}}
   else default_record(&bank->track[index][t]);
  }bank->epoch[index]=epoch;}
 }
 temp_valid=get(bytes+28);temp_owner=id;
 if(temp_valid)for(unsigned t=0;t<16;t++){
  if(t<tracks){if(me_record_decode(bytes+256+(128*tracks+t)*ME_RECORD_BYTES,ME_RECORD_BYTES,&temp[t])){loading=0;return -1;}}
  else default_record(&temp[t]);
 }
 sr=core_audio_irq_save();loading=0;darp_store_invalidate();core_audio_irq_restore(sr);darp_project_error=0;return 0;
}
void darp_project_temp_begin(unsigned valid,uint32_t id){
 temp_next_valid=0;temp_next_owner=id;
 if(valid && id==darp_ram_project_id() && !memory()){
  uint32_t token=darp_store_context_serial;unsigned ok=1;
  for(unsigned t=0;t<16;t++)if(darp_me_snapshot_track(t,&temp_next[t]))ok=0;
  temp_next_valid=ok && token==darp_store_context_serial && id==darp_ram_project_id();
 }
}
void darp_project_temp_commit(unsigned success){
 if(!success)return;
 uint32_t sr=core_audio_irq_save();temp_valid=temp_next_valid;temp_owner=temp_next_owner;
 if(temp_valid){me_record *old=temp;temp=temp_next;temp_next=old;}
 ++serial;core_audio_irq_restore(sr);
}
unsigned darp_project_temp_available(uint32_t id){return temp_valid && temp_owner==id;}
void darp_project_temp_restore(unsigned valid,uint32_t id){
 if(valid && id==darp_ram_project_id() && darp_project_temp_available(id)){
  arp_snapshot_state s;for(unsigned t=0;t<8;t++)s.track[t]=temp[t].current;
  darp_ram_apply_controls(&s,(unsigned char *)fw_kit);
  for(unsigned t=0;t<16;t++)if(darp_me_apply_snapshot_track(t,&temp[t]))darp_project_error=-31;
 }
 /* Audio is stopped by the native TEMP handoff before restoring these rows. */
}

static int pattern_capture_raw(uint32_t id,unsigned index,void *out,unsigned capacity){
 if(index>=128 || !out || capacity<16*ME_RECORD_BYTES)return -1;
 darp_project_tick();if(!bank || owner!=id)return darp_project_error<0?darp_project_error:0;
 unsigned current=((uint32_t)fw_kit-0x4191f018u)/0x91eu;
 if(current==index){darp_store_flush();darp_me_tick_all();darp_store_flush();}
 uint32_t sr=core_audio_irq_save();unsigned present=bank->epoch[index]==epoch;
 if(present){for(unsigned t=0;t<16;t++)copy_record(&capture_rows[t],&bank->track[index][t]);}
 core_audio_irq_restore(sr);
 if(!present)return 0;
 for(unsigned t=0;t<16;t++)if(me_record_encode(&capture_rows[t],(uint8_t *)out+t*ME_RECORD_BYTES))return -1;
 return 16*ME_RECORD_BYTES;
}
static int pattern_loaded_raw(uint32_t id,unsigned index,const void *data,unsigned n){
 if(index>=128 || id!=darp_ram_project_id())return -1;
 if(data && n!=8*ME_RECORD_BYTES && n!=16*ME_RECORD_BYTES)return -1;
 unsigned tracks=data?n/ME_RECORD_BYTES:0;
 for(unsigned t=0;t<tracks;t++){me_record row;if(me_record_decode((const uint8_t *)data+t*ME_RECORD_BYTES,ME_RECORD_BYTES,&row))return -1;}
 if(data && memory())return -1;
 if(bank){
  if(owner!=id)darp_project_reset(id);
  if(data)for(unsigned t=0;t<16;t++){
   if(t<tracks){if(me_record_decode((const uint8_t *)data+t*ME_RECORD_BYTES,ME_RECORD_BYTES,&capture_rows[t]))return -1;}
   else default_record(&capture_rows[t]);
  }
  uint32_t sr=core_audio_irq_save();
  if(data){for(unsigned t=0;t<16;t++)copy_record(&bank->track[index][t],&capture_rows[t]);bank->epoch[index]=epoch;}
  else bank->epoch[index]=0;
  ++serial;darp_store_invalidate_pattern(index);core_audio_irq_restore(sr);
 }
 return 0;
}

/* Keep the original transport's fixed two-bank budget and clipboard area.
 * Reserve scratch only in task context, never in render/audio callbacks. */
static uint8_t *codec_memory;static volatile unsigned codec_busy;
static int codec_enter(void){uint32_t sr=core_audio_irq_save();unsigned busy=codec_busy;codec_busy=1;core_audio_irq_restore(sr);return busy?-40:0;}
/* The OS 1.54 delete entry pairs with pd_allocate. Only the task holding
 * codec_busy owns this workspace. Release it before publishing availability. */
static void codec_leave(void){
 if(codec_memory)((void (*)(void *))0x400d43b4u)(codec_memory);
 codec_memory=0;
 uint32_t sr=core_audio_irq_save();codec_busy=0;core_audio_irq_restore(sr);
}
static int codec_ready(unsigned bytes){codec_memory=pd_allocate(bytes+4096u);return codec_memory?0:-30;}
extern uint32_t pd_crc(const void *,unsigned);
/* Group the four phrase-byte columns before LZ encoding. Step/span bytes
 * then compress together even when every saved melody is different. The
 * record CRC and all runtime bytes are restored before any decode/apply. */
static void transpose(uint8_t *p,unsigned n,unsigned inverse){
 unsigned start=get(p)==0x44415233u?256:0;uint8_t block[64];
 for(unsigned at=start;at+256<=n;at+=256){
  for(unsigned i=0;i<64;i++)block[i]=p[at+169+i];
  for(unsigned i=0;i<16;i++)for(unsigned j=0;j<4;j++)
   p[at+169+(inverse?4*i+j:16*j+i)]=block[inverse?16*j+i:4*i+j];
 }
}
static int pack(uint8_t *in,unsigned n,uint8_t *out,unsigned cap){
 if(cap<16 || (n&255u))return -33;
 uint32_t crc=pd_crc(in,n);transpose(in,n,0);
 int bytes=arp_lz_pack(in,n,out+16,cap-16,(uint32_t *)(codec_memory+n));transpose(in,n,1);if(bytes<0)return -33;
 put(out,0x444c5a31u);put(out+4,n);put(out+8,crc);put(out+12,(unsigned)bytes);return bytes+16;
}
static int unpack(const uint8_t *in,unsigned n,unsigned limit){
 if(n<16 || get(in)!=0x444c5a31u || get(in+4)>limit || (get(in+4)&255u) || get(in+12)!=n-16)return -1;
 unsigned size=get(in+4);if(arp_lz_unpack(in+16,n-16,codec_memory,size)!=(int)size)return -1;
 transpose(codec_memory,size,1);if(pd_crc(codec_memory,size)!=get(in+8))return -1;return (int)size;
}

int darp_project_capture(uint32_t id,uint8_t *out,unsigned cap){
 if(codec_enter())return -40;
 int result=codec_ready(DARP_PROJECT_BYTES);if(!result){result=capture_raw(id,codec_memory,DARP_PROJECT_BYTES);if(result>0)result=pack(codec_memory,(unsigned)result,out,cap);}
 codec_leave();return result;
}
int darp_project_load(uint32_t id,const uint8_t *in,unsigned n){
 if(!in || n<4)return -1;
 if(get(in)!=0x444c5a31u)return load_raw(id,in,n);
 if(codec_enter())return -40;
 int result=codec_ready(DARP_PROJECT_BYTES);if(!result){result=unpack(in,n,DARP_PROJECT_BYTES);if(result>0)result=load_raw(id,codec_memory,(unsigned)result);}
 codec_leave();return result;
}
static int pattern_capture(uint32_t id,unsigned index,void *out,unsigned cap){
 if(codec_enter())return -40;
 int result=codec_ready(16*ME_RECORD_BYTES);if(!result){result=pattern_capture_raw(id,index,codec_memory,16*ME_RECORD_BYTES);if(result>0)result=pack(codec_memory,(unsigned)result,out,cap);}
 codec_leave();return result;
}
static int pattern_loaded(uint32_t id,unsigned index,const void *in,unsigned n){
 if(in && n<4)return -1;
 if(!in || get((const uint8_t *)in)!=0x444c5a31u)return pattern_loaded_raw(id,index,in,n);
 if(codec_enter())return -40;
 int result=codec_ready(16*ME_RECORD_BYTES);if(!result){result=unpack(in,n,16*ME_RECORD_BYTES);if(result>0)result=pattern_loaded_raw(id,index,codec_memory,(unsigned)result);}
 codec_leave();return result;
}

#include "project-data-dt1/project_data.h"
static int project_capture_adapter(uint32_t id,void *out,unsigned cap){int result=-3;for(unsigned i=0;i<3 && result==-3;i++)result=darp_project_capture(id,out,cap);return result;}
static int project_load_adapter(uint32_t id,const void *in,unsigned n){return darp_project_load(id,in,n);}
const pd_client darp_project_client={0x44415250u,project_capture_adapter,project_load_adapter,darp_project_reset,pattern_capture,pattern_loaded,darp_project_identity_changed};
