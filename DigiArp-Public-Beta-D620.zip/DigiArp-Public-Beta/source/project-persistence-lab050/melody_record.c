/* SPDX-License-Identifier: MIT */
#include "melody_record.h"
#include "project_record.h"
static uint32_t get(const uint8_t *p){return (uint32_t)p[0]<<24 | (uint32_t)p[1]<<16 | (uint32_t)p[2]<<8 | p[3];}
static void put(uint8_t *p,uint32_t v){p[0]=(uint8_t)(v>>24);p[1]=(uint8_t)(v>>16);p[2]=(uint8_t)(v>>8);p[3]=(uint8_t)v;}
static void track_pack(uint8_t *d,const arp_snapshot_track *p){
 *d++=p->enabled;put(d,p->settings);d+=4;*d++=(uint8_t)(p->mask>>8);*d++=(uint8_t)p->mask;*d++=p->length;
 for(unsigned i=0;i<16;i++)*d++=(uint8_t)p->offsets[i];
 *d++=p->source;*d++=p->preset;*d++=p->count;*d++=p->manual_count;
 for(unsigned i=0;i<16;i++)*d++=p->manual[i];
 *d++=p->manual_octave;*d++=p->fixed_root;*d++=p->fixed_octave;*d++=p->key;*d++=p->probability;*d++=p->pulses;*d++=p->rotation;*d++=p->lfo[0];*d++=p->lfo[1];
}
static void track_unpack(const uint8_t *d,arp_snapshot_track *p){
 *p=(arp_snapshot_track){0};p->enabled=*d++;p->settings=get(d);d+=4;p->mask=(uint16_t)(256u*d[0]+d[1]);d+=2;p->length=*d++;
 for(unsigned i=0;i<16;i++){unsigned v=*d++;p->offsets[i]=(int8_t)(v<128?(int)v:(int)v-256);}
 p->source=*d++;p->preset=*d++;p->count=*d++;p->manual_count=*d++;
 for(unsigned i=0;i<16;i++)p->manual[i]=*d++;
 p->manual_octave=*d++;p->fixed_root=*d++;p->fixed_octave=*d++;p->key=*d++;p->probability=*d++;p->pulses=*d++;p->rotation=*d++;p->lfo[0]=*d++;p->lfo[1]=*d++;
}
static void config_pack(uint8_t *d,const melody_config *c){
 put(d,c->seed);d+=4;*d++=c->complexity;*d++=c->motion;*d++=c->rhythm;*d++=c->density;*d++=c->variation;*d++=c->repeat;*d++=c->tension;*d++=c->range;
 *d++=c->root;*d++=c->scale;*d++=c->source;*d++=c->arp_count;for(unsigned i=0;i<16;i++)*d++=c->arp[i];*d=c->ceiling;
}
static void config_unpack(const uint8_t *d,melody_config *c){
 *c=(melody_config){0};c->seed=get(d);d+=4;c->complexity=*d++;c->motion=*d++;c->rhythm=*d++;c->density=*d++;c->variation=*d++;c->repeat=*d++;c->tension=*d++;c->range=*d++;
 c->root=*d++;c->scale=*d++;c->source=*d++;c->arp_count=*d++;for(unsigned i=0;i<16;i++)c->arp[i]=*d++;c->ceiling=*d;
}
static int valid(const me_record *r){
 if(!r || r->flags>31 || r->preset>5 || r->classic_enabled>1 || r->source_root>127 || ((r->flags&6)==6) || ((r->flags&12) && !(r->flags&1)))return 0;
 for(unsigned i=0;i<8;i++)if(r->knobs[i]>127)return 0;
 if(r->knobs[2]<1 || r->knobs[2]>4 || r->knobs[3]>3 || r->knobs[4]>1 || r->knobs[5]>5 || r->knobs[7]>5 || r->recall_knobs[0]>127 || r->recall_knobs[1]>127 || r->recall_knobs[2]<1 || r->recall_knobs[2]>4 || r->recall_knobs[3]>3)return 0;
 arp_snapshot_state s={0};for(unsigned i=0;i<8;i++)s.track[i]=r->current;if(!arp_snapshot_valid(&s))return 0;
 for(unsigned i=0;i<8;i++)s.track[i]=r->original;
 if(!arp_snapshot_valid(&s))return 0;
 if(r->flags&1){uint8_t pool[MELODY_POOL];if(melody_pool(&r->config,pool)<1 || !melody_phrase_valid(&r->phrase))return 0;
  for(unsigned i=0;i<r->phrase.count;i++)if(r->phrase.event[i].cell>15)return 0;
 }
 return 1;
}
int me_record_encode(const me_record *r,uint8_t out[ME_RECORD_BYTES]){
 if(!out || !valid(r))return -1;
 uint8_t b[ME_RECORD_BYTES]={0};put(b,0x444d4531u);b[4]=1;b[5]=r->flags;b[6]=r->preset;b[7]=r->classic_enabled;
 for(unsigned i=0;i<8;i++)b[8+i]=r->knobs[i];
 for(unsigned i=0;i<4;i++)b[16+i]=r->recall_knobs[i];
 config_pack(b+20,&r->config);put(b+53,r->new_state);put(b+57,r->mutation_state);b[61]=r->source_root;
 track_pack(b+62,&r->current);track_pack(b+115,&r->original);
 if(r->flags&1){b[168]=r->phrase.count;
  for(unsigned i=0;i<r->phrase.count;i++){const melody_event *e=&r->phrase.event[i];uint32_t packed=(uint32_t)e->step<<28 | (uint32_t)(e->span-1u)<<24 | (uint32_t)e->note<<17 | (uint32_t)(e->velocity-1u)<<10 | (uint32_t)e->degree<<4 | e->cell;put(b+169+4*i,packed);}
 }
 for(unsigned i=0;i<8;i++){b[233+2*i]=(uint16_t)r->lfo3[i]>>8;b[234+2*i]=(uint16_t)r->lfo3[i];}
 b[249]=1;
 put(b+252,pd_crc(b,252));for(unsigned i=0;i<ME_RECORD_BYTES;i++)out[i]=b[i];return 0;
}
int me_record_decode(const uint8_t *b,unsigned n,me_record *out){
 if(!b || !out || n!=ME_RECORD_BYTES || get(b)!=0x444d4531u || b[4]!=1 || get(b+252)!=pd_crc(b,252))return -1;
 me_record r={0};r.flags=b[5];r.preset=b[6];r.classic_enabled=b[7];for(unsigned i=0;i<8;i++)r.knobs[i]=b[8+i];for(unsigned i=0;i<4;i++)r.recall_knobs[i]=b[16+i];
 config_unpack(b+20,&r.config);r.new_state=get(b+53);r.mutation_state=get(b+57);r.source_root=b[61];track_unpack(b+62,&r.current);track_unpack(b+115,&r.original);
 r.phrase.length=16;r.phrase.count=b[168];if(r.phrase.count>16 || (!(r.flags&1) && r.phrase.count))return -1;
 for(unsigned i=0;i<r.phrase.count;i++){
  uint32_t p=get(b+169+4*i);r.phrase.event[i]=(melody_event){(uint8_t)(p>>28),(uint8_t)(1u+((p>>24)&15u)),(uint8_t)((p>>17)&127u),(uint8_t)(1u+((p>>10)&127u)),(int16_t)((p>>4)&63u),(uint8_t)(p&15u),0};
 }
 for(unsigned i=169+4*r.phrase.count;i<252;i++)if((i<233 || i>=250) && b[i])return -1;
 if(b[249]==1){
  for(unsigned i=0;i<8;i++)r.lfo3[i]=(int16_t)((uint16_t)b[233+2*i]*256+b[234+2*i]);
  static const unsigned max[8]={32766,5888,32512,15616,1536,32512,1024,32766};
  for(unsigned i=0;i<8;i++)if((r.lfo3[i]<0 && !(i==3 && r.lfo3[i]==-256)) || r.lfo3[i]>(int)max[i])return -1;
 }else{
  /* Older four-control banks migrate to the closest native settings. */
  if(b[249] || b[233]>13 || b[234]>6 || b[235]>3 || b[236]>127)return -1;
  for(unsigned i=237;i<249;i++)if(b[i])return -1;
  static const int16_t dest[14]={-256,4352,6656,6912,11264,13568,13824,14080,14336,14592,14848,15104,15360,15616};
  static const int16_t wave[4]={0,1280,768,1024};
  r.lfo3[0]=24576;r.lfo3[1]=(int16_t)(b[234]*256);
  r.lfo3[2]=16384;r.lfo3[3]=dest[b[233]];
  r.lfo3[4]=wave[b[235]];r.lfo3[7]=16384+b[236]*128;
 }
 if(!valid(&r))return -1;
 *out=r;return 0;
}
