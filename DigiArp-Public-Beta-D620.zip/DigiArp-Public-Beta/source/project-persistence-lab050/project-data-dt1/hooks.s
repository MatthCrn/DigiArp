| SPDX-License-Identifier: GPL-2.0-or-later
.text
.globl pd_native_serialize
pd_native_serialize:
 lea -44(%sp),%sp
 movem.l %d2-%d7/%a2-%a6,(%sp)
 jmp 0x4007f312
.globl pd_native_deserialize
pd_native_deserialize:
 lea -36(%sp),%sp
 movem.l %d2-%d5/%a2-%a6,(%sp)
 jmp 0x4007eff0
.globl pd_native_project_write
pd_native_project_write:
 lea -52(%sp),%sp
 movem.l %d2-%d6/%a2-%a3,(%sp)
 jmp 0x400e5094
.globl pd_library
pd_library:
 jmp 0x40137a4a
.globl pd_guard
pd_guard:
 moveq #0,%d0
 move.w %sr,%d0
 move.w #0x2700,%sr
 rts
.globl pd_unguard
pd_unguard:
 move.l 4(%sp),%d0
 move.w %d0,%sr
 rts

.globl pd_clip_40017eba
pd_clip_40017eba:
 lea -24(%sp),%sp
 move.l %d2,20(%sp)
 move.l %a3,16(%sp)
 moveq #1,%d0
 move.l %d0,12(%sp)
 move.l 36(%sp),%d0
 move.l %d0,8(%sp)
 move.l 32(%sp),%d0
 move.l %d0,4(%sp)
 move.l 28(%sp),%d0
 move.l %d0,(%sp)
 jsr pd_pattern_copy
 lea 24(%sp),%sp
 move.l (%sp)+,%a0
 lea 36(%sp),%sp
 jmp (%a0)

.globl pd_clip_40017f2a
pd_clip_40017f2a:
 lea -24(%sp),%sp
 move.l %d2,20(%sp)
 move.l %a3,16(%sp)
 moveq #0,%d0
 move.l %d0,12(%sp)
 move.l 36(%sp),%d0
 move.l %d0,8(%sp)
 move.l 32(%sp),%d0
 move.l %d0,4(%sp)
 move.l 28(%sp),%d0
 move.l %d0,(%sp)
 jsr pd_pattern_copy
 lea 24(%sp),%sp
 move.l (%sp)+,%a0
 lea 36(%sp),%sp
 jmp (%a0)

.globl pd_clip_4001809e
pd_clip_4001809e:
 lea -24(%sp),%sp
 move.l %d2,20(%sp)
 move.l %a2,16(%sp)
 moveq #0,%d0
 move.l %d0,12(%sp)
 move.l 36(%sp),%d0
 move.l %d0,8(%sp)
 move.l 32(%sp),%d0
 move.l %d0,4(%sp)
 move.l 28(%sp),%d0
 move.l %d0,(%sp)
 jsr pd_pattern_copy
 lea 24(%sp),%sp
 move.l (%sp)+,%a0
 lea 36(%sp),%sp
 jmp (%a0)

.globl pd_clip_4001a3bc
pd_clip_4001a3bc:
 lea -24(%sp),%sp
 move.l %d2,20(%sp)
 move.l %a2,16(%sp)
 moveq #1,%d0
 move.l %d0,12(%sp)
 move.l 36(%sp),%d0
 move.l %d0,8(%sp)
 move.l 32(%sp),%d0
 move.l %d0,4(%sp)
 move.l 28(%sp),%d0
 move.l %d0,(%sp)
 jsr pd_pattern_copy
 lea 24(%sp),%sp
 move.l (%sp)+,%a0
 lea 36(%sp),%sp
 jmp (%a0)

.globl pd_clip_4001a534
pd_clip_4001a534:
 lea -24(%sp),%sp
 move.l %d2,20(%sp)
 move.l %a2,16(%sp)
 moveq #1,%d0
 move.l %d0,12(%sp)
 move.l 36(%sp),%d0
 move.l %d0,8(%sp)
 move.l 32(%sp),%d0
 move.l %d0,4(%sp)
 move.l 28(%sp),%d0
 move.l %d0,(%sp)
 jsr pd_pattern_copy
 lea 24(%sp),%sp
 move.l (%sp)+,%a0
 lea 32(%sp),%sp
 jmp (%a0)

| Original UID store at40014d32 and its following moveq-sized constant load.
| Preserve native caller-saved registers; callbacks run only for this explicit
| task-context identity transition, never a regular audio/UI tick.
.globl pd_identity_store
pd_identity_store:
 lea -16(%sp),%sp
 movem.l %d0-%d1/%a0-%a1,(%sp)
 move.l %d0,-(%sp)
 move.l 8(%a3),%d0
 move.l %d0,-(%sp)
 move.l %a3,-(%sp)
 jsr pd_identity_commit
 lea 12(%sp),%sp
 movem.l (%sp),%d0-%d1/%a0-%a1
 lea 16(%sp),%sp
 move.l #0x401804c0,%d0
 jmp 0x40014d3c
