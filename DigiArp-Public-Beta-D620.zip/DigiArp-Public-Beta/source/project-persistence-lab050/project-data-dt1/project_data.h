/* SPDX-License-Identifier: GPL-2.0-or-later */
#ifndef ELEK_DT1_PROJECT_DATA_H
#define ELEK_DT1_PROJECT_DATA_H
#include <stdint.h>
typedef struct {uint32_t tag;int (*capture)(uint32_t,void *,unsigned);int (*loaded)(uint32_t,const void *,unsigned);void (*reset)(uint32_t);int (*pattern_capture)(uint32_t,unsigned,void *,unsigned);int (*pattern_loaded)(uint32_t,unsigned,const void *,unsigned);void (*identity_changed)(uint32_t,uint32_t);} pd_client;
extern volatile int32_t pd_project_error;
void *pd_allocate(unsigned);
#endif
