/* SPDX-License-Identifier: GPL-2.0-or-later */
/* Experimental shared project transport for DT1 OS1.54. Tail refs are local to
 * the device: stock Transfer export is NOT yet a portable addon backup. */
#include "project_data.h"
#include "../project_record.h"
extern const pd_client darp_project_client;
static const pd_client *const dt1_project_clients_v2[]={&darp_project_client,0};
extern unsigned pd_native_serialize(void *,const void *,unsigned,unsigned,void *);
extern unsigned pd_native_deserialize(void *,const void *,void *);
extern unsigned pd_native_project_write(void *,void *,unsigned,unsigned,void *);
extern void *pd_library(void);
extern int pd_native_read(void *,unsigned,void *,unsigned);
extern int pd_native_write(void *,unsigned,const void *,unsigned);
extern int pd_native_sync(void *);
extern int pd_fw_read(void *,unsigned,unsigned,void *,void *);
extern unsigned pd_sector(unsigned,unsigned);
extern uint32_t pd_guard(void);
extern void pd_unguard(uint32_t);
#define WORKING ((const uint8_t *)0x409bbbfcu)
#define META 0x20u
#define META_BYTES 64u
#define META_MAGIC 0x454c504au
#define PACKET_MAGIC 0x50444331u
static uint8_t *stage;
static volatile unsigned busy;
static uint32_t blocked_owner;static int blocked_error;
volatile int32_t pd_project_error;
static uint32_t get(const uint8_t *p){return (uint32_t)p[0]<<24 | (uint32_t)p[1]<<16 | (uint32_t)p[2]<<8 | p[3];}
static void put(uint8_t *p,uint32_t x){p[0]=(uint8_t)(x>>24);p[1]=(uint8_t)(x>>16);p[2]=(uint8_t)(x>>8);p[3]=(uint8_t)x;}
static void copy(uint8_t *a,const uint8_t *b,unsigned n){for(unsigned i=0;i<n;i++)a[i]=b[i];}
static void clear(uint8_t *p,unsigned n){for(unsigned i=0;i<n;i++)p[i]=0;}
static unsigned active(void){return dt1_project_clients_v2[0]!=0;}
static int enter(void){uint32_t sr=pd_guard();unsigned was=busy;busy=1;pd_unguard(sr);return was?-1:0;}
static void leave(void){uint32_t sr=pd_guard();busy=0;pd_unguard(sr);}
static int memory(void){if(stage)return 0;stage=pd_allocate(PD_MAX_PAYLOAD);if(!stage){pd_project_error=-30;return -1;}return 0;}
static int meta(const uint8_t *p){
 if(get(p)!=META_MAGIC)return 0;
 if(get(p+4)!=1)return PD_INCOMPATIBLE;
 if(get(p+60)!=pd_crc(p,60) || get(p+8)>3)return PD_CORRUPT;
 for(unsigned i=44;i<60;i++)if(p[i])return PD_CORRUPT;
 if((get(p+8)&2) && (get(p+28)>128 || get(p+32)>1 || !get(p+36) || get(p+40)>PD_MAX_PAYLOAD || !get(p+40)))return PD_CORRUPT;
 return 1;
}
static void finish_meta(uint8_t *p){put(p,META_MAGIC);put(p+4,1);put(p+60,pd_crc(p,60));}
static void mark_pending(uint8_t *project,uint32_t id){
 uint8_t *p=project+META;int valid=meta(p);
 if(valid<0){pd_project_error=valid;return;}
 if(valid!=1 || get(p+12)!=id)clear(p,META_BYTES);
 put(p+8,get(p+8)|1u);put(p+12,id);finish_meta(p);
}
unsigned pd_serialize(void *dest,const void *source,unsigned mode,unsigned flags,void *progress){
 unsigned result=(uint8_t)pd_native_serialize(dest,source,mode,flags,progress);
 if(result && active() && source==WORKING)mark_pending(dest,get((const uint8_t *)source+8));
 return result;
}
static void reset_clients(uint32_t id){for(unsigned i=0;dt1_project_clients_v2[i];i++)if(dt1_project_clients_v2[i]->reset)dt1_project_clients_v2[i]->reset(id);}
static int capture(uint32_t id,unsigned *length){
 clear(stage,16);put(stage,PACKET_MAGIC);put(stage+4,1);unsigned at=16,count=0;
 for(unsigned i=0;dt1_project_clients_v2[i];i++){
  const pd_client *c=dt1_project_clients_v2[i];if(!c->tag || !c->capture || at>PD_MAX_PAYLOAD-8)return PD_INVALID;
  int n=c->capture(id,stage+at+8,PD_MAX_PAYLOAD-at-8);if(n<0)return n;if(!n)continue;
  if((unsigned)n>PD_MAX_PAYLOAD-at-8 || count>=32)return PD_INVALID;
  unsigned previous=16;for(unsigned j=0;j<count;j++){if(get(stage+previous)==c->tag)return PD_CONFLICT;previous+=8+get(stage+previous+4);}
  put(stage+at,c->tag);put(stage+at+4,(unsigned)n);at+=8+(unsigned)n;++count;
 }
 put(stage+8,count);put(stage+12,at);*length=at;return 0;
}
static int apply(uint32_t id,unsigned length){
 if(length<16 || get(stage)!=PACKET_MAGIC || get(stage+4)!=1 || get(stage+12)!=length || get(stage+8)>32)return PD_CORRUPT;
 unsigned count=get(stage+8),at=16;
 for(unsigned i=0;i<count;i++){
  if(at>length-8)return PD_CORRUPT;
  unsigned n=get(stage+at+4);if(n>length-at-8)return PD_CORRUPT;
  unsigned before=16;for(unsigned j=0;j<i;j++){if(get(stage+before)==get(stage+at))return PD_CORRUPT;before+=8+get(stage+before+4);}
  at+=8+n;
 }
 if(at!=length)return PD_CORRUPT;
 for(unsigned i=0;dt1_project_clients_v2[i];i++){
  const pd_client *c=dt1_project_clients_v2[i];at=16;unsigned found=0;
  for(unsigned j=0;j<count;j++){
   unsigned tag=get(stage+at),n=get(stage+at+4);
   if(tag==c->tag){if(!c->loaded || c->loaded(id,stage+at+8,n))return PD_CORRUPT;found=1;break;}at+=8+n;
  }
  if(!found && c->reset)c->reset(id);
 }
 return 0;
}
static int load_reference(const uint8_t *m,unsigned *length){
 uint32_t context[2]={(uint32_t)pd_library(),get(m+28)};
 pd_io io={context,pd_native_read,pd_native_write,pd_native_sync};
 int result=pd_load_bank(&io,get(m+32),get(m+36),get(m+16),get(m+20),stage,PD_MAX_PAYLOAD,length);
 if(result)return result==PD_MISSING?PD_CORRUPT:result;
 if(*length!=get(m+40) || pd_crc(stage,*length)!=get(m+24))return PD_CORRUPT;
 return 0;
}
unsigned pd_deserialize(void *dest,const void *source,void *progress){
 if(!active() || dest!=(void *)WORKING)return (uint8_t)pd_native_deserialize(dest,source,progress);
 if(enter()){pd_project_error=-40;return 0;}
 unsigned result=(uint8_t)pd_native_deserialize(dest,source,progress);
 if(result){
  uint32_t id=get((uint8_t *)dest+8);const uint8_t *m=(const uint8_t *)source+META;int valid=meta(m),error=0;
  if(valid==1 && (get(m+8)&2)){
   if(memory())error=-30;
   else if(!(get(m+8)&1) && get(m+20)!=pd_native_crc(source))error=PD_CORRUPT;
   else {unsigned n=0;error=load_reference(m,&n);if(!error)error=apply(id,n);}
   if(error){pd_project_error=error;blocked_owner=id;blocked_error=error;reset_clients(id);}else {pd_project_error=0;blocked_error=0;}
  }else {reset_clients(id);pd_project_error=valid<0?valid:0;blocked_error=valid<0?valid:0;blocked_owner=id;}
 }
 leave();return result;
}
unsigned pd_project_write(void *driver,void *native,unsigned slot,unsigned force,void *progress){
 uint8_t *project=native;
 if(!active() || !project || get(project)!=0xbeefbaceu || slot>128)return pd_native_project_write(driver,native,slot,force,progress);
 if(enter()){pd_project_error=-40;return 1;}
 unsigned result=1,n=0;uint8_t old[META_BYTES],prefix[512];copy(old,project+META,META_BYTES);
 int valid=meta(old),error=0;
 if(valid<0){error=valid;goto done;}
 if(blocked_error && get(project+24)==blocked_owner){error=blocked_error;goto done;}
 if(memory()){error=-30;goto done;}
 uint32_t id=get(project+24),native_crc=pd_native_crc(project);
 if(valid==1 && (get(old+8)&1) && get(old+12)==get(WORKING+8))error=capture(get(old+12),&n);
 else if(valid==1 && (get(old+8)&2)){
  if(get(old+20)!=native_crc && !(get(old+8)&1))error=PD_CORRUPT;
  else error=load_reference(old,&n);
 }else {clear(stage,16);put(stage,PACKET_MAGIC);put(stage+4,1);put(stage+12,16);n=16;}
 if(error)goto done;
 /* Protect the bank named by the prefix currently on disk, not an uncommitted
  * newer bank left by an earlier failed save. */
 uint32_t cb[3]={0};unsigned protect=2;
 if(pd_fw_read(driver,pd_sector(slot,0),512,prefix,cb)){error=PD_IO;goto done;}
 if(meta(prefix+META)==1 && (get(prefix+META+8)&2) && get(prefix+META+28)==slot)protect=get(prefix+META+32);
 uint32_t context[2]={(uint32_t)driver,slot};pd_io io={context,pd_native_read,pd_native_write,pd_native_sync};
 pd_commit commit;error=pd_save_protected_commit(&io,id,native_crc,stage,n,protect,&commit);if(error)goto done;
 uint8_t *m=project+META;clear(m,META_BYTES);put(m+8,2);put(m+12,id);put(m+16,id);put(m+20,native_crc);put(m+24,commit.crc);put(m+28,slot);put(m+32,commit.bank);put(m+36,commit.generation);put(m+40,n);finish_meta(m);
 result=pd_native_project_write(driver,native,slot,force,progress);
 if(result){copy(project+META,old,META_BYTES);error=PD_IO;}
 done:
 pd_project_error=error;leave();return error?1:result;
}

/* Native clipboard allocations are extended by 4096 bytes, owned by this
 * component. Every constructor fills this trailer at the kit-copy boundary;
 * the trailer therefore has the same lifetime as native clipboard/undo data. */
#define CLIP_BYTES 4096u
#define CLIP_AFTER_KIT 0x924u
void *pd_pattern_copy(void *dest,const void *source,unsigned n,unsigned to_clip,void *project,unsigned index){
 void *result=((void *(*)(void *,const void *,unsigned))0x400e8ae8)(dest,source,n);
 if(!active() || n!=0x91eu || index>=128)return result;
 if(enter()){pd_project_error=-40;return result;}
 uint32_t id=((uint32_t (*)(void *))0x40014cd4)(project);
 uint8_t *m=(uint8_t *)(to_clip?dest:(void *)source)+CLIP_AFTER_KIT;int error=0;
 if(to_clip){
  clear(m,CLIP_BYTES);put(m,0x454c5043u);put(m+4,1);unsigned at=16,count=0;
  for(unsigned i=0;dt1_project_clients_v2[i];i++){
   const pd_client *c=dt1_project_clients_v2[i];if(!c->pattern_capture)continue;
   if(at>CLIP_BYTES-12){error=PD_INVALID;break;}
   int size=c->pattern_capture(id,index,m+at+8,CLIP_BYTES-4-at-8);
   if(size<0){error=size;break;}if(!size)continue;
   if((unsigned)size>CLIP_BYTES-4-at-8 || count>=32){error=PD_INVALID;break;}
   put(m+at,c->tag);put(m+at+4,(unsigned)size);at+=8+(unsigned)size;++count;
  }
  if(error)clear(m,CLIP_BYTES);
  else{put(m+8,count);put(m+12,at);put(m+CLIP_BYTES-4,pd_crc(m,CLIP_BYTES-4));}
 }else{
  unsigned length=get(m+12),count=get(m+8),at=16;
  if(get(m)!=0x454c5043u || get(m+4)!=1 || length<16 || length>CLIP_BYTES-4 || count>32 || get(m+CLIP_BYTES-4)!=pd_crc(m,CLIP_BYTES-4))error=PD_CORRUPT;
  if(!error)for(unsigned i=0;i<count;i++){
   if(at>length-8 || get(m+at+4)>length-at-8){error=PD_CORRUPT;break;}at+=8+get(m+at+4);
  }
  if(at!=length)error=PD_CORRUPT;
  for(unsigned i=0;dt1_project_clients_v2[i];i++){
   const pd_client *c=dt1_project_clients_v2[i];if(!c->pattern_loaded)continue;
   const void *payload=0;unsigned size=0;at=16;
   if(!error)for(unsigned j=0;j<count;j++){
    if(get(m+at)==c->tag){payload=m+at+8;size=get(m+at+4);break;}at+=8+get(m+at+4);
   }
   if(c->pattern_loaded(id,index,payload,size)){error=PD_CORRUPT;(void)c->pattern_loaded(id,index,0,0);}
  }
 }
 if(error)pd_project_error=error;
 leave();return result;
}

/* OS1.54 Project::load regenerates the working UID AFTER deserialization.
 * This hook owns the proven native UID store, not a heuristic "same project"
 * guess on a later tick. Keep client data attached through that identity-only
 * transition; unrelated loads still validate/reset at pd_deserialize. */
volatile uint32_t pd_identity_remaps;
void pd_identity_commit(void *data,uint32_t old_id,uint32_t new_id){
 uint32_t sr=pd_guard();
 put((uint8_t *)data+8,new_id);
 if(data==(void *)WORKING && old_id!=new_id){
  if(blocked_error && blocked_owner==old_id)blocked_owner=new_id;
  for(unsigned i=0;dt1_project_clients_v2[i];i++){
   const pd_client *c=dt1_project_clients_v2[i];if(c->identity_changed)c->identity_changed(old_id,new_id);
  }
  ++pd_identity_remaps;
 }
 pd_unguard(sr);
}
