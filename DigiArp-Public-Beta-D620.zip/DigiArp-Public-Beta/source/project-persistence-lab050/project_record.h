/* SPDX-License-Identifier: MIT */
#ifndef ELK_DT1_PROJECT_RECORD_H
#define ELK_DT1_PROJECT_RECORD_H
#include <stdint.h>
#define PD_NATIVE_BYTES 0x372a04u
#define PD_SLOT_BYTES 0x400000u
#define PD_BANK_START 0x374000u
#define PD_BANK_STRIDE 0x46000u
#define PD_MAX_PAYLOAD 0x43000u
#define PD_HEADER 512u
/* Lab backend: offsets are relative to one selected project's 4 MiB slot.
 * read/write/sync return zero on success. Synchronous task context only. */
typedef struct {void *context;int (*read)(void *,unsigned,void *,unsigned);int (*write)(void *,unsigned,const void *,unsigned);int (*sync)(void *);} pd_io;
enum {PD_OK=0,PD_MISSING=1,PD_IO=-1,PD_INVALID=-2,PD_CORRUPT=-3,PD_CONFLICT=-4,PD_INCOMPATIBLE=-5};
uint32_t pd_crc(const void *,unsigned);
/* The native serialized-project CRC binds the record to the saved project.
 * Staging may change on failure; the live engine must only apply on PD_OK. */
int pd_load(const pd_io *,uint32_t project,uint32_t native_crc,void *staging,unsigned capacity,unsigned *length,uint32_t *generation);
int pd_save(const pd_io *,uint32_t project,uint32_t native_crc,const void *data,unsigned length);
/* Keep the bank referenced by the committed native prefix, even after a prior
 * uncommitted newer save. protected_bank=2 means no prefix bank to protect. */
/* Commit details are published only after the full on-disk readback succeeds. */
typedef struct {uint32_t bank,generation,length,crc;} pd_commit;
int pd_save_protected_commit(const pd_io *,uint32_t,uint32_t,const void *,unsigned,unsigned,pd_commit *);
int pd_save_protected(const pd_io *,uint32_t,uint32_t,const void *,unsigned,unsigned protected_bank);
int pd_load_bank(const pd_io *,unsigned bank,uint32_t generation,uint32_t project,uint32_t native_crc,void *,unsigned,unsigned *);
uint32_t pd_native_crc(const void *native_project);
#endif
