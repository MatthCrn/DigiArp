/* SPDX-License-Identifier: MIT */
#ifndef DIGIARP_MELODY_RECORD_H
#define DIGIARP_MELODY_RECORD_H
#include "../persistence-sources050/src/melody_engine.h"
#include "../persistence-sources050/src/arp_snapshot.h"
#define ME_RECORD_BYTES 256u
/* Deliberately no pointers, queues, transport positions or held-note state. */
typedef struct {
 arp_snapshot_track current,original;
 melody_config config;melody_phrase phrase;
 uint32_t new_state,mutation_state;
 int16_t lfo3[8];
 uint8_t flags,preset,classic_enabled,knobs[8],recall_knobs[4],source_root;
} me_record;
enum {ME_RECORD_INITIALIZED=1,ME_RECORD_ENABLED=2,ME_RECORD_IMPORTED=4,ME_RECORD_SAVED=8,ME_RECORD_CUSTOM=16};
int me_record_encode(const me_record *,uint8_t [ME_RECORD_BYTES]);
int me_record_decode(const uint8_t *,unsigned,me_record *);
#endif
